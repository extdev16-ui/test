using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.Banks;

public sealed class Bank : AggregateRoot{
    

    public Bank(string nombre, string descripcion, AuditRecord registroAuditoria)
    {
        Nombre = nombre;
        Descripcion = descripcion;
        RegistroAuditoria = registroAuditoria;
    }

    private Bank()
    {
        
    }

    public int Id { get; set;}
    public string Nombre  { get; set; } = string.Empty;
    public string Descripcion  { get; set; } = string.Empty;
    public AuditRecord RegistroAuditoria { get; set; }
}
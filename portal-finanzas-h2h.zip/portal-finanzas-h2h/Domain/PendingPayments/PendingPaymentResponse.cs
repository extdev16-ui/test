namespace Domain.PendingPayments;
public record PendingPaymentResponse
{
    public int PId { get; set; }
    public string PTecnalisPaymentId { get; set; } = string.Empty;
    public string PTipoDocumento { get; set; } = string.Empty;
    public string PNroDocumento { get; set; } = string.Empty;
    public string PTipoAbono { get; set; } = string.Empty;
    public string PNroCuentaBancaria { get; set; } = string.Empty;
    public string PNombreBeneficiario { get; set; } = string.Empty;
    public string PTipoMoneda { get; set; } = string.Empty;
    public decimal PImporteAbonar { get; set; }
    public string PBanco { get; set; } = string.Empty;
    public string PNombre { get; set; } = string.Empty;
    public string PApellidoPaterno { get; set; } = string.Empty;
    public string PApellidoMaterno { get; set; } = string.Empty;
    public string PFechaSolicitud { get; set; } = string.Empty;
    public string PEstadoCuenta { get; set; } = string.Empty;
    public string PTipoCuenta { get; set; } = string.Empty;
    public string PCodigoBanco { get; set; } = string.Empty;
    public int? PEstado { get; set; }
    public string PMensajeValidacion { get; set; } = string.Empty;
    public string PNroCuentaInterBancaria { get; set; } = string.Empty;
    public string ConfiguracionPago { get; set; } = string.Empty;
}



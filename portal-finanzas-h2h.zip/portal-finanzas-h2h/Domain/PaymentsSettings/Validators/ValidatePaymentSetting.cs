﻿using Domain.MassivesPayments.Common;
using Domain.Helpers;
using System.Text.RegularExpressions;
using Domain.PendingPayments;
using Domain.ValueObjects.PaymentsFiles;
using SixLabors.ImageSharp;
using System;
using System.Linq;

namespace Domain.PaymentsSettings.Validators;


public class ValidatePaymentSetting : IValidatePaymentSetting
{
	public ValidationResponseMessage ValidatePaymentSettingDetail(PaymentSetting paymentSetting)
	{
		ValidationResponseMessage validationResponseMessage = new();

		//Validate Payments Settings
		if (paymentSetting.DetalleConfiguraciones is null || paymentSetting.DetalleReglas is null || paymentSetting.DetalleErrores is null || string.IsNullOrEmpty(paymentSetting.Formato))
		{
			validationResponseMessage.Title = "Configuración Pago";
			validationResponseMessage.Message = "Falta la configuración de pagos para proceder con el pago.";
			return validationResponseMessage;
		}

		//Validate Setting Detail
		if (paymentSetting.DetalleConfiguraciones.Where(c => string.IsNullOrEmpty(c.Nombre) || c.Valor is null).ToList().Count > 0)
		{
			validationResponseMessage.Title = "Detalles Configuración Pago";
			validationResponseMessage.Message = "Existen campos obligatorios vacíos o nulos.";
			return validationResponseMessage;
		}

		//Validate Rule Detail
		if (paymentSetting.DetalleReglas.Where(c => string.IsNullOrEmpty(c.Campo) || string.IsNullOrEmpty(c.Tipo)).ToList().Count > 0)
		{
			validationResponseMessage.Title = "Reglas Configuración Pago";
			validationResponseMessage.Message = "Existen campos obligatorios vacíos o nulos.";
			return validationResponseMessage;
		}

		//Validate Errors Detail
		if (paymentSetting.DetalleErrores.Where(c => string.IsNullOrEmpty(c.Descripcion)).ToList().Count > 0)
		{
			validationResponseMessage.Title = "Errores Configuración Pago";
			validationResponseMessage.Message = "Existen campos obligatorios vacíos o nulos.";
			return validationResponseMessage;
		}

		validationResponseMessage.Validated = true;

		return validationResponseMessage;
	}

	public RuleResponseMessage ValidatePaymentRule(PaymentSetting paymentSetting, MassivePaymentResponse massivePaymentResponse)
	{
		RuleResponseMessage ruleResponseMessage = new();

        foreach (var detail in massivePaymentResponse.Detalle)
		{
			foreach (var rule in paymentSetting.DetalleReglas!)
			{
				switch (rule.Campo)
				{
					case "NumeroCuentaCargo":
						{
							ruleResponseMessage.Title = rule.Campo;
							if (string.IsNullOrEmpty(massivePaymentResponse.CuentaBancaria))
							{
								ruleResponseMessage.Message = "La cuenta cargo no puede estar vacía.";
								return ruleResponseMessage;
							}
							if (!Regex.IsMatch(massivePaymentResponse.CuentaBancaria, @"^\d+$"))
							{
								ruleResponseMessage.Message = $"La cuenta cargo {massivePaymentResponse.CuentaBancaria} no cuenta con el formato correcto.";
								return ruleResponseMessage;
							}
							if (massivePaymentResponse.CuentaBancaria.Length < rule.LongitudMinima.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"La longitud mínima de la cuenta cargo es de {rule.LongitudMinima.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}
							if (massivePaymentResponse.CuentaBancaria.Length > rule.LongitudMaxima.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"La longitud máxima de la cuenta cargo es de {rule.LongitudMaxima.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}

							break;
						}
					case "NumeroCuentaDestino":
						{
							ruleResponseMessage.Title = rule.Campo;
                            string NroCuentaBeneficiario = detail.CuentaBeneficiario.Replace("-", "");
							
                            if (string.IsNullOrEmpty(NroCuentaBeneficiario))
							{
								ruleResponseMessage.Message = "La cuenta abono no puede estar vacía.";
								return ruleResponseMessage;
							}
							if (!Regex.IsMatch(NroCuentaBeneficiario, @"^\d+$"))
							{
								ruleResponseMessage.Message = $"La cuenta abono {detail.CuentaBeneficiario} no cuenta con el formato correcto.";
								return ruleResponseMessage;
							}
							if (detail.CuentaBeneficiario.Length < rule.LongitudMinima.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"La longitud mínima de la cuenta abono es de {rule.LongitudMinima.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}
							if (detail.CuentaBeneficiario.Length > rule.LongitudMaxima.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"La longitud máxima de la cuenta abono es de {rule.LongitudMaxima.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}

							break;
						}
					case "NumeroDocumento":
						{
							ruleResponseMessage.Title = rule.Campo;
							if (string.IsNullOrEmpty(detail.NumeroDocumento))
							{
								ruleResponseMessage.Message = "El número de documento no puede estar vacío.";
								return ruleResponseMessage;
							}
							if (detail.NumeroDocumento.Length < rule.LongitudMinima.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"La longitud mínima del número de documento es de {rule.LongitudMinima.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}
							if (detail.NumeroDocumento.Length > rule.LongitudMaxima.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"La longitud máxima del número de documento es de {rule.LongitudMaxima.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}

							break;
						}
					case "ImporteTotal":
						{
							ruleResponseMessage.Title = rule.Campo;
							if (detail.Monto < rule.Minimo.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"El valor mínimo del monto es de {rule.Minimo.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}
							if (detail.Monto > rule.Maximo.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"El valor máximo del monto es de {rule.Maximo.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}

							break;
						}
					case "TipoCuenta":
						{
							ruleResponseMessage.Title = rule.Campo;
							if (detail.TipoCuenta.Length > rule.LongitudMaxima.GetValueOrDefault())
							{
								ruleResponseMessage.Message = $"La longitud máxima del tipo de cuenta es de {rule.LongitudMaxima.GetValueOrDefault()}.";
								return ruleResponseMessage;
							}

							break;
						}

				}
			}
		}

		ruleResponseMessage.Validated = true;

		return ruleResponseMessage;
	}

	public List<PendingPaymentResponse> ValidateRulePendingPayment(List<PendingPaymentResponse> pendingPaymentResponses, List<PaymentFileRule> paymentFileRules, List<PaymentFileBank> paymentBanksValidator)
	{
		List<PendingPaymentResponse> pendingPaymentResponsesResult = pendingPaymentResponses;

        var bancosValidacionFormat1 = Common.Constants.BankFormatNumber.PaymentConfigurationFormat1.Split(',');
        var bancosValidacionFormat2 = Common.Constants.BankFormatNumber.PaymentConfigurationFormat2.Split(',');

        foreach (var pendingPaymentResponse in pendingPaymentResponsesResult)
		{
			pendingPaymentResponse.PEstado = null;
			pendingPaymentResponse.PMensajeValidacion = "";

			foreach (var rule in paymentFileRules)
			{
				switch (rule.Campo)
				{
					case "NumeroCuentaDestino":
						{
							//Se retira los guiones de la cuenta bancaria.
							string pNroCuentaBancaria = pendingPaymentResponse.PNroCuentaBancaria.Replace("-", "");

                            string pTipoCuenta = pendingPaymentResponse.PTipoCuenta;
							string pTipoAbono = pendingPaymentResponse.PTipoAbono;

							if (string.IsNullOrEmpty(pNroCuentaBancaria))
							{
								pendingPaymentResponse.PEstado = 0;
								pendingPaymentResponse.PMensajeValidacion += $"La cuenta abono no puede estar vacía.<br>";
							}
                            if (!Regex.IsMatch(pNroCuentaBancaria, @"^\d+$"))
							{
								pendingPaymentResponse.PEstado = 0;
								pendingPaymentResponse.PMensajeValidacion += $"La cuenta abono {pNroCuentaBancaria} no cuenta con el formato correcto.<br>";
							}

							if (bancosValidacionFormat1.Contains(pendingPaymentResponse.ConfiguracionPago))
							{
                                if (pNroCuentaBancaria.Length < rule.LongitudMinima.GetValueOrDefault())
                                {
                                    pendingPaymentResponse.PEstado = 0;
                                    pendingPaymentResponse.PMensajeValidacion += $"La longitud mínima de la cuenta abono es de {rule.LongitudMinima.GetValueOrDefault()}.<br>";
                                }
                                if (pNroCuentaBancaria.Length > rule.LongitudMaxima.GetValueOrDefault())
                                {
                                    pendingPaymentResponse.PEstado = 0;
                                    pendingPaymentResponse.PMensajeValidacion += $"La longitud máxima de la cuenta abono es de {rule.LongitudMaxima.GetValueOrDefault()}.<br>";
                                }

                                switch (pTipoCuenta)
                                {
                                    case "2":
                                        {
                                            if (pNroCuentaBancaria.Length != rule.LongitudCuentaAhorro.GetValueOrDefault())
                                            {
                                                pendingPaymentResponse.PEstado = 0;
                                                pendingPaymentResponse.PMensajeValidacion += $"La longitud de la cuenta de ahorros debe ser de {rule.LongitudCuentaAhorro.GetValueOrDefault()}.<br>";
                                            }
                                        }
                                        break;
                                    case "1":
                                        {
                                            if (pNroCuentaBancaria.Length != rule.LongitudCuentaCorriente.GetValueOrDefault())
                                            {
                                                pendingPaymentResponse.PEstado = 0;
                                                pendingPaymentResponse.PMensajeValidacion += $"La longitud de la cuenta corriente debe ser de {rule.LongitudCuentaCorriente.GetValueOrDefault()}.<br>";
                                            }
                                        }
                                        break;
                                }
                            }
							else if (bancosValidacionFormat2.Contains(pendingPaymentResponse.ConfiguracionPago))
							{
								//Valide count in list the configuration:
								int exists_bank = 0;
								string bank_name = pendingPaymentResponse.PBanco;
								string money = pendingPaymentResponse.PTipoMoneda;
								string type_account = pendingPaymentResponse.PTipoCuenta;
								string type_finance = pendingPaymentResponse.PTipoAbono;
								int length_account = pNroCuentaBancaria.Length;

                                foreach (var validator_bank in paymentBanksValidator) 
								{
									if (validator_bank.Banco == bank_name)
									{
										exists_bank = 1;
                                    }

									if(validator_bank.Banco == bank_name && 
										validator_bank.CodigoMoneda == money &&
										validator_bank.TipoCuenta == Convert.ToInt32(type_account) &&
										validator_bank.TipoAbono == type_finance)
									{
										if(validator_bank.Longitud != length_account)
										{
                                            pendingPaymentResponse.PEstado = 0;
                                            pendingPaymentResponse.PMensajeValidacion += $"La longitud de la cuenta del banco {bank_name} debe ser de {validator_bank.Longitud} caracteres.<br>";
                                            break;
                                        }
                                    }

                                }
								//If not exist configuration of bank, take the properties to default json:
								if(exists_bank == 0)
								{
									var default_values = paymentBanksValidator.Where(t => t.Banco == "DEFAULT");
									foreach(var values in default_values)
									{
                                        if (values.Banco == bank_name &&
											values.CodigoMoneda == money &&
											values.TipoCuenta == Convert.ToInt32(type_account) &&
											values.TipoAbono == type_finance)
                                        {
                                            if (values.Longitud != length_account)
                                            {
                                                pendingPaymentResponse.PEstado = 0;
                                                pendingPaymentResponse.PMensajeValidacion += $"La longitud de la cuenta del banco {bank_name} debe ser de {values.Longitud} caracteres.<br>";
                                                break;
                                            }
                                        }
                                    }

                                }

                            }
							else
							{
                                pendingPaymentResponse.PEstado = 0;
                                pendingPaymentResponse.PMensajeValidacion += $"No existe una configuracion en las constantes para el código {pendingPaymentResponse.ConfiguracionPago}.<br>";
                            }
							break;
						}
					case "NumeroDocumento":
						{
							string pNroDocumento = pendingPaymentResponse.PNroDocumento;
							if (string.IsNullOrEmpty(pNroDocumento))
							{
								pendingPaymentResponse.PEstado = 0;
								pendingPaymentResponse.PMensajeValidacion += $"El número de documento no puede estar vacío.<br>";
							}
							if (pNroDocumento.Length < rule.LongitudMinima.GetValueOrDefault())
							{
								pendingPaymentResponse.PEstado = 0;
								pendingPaymentResponse.PMensajeValidacion += $"La longitud mínima del número de documento es de {rule.LongitudMinima.GetValueOrDefault()}.<br>";
							}
							if (pNroDocumento.Length > rule.LongitudMaxima.GetValueOrDefault())
							{
								pendingPaymentResponse.PEstado = 0;
								pendingPaymentResponse.PMensajeValidacion += $"La longitud máxima del número de documento es de {rule.LongitudMaxima.GetValueOrDefault()}.<br>";
							}

							break;
						}
					case "TipoCuenta":
						{
							string pTipoCuenta = pendingPaymentResponse.PTipoCuenta;
							if (string.IsNullOrEmpty(pTipoCuenta))
							{
								pendingPaymentResponse.PEstado = 0;
								pendingPaymentResponse.PMensajeValidacion += $"El tipo de cuenta no puede ser vacío.<br>";
							}
							if (pTipoCuenta.Length > rule.LongitudMaxima.GetValueOrDefault())
							{
								pendingPaymentResponse.PEstado = 0;
								pendingPaymentResponse.PMensajeValidacion += $"La longitud máxima del tipo de cuenta es de {rule.LongitudMaxima.GetValueOrDefault()}.<br>";
							}

							break;
						}

				}
			}
		}

		return pendingPaymentResponsesResult;
	}


}
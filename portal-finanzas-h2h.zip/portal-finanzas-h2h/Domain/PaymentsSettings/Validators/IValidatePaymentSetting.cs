﻿using Domain.Helpers;
using Domain.MassivesPayments.Common;
using Domain.PendingPayments;
using Domain.ValueObjects.PaymentsFiles;

namespace Domain.PaymentsSettings.Validators
{
    public interface IValidatePaymentSetting
    {
        public ValidationResponseMessage ValidatePaymentSettingDetail(PaymentSetting paymentSetting);
        public RuleResponseMessage ValidatePaymentRule(PaymentSetting paymentSetting, MassivePaymentResponse massivePaymentResponse);
        public List<PendingPaymentResponse> ValidateRulePendingPayment(List<PendingPaymentResponse> pendingPaymentResponses, List<PaymentFileRule> paymentFileRules, List<PaymentFileBank> paymentBanksValidator);

    }
}

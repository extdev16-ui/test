namespace Domain.PaymentsSettings.Interfaces;

public interface IPaymentSettingRepository
{
    Task<PaymentSetting?> GetPaymentSettingById(int idPaymentSetting);
    Task<PaymentSetting?> GetPaymentSettingByCode(string code);
}
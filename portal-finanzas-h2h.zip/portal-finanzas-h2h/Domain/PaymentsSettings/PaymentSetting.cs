using Domain.Apps;
using Domain.Banks;
using Domain.Modalities;
using Domain.PaymentsFiles.Helpers;
using Domain.Plataforms;
using Domain.Primitives;
using Domain.ValueObjects;
using Domain.ValueObjects.PaymentsFiles;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Domain.PaymentsSettings;

public sealed class PaymentSetting : AggregateRoot
{

	public PaymentSetting(int idAplicacion, int idBanco, int idPlataforma, int idModalidad, string configuraciones, string reglas, string bancos, AuditRecord registroAuditoria)
	{
		IdAplicacion = idAplicacion;
		IdBanco = idBanco;
		IdPlataforma = idPlataforma;
		IdModalidad = idModalidad;
		Configuraciones = configuraciones;
		Reglas = reglas;
        CuentasBancos = bancos;
        RegistroAuditoria = registroAuditoria;
	}

	private PaymentSetting()
	{

	}

	public int Id { get; set; }
	public string Codigo { get; set; } = string.Empty;
	public int IdAplicacion { get; set; }
	public App Aplicacion { get; set; }
	public int IdBanco { get; set; }
	public Bank Banco { get; set; }
	public int IdPlataforma { get; set; }
	public Plataform Plataforma { get; set; }
	public int IdModalidad { get; set; }
	public Mode Modalidad { get; set; }

	public int Version { get; set; }

	[JsonIgnore]
	public string Configuraciones { get; set; } = string.Empty;
	[JsonIgnore]
	public string Reglas { get; set; } = string.Empty;
	[JsonIgnore]
	public string Formato { get; set; } = string.Empty;
	public string Errores { get; set; } = string.Empty;
    [JsonIgnore]
    public string CuentasBancos { get; set; } = string.Empty;

    [JsonPropertyName("configuraciones")]
	public List<PaymentFileSetting>? DetalleConfiguraciones { get; set; }
	[JsonPropertyName("reglas")]
	public List<PaymentFileRule>? DetalleReglas { get; set; }
	[JsonPropertyName("formato")]
	public List<PaymentFileFormat>? DetalleFormato { get; set; }
	public List<PaymentFileFormatTxt>? DetalleFormatoTxt { get; set; }
	public List<PaymentFileFormatXml>? DetalleFormatoXml { get; set; }
	[JsonPropertyName("errores")]
	public List<PaymentFileError>? DetalleErrores { get; set; }
    [JsonPropertyName("cuentas_bancos")]
    public List<PaymentFileBank>? DetalleBancos { get; set; }
    public AuditRecord RegistroAuditoria { get; set; }


	// M�todo para realizar la deserializaci�n
	public void DeserializeDetails()
	{
		var options = new JsonSerializerOptions
		{
			PropertyNameCaseInsensitive = true
		};

		DetalleConfiguraciones = JsonSerializer.Deserialize<List<PaymentFileSetting>>(Configuraciones, options);
		DetalleReglas = JsonSerializer.Deserialize<List<PaymentFileRule>>(Reglas, options);
		//DetalleFormato = JsonSerializer.Deserialize<List<PaymentFileFormatTxt>>(Formato, options);
		DetalleErrores = JsonSerializer.Deserialize<List<PaymentFileError>>(Errores, options);

		if (!string.IsNullOrEmpty(CuentasBancos))
			DetalleBancos = JsonSerializer.Deserialize<List<PaymentFileBank>>(CuentasBancos, options);
    }

	public void DeserializeFormatByFileType()
	{
		DeserializeDetails();

		string? fileFormat = DetalleConfiguraciones!.Find(c => c.Nombre == "formatoArchivo")?.Valor; 

		switch (fileFormat)
		{
			case "xml":
				{
					DetalleFormatoXml = PaymentFormatDeserializer.Deserialize<PaymentFileFormatXml>(Formato);

				}
				break;
			case "txt":
				{

					DetalleFormatoTxt = PaymentFormatDeserializer.Deserialize<PaymentFileFormatTxt>(Formato);
				}
				break;
			default:
				{
					throw new NotImplementedException("No se encontr� la configuraci�n del formato del archivo.");
				}
		}
	}
}
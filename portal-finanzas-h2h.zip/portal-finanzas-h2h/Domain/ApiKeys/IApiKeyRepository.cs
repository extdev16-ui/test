namespace Domain.ApiKeys;

public interface IApiKeyRepository{
    void Add(ApiKey apiKey);
    Task<bool> ExistByKey(string key);
}
using Domain.Apps;
using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.ApiKeys;

public sealed class ApiKey : AggregateRoot{
    
    public ApiKey(string key, int idAplicacion, DateTime fechaExpiracion, AuditRecord registroAuditoria)
    {
        Key = key;
        IdAplicacion = idAplicacion;
        FechaExpiracion = fechaExpiracion;
        RegistroAuditoria = registroAuditoria;
    }

    private ApiKey()
    {
        
    }
    
    public int Id { get; set; }
    public string Key { get; set; } = string.Empty;
    public int IdAplicacion { get; set; }
    public App Aplicacion { get; set; }
    public DateTime FechaExpiracion { get; set; }
    public AuditRecord RegistroAuditoria {get; set;}


    public static string GenerateKey() => $"{Guid.NewGuid()}-{DateTime.UtcNow.Ticks}-{GenerateRandomString(8)}";

    private static string GenerateRandomString(int length)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        var random = new Random();
        var result = new char[length];
        for (int i = 0; i < length; i++)
        {
            result[i] = chars[random.Next(chars.Length)];
        }
        return new string(result);
    }

}
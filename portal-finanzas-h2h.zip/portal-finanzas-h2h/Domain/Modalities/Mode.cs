using Domain.Plataforms;
using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.Modalities;

public sealed class Mode : AggregateRoot{
    
    public Mode(string nombre, string descripcion, int version, AuditRecord registroAuditoria)
    {
        Nombre = nombre;
        Descripcion = descripcion;
        Version = version;
        RegistroAuditoria = registroAuditoria;
    }

    private Mode()
    {
        
    }

    public int Id { get; set;}
    public string Nombre {get; set;} = string.Empty;
    public string Descripcion {get; set;} = string.Empty;
    public int Version {get; set;}
    public AuditRecord RegistroAuditoria {get; set;}

}
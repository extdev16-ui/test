using Domain.Catalogs;
using Domain.PaymentsFiles;
using Domain.PaymentsOrdersDetails;
using Domain.PaymentsSettings;
using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.PaymentsOrders;

public sealed class PaymentOrder : AggregateRoot{
    
    public PaymentOrder(int idPagoMasivo, int idCatalogoEstado, decimal montoTotal, int idCatalogoMoneda, string comentarios, int idConfiguracionPago, DateTime fechaPago, string fechaEnvio, string fechaRespuesta, AuditRecord registroAuditoria)
    {
        IdPagoMasivo = idPagoMasivo;
        IdCatalogoEstado = idCatalogoEstado;
        MontoTotal = montoTotal;
        IdCatalogoMoneda = idCatalogoMoneda;
        Comentarios = comentarios;
        IdConfiguracionPago = idConfiguracionPago;
        FechaPago = fechaPago;
        FechaEnvio = fechaEnvio;
        FechaRespuesta = fechaRespuesta;
        RegistroAuditoria = registroAuditoria;
    }

    public PaymentOrder(int id, string codigoCatalogoEstado, int idCatalogoEstado, string fechaEnvio, string fechaRespuesta)
    {
        Id = id;
        IdCatalogoEstado = idCatalogoEstado;
        CatalogoEstado = new Catalog(idCatalogoEstado, codigoCatalogoEstado);
        FechaEnvio = fechaEnvio;
        FechaRespuesta = fechaRespuesta;
    }

    private PaymentOrder()
    {
        
    }

    public int Id { get; set;}
    public int IdPagoMasivo {get; set;}
    public int IdCatalogoEstado {get; set;}
    public Catalog CatalogoEstado { get; set;}
    public decimal MontoTotal {get; set;}
    public int IdCatalogoMoneda {get; set;}
    public Catalog CatalogoMoneda { get; set;}
    public string Comentarios {get; set;} = string.Empty;
    public int IdConfiguracionPago {get; set;}
    public DateTime FechaPago { get; set; }
    public string FechaEnvio { get; set; }
    public string FechaRespuesta { get; set; }
    public PaymentSetting ConfiguracionPago {get; set;}
    public List<PaymentOrderDetail> Detalle {get; set;}
    public AuditRecord RegistroAuditoria {get; set;}

}
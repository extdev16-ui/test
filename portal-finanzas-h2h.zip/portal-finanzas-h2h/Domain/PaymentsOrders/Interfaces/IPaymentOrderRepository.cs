using Domain.ValueObjects;

namespace Domain.PaymentsOrders.Interfaces;

public interface IPaymentOrderRepository
{
    Task<PaymentOrder?> GetByMassivePayment(int idMassivePayment);
    Task<AuditRecord?> GetAuditRecordById(int id);
    void Add(PaymentOrder paymentOrder);
    void Update(PaymentOrder paymentOrder, AuditRecord auditRecord);
}
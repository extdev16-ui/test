using System.Text.Json.Serialization;

namespace Domain.ValueObjects.PaymentsFiles;

public partial record PaymentFileFormat
{
    [JsonPropertyName("campo")]
    public string Campo { get; set; } = string.Empty;	
}
using System.Text.Json.Serialization;

namespace Domain.ValueObjects.PaymentsFiles;

public partial record PaymentFileBank
{
    public PaymentFileBank() { }

    [JsonPropertyName("banco")]
    public string? Banco { get; init; }

    [JsonPropertyName("codigoMoneda")]
    public string? CodigoMoneda { get; init; }

    [JsonPropertyName("tipoCuenta")]
    public int? TipoCuenta { get; init; }

    [JsonPropertyName("tipoAbono")]
    public string? TipoAbono { get; init; }

    [JsonPropertyName("longitud")]
    public int? Longitud { get; init; }
}
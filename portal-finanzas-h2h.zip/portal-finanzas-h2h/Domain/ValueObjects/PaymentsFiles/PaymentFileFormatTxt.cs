using System;
using System.Text.Json.Serialization;

namespace Domain.ValueObjects.PaymentsFiles;

public partial record PaymentFileFormatTxt: PaymentFileFormat
{
    private static readonly Random _random = new();

    public PaymentFileFormatTxt() { }

    [JsonPropertyName("inicio")]
    public int Inicio { get; set; }
    [JsonPropertyName("longitud")]
    public int Longitud { get; set; }
    [JsonPropertyName("obligatorio")]
    public bool? Obligatorio { get; set; }

    [JsonPropertyName("formatoFecha")]
    public string FormatoFecha { get; set; } = string.Empty;
    [JsonPropertyName("rangoInicio")]
    public int? RangoInicio { get; set; }
    [JsonPropertyName("rangoFin")]
    public int? RangoFin { get; set; }
    public int? ModuloRaiz { get; set; }

    [JsonPropertyName("valorPorDefecto")]
    public string ValorPorDefecto
    {
        get
        {
            return Campo == "moduloRaiz" ? GenerateRandomNumber(RangoInicio.GetValueOrDefault(), RangoFin.GetValueOrDefault()).ToString() : _valorPorDefecto;
        }
        set
        {
            _valorPorDefecto = value;
        }
    }
    [JsonPropertyName("totales")]
    public bool? Totales { get; set; }
    [JsonPropertyName("oficina")]
    public string Oficina { get; set; } = string.Empty;
    [JsonPropertyName("cuentaCorrienteSoles")]
    public string CuentaCorrienteSoles { get; set; } = string.Empty;
    [JsonPropertyName("cuentaCorrienteDolares")]
    public string CuentaCorrienteDolares { get; set; } = string.Empty;
    [JsonPropertyName("cuentaAhorroSoles")]
    public string CuentaAhorroSoles { get; set; } = string.Empty;
    [JsonPropertyName("cuentaAhorroDolares")]
    public string CuentaAhorroDolares { get; set; } = string.Empty;
    public string _valorPorDefecto { get; set; } = string.Empty;

    private int GenerateRandomNumber(int min, int max)
    {
        return _random.Next(min, max + 1);
    }

}
using System.Text.Json.Serialization;

namespace Domain.ValueObjects.PaymentsFiles;

public partial record PaymentFileFormatXml : PaymentFileFormat
{
	[JsonPropertyName("ruta")]
	public string Ruta { get; set; } = string.Empty;

	[JsonPropertyName("repetible")]
    public bool? Repetible { get; set; }

	[JsonPropertyName("atributo")]
	public string? Atributo { get; set; }

	[JsonPropertyName("valorAtributo")]
	public string? ValorAtributo { get; set; }

	[JsonPropertyName("valorPorDefecto")]
	public string? ValorPorDefecto { get; set; }

	[JsonPropertyName("items")]
	public List<PaymentFileFormatXml>? Items { get; set; } = [];

    [JsonPropertyName("nivel")]
    public string? Nivel { get; set; }
}
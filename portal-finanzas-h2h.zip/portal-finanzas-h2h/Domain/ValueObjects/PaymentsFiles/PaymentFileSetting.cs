using System.Text.Json.Serialization;

namespace Domain.ValueObjects.PaymentsFiles;

public partial record PaymentFileSetting
{
    public PaymentFileSetting() { }

    [JsonPropertyName("nombre")]
    public string? Nombre { get; init; }
    [JsonPropertyName("valor")]
    public string? Valor { get; init; }
    [JsonPropertyName("horaInicio")]
    public string? HoraInicio { get; init; }
    [JsonPropertyName("horaFin")]
    public string? HoraFin { get; init; }
    [JsonPropertyName("origen")]
    public string? Origen { get; init; }
}
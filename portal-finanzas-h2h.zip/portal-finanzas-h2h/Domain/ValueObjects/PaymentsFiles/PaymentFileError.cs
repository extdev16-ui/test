using System.Text.Json.Serialization;

namespace Domain.ValueObjects.PaymentsFiles;

public partial record PaymentFileError
{
    public PaymentFileError() { }

    [JsonPropertyName("codigo")]
    public int Codigo { get; init; }
    [JsonPropertyName("descripcion")]
    public string Descripcion { get; init; } = string.Empty;

    [JsonPropertyName("tipo")]
    public PaymentErrorsType Tipo { get; init; } = new PaymentErrorsType();


    public partial record PaymentErrorsType
    {
        public PaymentErrorsType() { }
        [JsonPropertyName("codigo")]
        public string Codigo { get; init; } = string.Empty;


        [JsonPropertyName("descripcion")]
        public string Descripcion { get; init; } = string.Empty;
    }
}
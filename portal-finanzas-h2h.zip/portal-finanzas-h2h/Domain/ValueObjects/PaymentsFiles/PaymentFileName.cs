﻿using Microsoft.VisualBasic;
using NPOI.POIFS.Crypt;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ValueObjects.PaymentsFiles
{
	public partial record PaymentFileName
	{
		public PaymentFileName(List<PaymentFileSetting> paymentFileSettings)
		{
			Prefijo = paymentFileSettings!.Find(c => c.Nombre == "prefijoArchivo")?.Valor!;
			FormatoFecha = paymentFileSettings!.Find(c => c.Nombre == "formatoNombreFecha")?.Valor!;
			RutaSftpHistoricoEnvio = paymentFileSettings.Find(c => c.Nombre == "rutaFTPHistoricoEnvio")?.Valor!;
			RangoHorario = paymentFileSettings!.Find(c => c.Nombre == "rangoHorario")!;
			Nomenclatura = paymentFileSettings!.Find(c => c.Nombre == "nomenclatura")?.Valor!;
			Extension = paymentFileSettings!.Find(c => c.Nombre == "extensionArchivo")?.Valor!;
			FormatoCorrelativo = paymentFileSettings!.Find(c => c.Nombre == "formatoCorrelativo")?.Valor!;
            FormatoPagoMasivo = paymentFileSettings!.Find(c => c.Nombre == "formatoPagoMasivo")?.Valor!;
            CodigoIdentificador = paymentFileSettings!.Find(c => c.Nombre == "codigoIdentificador")?.Valor!;
            

            DateTime utcNow = DateTime.UtcNow;
			TimeZoneInfo tz = TimeZoneInfo.FindSystemTimeZoneById("SA Pacific Standard Time");
			DateTime dateFile = TimeZoneInfo.ConvertTimeFromUtc(utcNow, tz);

			TimeSpan finalHour = TimeSpan.Parse(RangoHorario.HoraFin!);

			if (dateFile.TimeOfDay > finalHour)
			{
				dateFile = dateFile.AddDays(1);
				FechaPagoPosterior = true;
			}

			FechaPago = dateFile;
		}
		public string Prefijo { get; set; } = string.Empty;
		public string FormatoFecha { get; set; } = string.Empty;
		public string RutaSftpHistoricoEnvio { get; set; } = string.Empty;
		public PaymentFileSetting RangoHorario { get; set; } = new();
		public string Nomenclatura { get; set; } = string.Empty;
		public string Extension { get; set; } = string.Empty;
		public string FormatoCorrelativo { get; set; } = string.Empty;
		public string FormatoPagoMasivo { get; set; } = string.Empty;

        public DateTime FechaPago { get; set; }
		public bool FechaPagoPosterior { get; set; }
		public int Correlativo { get; set; }
		public string NombreArchivo { get; set; } = string.Empty;

		public string CodigoIdentificador { get; set; } = string.Empty;


        public string GetPathFileNameNomenclature(int correlative,string cod_money, int cod_paymentmassive)
		{

            string nomenclatureOrigin = Nomenclatura;
			//Dictionary Value for FileName   
			var keyValues = new Dictionary<string, string>
			{
				{ "prefix", Prefijo },
				{ "country", "PE" },
				{ "date", FechaPago.ToString(FormatoFecha) },
				{ "correlative", correlative.ToString(FormatoCorrelativo) },
				{ "code", CodigoIdentificador },
                { "money", cod_money },
				{ "paymentmasive", cod_paymentmassive.ToString(FormatoPagoMasivo) }
            };

			foreach (var key in keyValues.Keys)
			{ 
				Nomenclatura = Nomenclatura.Replace($"{{{key}}}", keyValues[key]);
			}



			NombreArchivo = $"{Nomenclatura}.{Extension}";

			Nomenclatura = nomenclatureOrigin;
			return $"{RutaSftpHistoricoEnvio}{NombreArchivo}";
		}
	}
}

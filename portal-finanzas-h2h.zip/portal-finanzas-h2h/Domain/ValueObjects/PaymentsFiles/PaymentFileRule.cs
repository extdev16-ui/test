using System.Text.Json.Serialization;

namespace Domain.ValueObjects.PaymentsFiles;

public partial record PaymentFileRule
{
    public PaymentFileRule() { }

    [JsonPropertyName("campo")]
    public string? Campo { get; init; }
    [JsonPropertyName("tipo")]
    public string? Tipo { get; init; }
    [JsonPropertyName("minimo")]
    public int? Minimo { get; init; }
    [JsonPropertyName("maximo")]
    public int? Maximo { get; init; }
    [JsonPropertyName("longitudMaxima")]
    public int? LongitudMaxima { get; init; }
    [JsonPropertyName("longitudMinima")]
    public int? LongitudMinima { get; init; }
    [JsonPropertyName("formato")]
    public string? Formato { get; init; }
    [JsonPropertyName("formatoFecha")]
    public string? FormatoFecha { get; init; }
    [JsonPropertyName("longitudCuentaAhorro")]
    public int? LongitudCuentaAhorro { get; init; }
    [JsonPropertyName("longitudCuentaCorriente")]
    public int? LongitudCuentaCorriente { get; init; }
	[JsonPropertyName("data")]
	public string? Data { get; init; }
}
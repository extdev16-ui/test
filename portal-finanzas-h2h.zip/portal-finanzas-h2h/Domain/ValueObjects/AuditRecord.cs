namespace Domain.ValueObjects;

public partial record AuditRecord
{
    public AuditRecord(string usuarioCreador, string hostCreador, string appCreador)
    {
        UsuarioCreador = usuarioCreador;
        HostCreador = hostCreador;
        AppCreador = appCreador;
    }

    public AuditRecord(string usuarioActualizador, string hostActualizador, string appActualizador, DateTime fechaActualizacion)
    {
        UsuarioActualizador = usuarioActualizador;
        HostActualizador = hostActualizador;
        AppActualizador = appActualizador;
        FechaActualizacion = fechaActualizacion;
    }

    public AuditRecord()
    {

    }

	public bool Activo { get; init; } = true;
    public string UsuarioCreador { get; init; } = string.Empty;
    public string UsuarioActualizador { get; set; } = string.Empty;
    public string HostCreador { get; init; } = string.Empty;
    public string HostActualizador { get; set; } = string.Empty;
    public DateTime FechaCreacion { get; init; } = DateTime.Now;
    public DateTime FechaActualizacion { get; set; } = DateTime.Now;
    public string AppCreador { get; init; } = string.Empty;
    public string AppActualizador { get; set; } = string.Empty;

    public static AuditRecord? Create(string usuarioCreador, string hostCreador, string appCreador)
    {
        if (string.IsNullOrEmpty(usuarioCreador) || string.IsNullOrEmpty(hostCreador) ||
            string.IsNullOrEmpty(appCreador))
        {
            return null;
        }

        return new AuditRecord(usuarioCreador, hostCreador, appCreador);
    }

    public static AuditRecord? Update(string usuarioActualizador, string hostActualizador, string appActualizador, DateTime? fechaActualizacion)
    {
        if (string.IsNullOrEmpty(usuarioActualizador) || string.IsNullOrEmpty(hostActualizador) ||
            string.IsNullOrEmpty(appActualizador) || fechaActualizacion is null)
        {
            return null;
        }

        return new AuditRecord(usuarioActualizador, hostActualizador, appActualizador, fechaActualizacion.GetValueOrDefault());
    }
}
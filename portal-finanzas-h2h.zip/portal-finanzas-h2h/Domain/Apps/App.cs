using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.Apps;

public sealed class App : AggregateRoot{
    
    public App(string nombre, string descripcion, AuditRecord registroAuditoria)
    {
        Nombre = nombre;
        Descripcion = descripcion;
        RegistroAuditoria = registroAuditoria;
    }

    private App()
    {
        
    }

    public int Id { get; set;}
    public string Nombre  { get; set; } = string.Empty;
    public string Descripcion  { get; set; } = string.Empty;
    public AuditRecord RegistroAuditoria { get; set; }
}
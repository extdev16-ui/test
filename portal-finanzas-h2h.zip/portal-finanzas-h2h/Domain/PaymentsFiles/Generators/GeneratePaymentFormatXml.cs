﻿using System.Xml.Linq;
using Domain.MassivesPayments.Common;
using Domain.ValueObjects.PaymentsFiles;
using Domain.PaymentsSettings;
using System.Text;
using System.Xml;
using System.Data.SqlTypes;
using Domain.Common;
using NPOI.HPSF;
using static Domain.Common.Constants;
using Domain.PaymentsOrders;
using NPOI.POIFS.Properties;
using static Org.BouncyCastle.Bcpg.Attr.ImageAttrib;

namespace Domain.PaymentsFiles.Generators;

public class GeneratePaymentFormatXml : IPaymentFileGenerator<PaymentFileFormatXml>
{
	public string GenerateContent(MassivePaymentResponse massivePaymentResponse, PaymentSetting paymentSettings, string fileName, DateTime datePayment, PaymentOrder paymentOrder)
	{
		List<PaymentFileFormatXml>? paymentFormat = paymentSettings.DetalleFormatoXml ?? null;

		if (paymentFormat is null)
		{
			throw new ArgumentNullException(nameof(paymentFormat));
		}


        var configurationPayment = massivePaymentResponse.ConfiguracionPago;

        XNamespace xsi = "http://www.w3.org/2001/XMLSchema-instance";
        XNamespace ns = "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03";

        var document = new XDocument(
            new XDeclaration("1.0", "UTF-8", "yes"),
            new XElement(ns + "Document",
                new XAttribute(XNamespace.Xmlns + "xsi", xsi)
            )
        );

        if (Constants.ConfigurationFormatXML.ConfigurationPaymentBBVA.Contains(configurationPayment))
        {
            foreach (var format in paymentFormat)
            {
                if (format.Repetible.GetValueOrDefault())
                {
                    XElement parent = GetParentNode(document, format, ns);
                    int correlativeDetails = 1;
                    foreach (var paymentDetail in massivePaymentResponse.Detalle)
                    {
                        XElement elementPayment = new(ns + "CdtTrfTxInf");

                        foreach (var item in format.Items!)
                        {
                            paymentDetail.ConfiguracionPago = massivePaymentResponse.ConfiguracionPago;
                            paymentDetail.Correlativo = correlativeDetails;
                            paymentDetail.FechaPago = massivePaymentResponse.FechaPago;
                            paymentDetail.IdPagoMasivo = massivePaymentResponse.IdPagoMasivo;
                            string value = GetValueDetailFromResponseBBVA(paymentDetail, item);
                            string[] nodosRoute = [.. item.Ruta.Split('.')];
                            XElement parentNode = elementPayment;

                            foreach (var nodo in nodosRoute.Take(nodosRoute.Length - 1))
                            {
                                XElement? existingNode = parentNode.Element(ns + nodo);
                                if (existingNode == null)
                                {
                                    existingNode = new XElement(ns + nodo);
                                    parentNode.Add(existingNode);
                                }
                                parentNode = existingNode;
                            }

                            string nodeName = nodosRoute.Last();
                            XElement element = new(ns + nodeName, value);

                            if (item.Atributo != null)
                            {
                                string valueAttribute = string.Empty;

                                valueAttribute = value;

                                var paymentFileFormatXmlAttribute = new PaymentFileFormatXml
                                {
                                    Campo = item.ValorAtributo!,
                                    Ruta = item.Ruta!,
                                    ValorPorDefecto = item.ValorPorDefecto!,
                                    Atributo = item.Atributo!
                                };

                                valueAttribute = GetValueFromResponseBBVA(massivePaymentResponse, paymentFileFormatXmlAttribute);

                                element.SetAttributeValue(paymentFileFormatXmlAttribute.Atributo, valueAttribute);
                            }

                            parentNode.Add(element);
                        }
                        correlativeDetails++;

                        parent.Add(elementPayment);

                    }
                }
                else
                {
                    XElement parent = GetParentNode(document, format, ns);
                    string value = GetValueFromResponseBBVA(massivePaymentResponse, format);
                    XElement element = new(ns + format.Ruta.Split('.').Last(), value);
                    parent.Add(element);
                }
            }
        }
        else if (Constants.ConfigurationFormatXML.ConfigurationPaymentIBK.Contains(configurationPayment))
        {
            string CategoryCode = paymentSettings.DetalleConfiguraciones!.Find(c => c.Nombre == "codigoRubro")?.Valor!;
            string CompanyCode = paymentSettings.DetalleConfiguraciones!.Find(c => c.Nombre == "codigoEmpresa")?.Valor!;
            string MoneyCode = massivePaymentResponse.CodigoMoneda.Substring(massivePaymentResponse.CodigoMoneda.Length - 2);
            string BICOrBEI = CategoryCode + CompanyCode + MoneyCode;
            string Identification = CategoryCode + CompanyCode + MoneyCode;

            var cstmrCdtTrfInitn = new XElement(ns + "CstmrCdtTrfInitn");

            document.Root!.Add(cstmrCdtTrfInitn);

            var format_head = paymentFormat.Where(t => t.Nivel == "1");
            var format_payment_lote = paymentFormat.Where(t => t.Nivel == "2" || t.Nivel == "3");

            //building header of xml:
            var grpHdr = new XElement(ns + "GrpHdr");

            foreach (var row in format_head) {
                if (row.Repetible.GetValueOrDefault())
                {
                    XElement parent = GetParentNode(document, row, ns);
                    int correlativeDetails = 1;
                    var lote = new MassivePaymentByPassResponse();
                    foreach (var paymentDetail in massivePaymentResponse.Detalle)
                    {
                        XElement elementPayment = new(ns + "CdtTrfTxInf");

                        foreach (var item in row.Items!)
                        {
                            paymentDetail.ConfiguracionPago = massivePaymentResponse.ConfiguracionPago;
                            paymentDetail.Correlativo = correlativeDetails;
                            paymentDetail.FechaPago = massivePaymentResponse.FechaPago;
                            paymentDetail.IdPagoMasivo = massivePaymentResponse.IdPagoMasivo;
                            string value = GetValueDetailFromResponseIBK(massivePaymentResponse, item, paymentOrder, lote, fileName);

                            string[] nodosRoute = [.. item.Ruta.Split('.')];
                            XElement parentNode = elementPayment;

                            foreach (var nodo in nodosRoute.Take(nodosRoute.Length - 1))
                            {
                                XElement? existingNode = parentNode.Element(ns + nodo);
                                if (existingNode == null)
                                {
                                    existingNode = new XElement(ns + nodo);
                                    parentNode.Add(existingNode);
                                }
                                parentNode = existingNode;
                            }

                            string nodeName = nodosRoute.Last();
                            XElement element = new(ns + nodeName, value);

                            if (item.Atributo != null)
                            {
                                string valueAttribute = string.Empty;

                                valueAttribute = value;

                                var paymentFileFormatXmlAttribute = new PaymentFileFormatXml
                                {
                                    Campo = item.ValorAtributo!,
                                    Ruta = item.Ruta!,
                                    ValorPorDefecto = item.ValorPorDefecto!,
                                    Atributo = item.Atributo!
                                };

                                valueAttribute = GetValueFromResponseIBK(massivePaymentResponse, item, fileName, BICOrBEI, Identification, datePayment);

                                element.SetAttributeValue(paymentFileFormatXmlAttribute.Atributo, valueAttribute);
                            }

                            parentNode.Add(element);
                        }
                        correlativeDetails++;

                        grpHdr.Add(elementPayment);

                    }
                }
                else
                {
                    string value = GetValueFromResponseIBK(massivePaymentResponse, row, fileName, BICOrBEI, Identification, datePayment);
                    string[] nodosRoute = row.Ruta.Split('.');
                    XElement parentNode = grpHdr;

                    foreach (var nodo in nodosRoute.Take(nodosRoute.Length - 1))
                    {
                        XElement? existingNode = parentNode.Element(ns + nodo);
                        if (existingNode == null)
                        {
                            existingNode = new XElement(ns + nodo);
                            parentNode.Add(existingNode);
                        }
                        parentNode = existingNode;
                    }

                    string nodeName = nodosRoute.Last();
                    XElement element = new(ns + nodeName, value);
                    parentNode.Add(element);
                }
            }
            cstmrCdtTrfInitn.AddFirst(grpHdr);

            var details_payments = massivePaymentResponse.Detalle;

            var tipos_abono = details_payments.Select(t => t.TipoAbono)
                                                .Distinct().ToList();

            var lotes_agrupados = new List<MassivePaymentByPassResponse>();

            foreach (var item in tipos_abono)
            {
                var x = new MassivePaymentByPassResponse
                {
                    TipoAbono = item,
                    Detalle = massivePaymentResponse.Detalle.Where(t=>t.TipoAbono == item).ToList()
                };

                lotes_agrupados.Add(x); 
            }

            //builder lote of xml for total typepayment:
            //For TRF:
            if (tipos_abono.Contains(Constants.TypeDestinyPayment.Self))
            {
                var detalle_transferencia = massivePaymentResponse.Detalle.Where(t => t.TipoAbono == Constants.TypeDestinyPayment.Self).ToList();
                var lote = lotes_agrupados.Where(t => t.TipoAbono == Constants.TypeDestinyPayment.Self).First();
                XElement pmtInf = new(ns + "PmtInf");

                foreach (var row in format_payment_lote)
                {              
                    if (row.Repetible.GetValueOrDefault())
                    {
                        int correlativeDetails = 1;
                        foreach (var paymentDetail in detalle_transferencia)
                        {
                            XElement elementPayment = new(ns + "CdtTrfTxInf");

                            foreach (var item in row.Items!)
                            {
                                paymentDetail.ConfiguracionPago = massivePaymentResponse.ConfiguracionPago;
                                paymentDetail.Correlativo = correlativeDetails;
                                paymentDetail.FechaPago = massivePaymentResponse.FechaPago;
                                paymentDetail.IdPagoMasivo = massivePaymentResponse.IdPagoMasivo;
                                string value = GetValueDetailPaymentsFromResponseIBK(massivePaymentResponse, paymentDetail,item, datePayment);
                                string[] nodosRoute = [.. item.Ruta.Split('.')];
                                XElement parentNode = elementPayment;

                                foreach (var nodo in nodosRoute.Take(nodosRoute.Length - 1))
                                {
                                    XElement? existingNode = parentNode.Element(ns + nodo);
                                    if (existingNode == null)
                                    {
                                        existingNode = new XElement(ns + nodo);
                                        parentNode.Add(existingNode);
                                    }
                                    parentNode = existingNode;
                                }

                                string nodeName = nodosRoute.Last();
                                XElement element = new(ns + nodeName, value);

                                if (item.Atributo != null)
                                {
                                    string valueAttribute = string.Empty;

                                    valueAttribute = value;

                                    var paymentFileFormatXmlAttribute = new PaymentFileFormatXml
                                    {
                                        Campo = item.ValorAtributo!,
                                        Ruta = item.Ruta!,
                                        ValorPorDefecto = item.ValorPorDefecto!,
                                        Atributo = item.Atributo!
                                    };

                                    valueAttribute = GetValueDetailPaymentsFromResponseIBK(massivePaymentResponse, paymentDetail, paymentFileFormatXmlAttribute, datePayment);

                                    element.SetAttributeValue(paymentFileFormatXmlAttribute.Atributo, valueAttribute);
                                }

                                parentNode.Add(element);
                            }
                            

                            pmtInf.Add(elementPayment);
                            correlativeDetails++;

                        }
                    }
                    else
                    {
                        string value = GetValueDetailFromResponseIBK(massivePaymentResponse, row, paymentOrder, lote, fileName);

                        string[] nodosRoute = row.Ruta.Split('.');
                        XElement parentNode = pmtInf;

                        foreach (var nodo in nodosRoute.Take(nodosRoute.Length - 1))
                        {
                            XElement? existingNode = parentNode.Element(ns + nodo);
                            if (existingNode == null)
                            {
                                existingNode = new XElement(ns + nodo);
                                parentNode.Add(existingNode);
                            }
                            parentNode = existingNode;
                        }

                        string nodeName = nodosRoute.Last();
                        XElement element = new(ns + nodeName, value);
                        parentNode.Add(element);
                    }
                }
                cstmrCdtTrfInitn.Add(pmtInf);
            }

            //For EXT:
            if (tipos_abono.Contains(Constants.TypeDestinyPayment.Interbank))
            {
                var detalle_transferencia = massivePaymentResponse.Detalle.Where(t => t.TipoAbono == Constants.TypeDestinyPayment.Interbank).ToList();
                var lote = lotes_agrupados.Where(t => t.TipoAbono == Constants.TypeDestinyPayment.Interbank).First();
                XElement pmtInf = new(ns + "PmtInf");
                foreach (var row in format_payment_lote)
                {
                    if (row.Repetible.GetValueOrDefault())
                    {
                        int correlativeDetails = 1;
                        foreach (var paymentDetail in detalle_transferencia)
                        {
                            XElement elementPayment = new(ns + "CdtTrfTxInf");

                            foreach (var item in row.Items!)
                            {
                                paymentDetail.ConfiguracionPago = massivePaymentResponse.ConfiguracionPago;
                                paymentDetail.Correlativo = correlativeDetails;
                                paymentDetail.FechaPago = massivePaymentResponse.FechaPago;
                                paymentDetail.IdPagoMasivo = massivePaymentResponse.IdPagoMasivo;
                                string value = GetValueDetailPaymentsFromResponseIBK(massivePaymentResponse, paymentDetail, item, datePayment);
                                string[] nodosRoute = [.. item.Ruta.Split('.')];
                                XElement parentNode = elementPayment;

                                foreach (var nodo in nodosRoute.Take(nodosRoute.Length - 1))
                                {
                                    XElement? existingNode = parentNode.Element(ns + nodo);
                                    if (existingNode == null)
                                    {
                                        existingNode = new XElement(ns + nodo);
                                        parentNode.Add(existingNode);
                                    }
                                    parentNode = existingNode;
                                }

                                string nodeName = nodosRoute.Last();
                                XElement element = new(ns + nodeName, value);

                                if (item.Atributo != null)
                                {
                                    string valueAttribute = string.Empty;

                                    valueAttribute = value;

                                    var paymentFileFormatXmlAttribute = new PaymentFileFormatXml
                                    {
                                        Campo = item.ValorAtributo!,
                                        Ruta = item.Ruta!,
                                        ValorPorDefecto = item.ValorPorDefecto!,
                                        Atributo = item.Atributo!
                                    };

                                    valueAttribute = GetValueDetailPaymentsFromResponseIBK(massivePaymentResponse, paymentDetail, paymentFileFormatXmlAttribute, datePayment);

                                    element.SetAttributeValue(paymentFileFormatXmlAttribute.Atributo, valueAttribute);
                                }

                                parentNode.Add(element);
                            }

                            pmtInf.Add(elementPayment); 
                            correlativeDetails++;

                        }
                    }
                    else
                    {
                        string value = GetValueDetailFromResponseIBK(massivePaymentResponse, row, paymentOrder, lote, fileName);
                        string[] nodosRoute = row.Ruta.Split('.');
                        XElement parentNode = pmtInf;

                        foreach (var nodo in nodosRoute.Take(nodosRoute.Length - 1))
                        {
                            XElement? existingNode = parentNode.Element(ns + nodo);
                            if (existingNode == null)
                            {
                                existingNode = new XElement(ns + nodo);
                                parentNode.Add(existingNode);
                            }
                            parentNode = existingNode;
                        }

                        string nodeName = nodosRoute.Last();
                        XElement element = new(ns + nodeName, value);
                        parentNode.Add(element);
                    }
                }
                cstmrCdtTrfInitn.Add(pmtInf);
            }

        }


            var settings = new XmlWriterSettings
			{
				Encoding = new UTF8Encoding(false),
				Indent = true,
				OmitXmlDeclaration = false,
				NewLineChars = "\n"
			};



		// Usamos StringWriter para almacenar el contenido
		using (var sw = new StringWriter())
		using (var writer = XmlWriter.Create(sw, settings))
		{
			document.Save(writer);  // Guardar el documento XML
			writer.Flush();  // Asegurarse de vaciar el XmlWriter

			// Retornar el contenido como un string

			return sw.ToString().Replace("encoding=\"utf-16\"", "encoding=\"utf-8\"");
		}
	}

	private static XElement GetParentNode(XDocument document, PaymentFileFormatXml formatXml, XNamespace ns)
	{
		string[] path = formatXml.Ruta.Split('.');
		XElement parent = document.Root!;

		foreach (var node in path.Skip(1).Take(path.Length - (formatXml.Repetible.GetValueOrDefault() ? 0 : 2)))
		{
			XElement? existingElement = parent.Element(ns + node);
			if (existingElement == null)
			{
				existingElement = new(ns + node);
				parent.Add(existingElement);
			}
			parent = existingElement;
		}
		return parent;
	}

	private static string GetValueFromResponseBBVA(MassivePaymentResponse paymentMassiveResponse, PaymentFileFormatXml paymentFileFormatXml) => paymentFileFormatXml.Campo switch
	{
		"Correlative" => paymentMassiveResponse.IdOrdenPago.ToString("000000"), //AGREGAR FORMATO DE JSON BD
		"CreatedDate" => DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"), //AGREGAR FORMATO DE JSON BD
		"HashAuth" => paymentMassiveResponse.FirmaDigital,
		"NumberOfTransactions" => paymentMassiveResponse.Detalle.Count.ToString(),
		"TotalAmount" => paymentMassiveResponse.Detalle.Sum(d => d.Monto).ToString("F2"),//AGREGAR FORMATO DE JSON BD
		"CompanyName" => paymentFileFormatXml.ValorPorDefecto ?? "CORPORACION TURISTICA PERUANA S.A.C",
		"CompanyDocument" => paymentFileFormatXml.ValorPorDefecto ?? "20265815830",
		"CompanyType" => paymentFileFormatXml.ValorPorDefecto ?? "TXID",
		"CompanyOther" => paymentFileFormatXml.ValorPorDefecto ?? "20265815830 - CORPORACION TURISTICA PERUANA S.A.C",
		"BatchId" => paymentFileFormatXml.ValorPorDefecto ?? "0001",
		"PaymentMethod" => paymentFileFormatXml.ValorPorDefecto ?? "TRF",
		"PurposePayment" => paymentFileFormatXml.ValorPorDefecto ?? "SUPP",
		"PaymentDate" => paymentMassiveResponse.FechaPago.ToString("yyyy-MM-dd"), //AGREGAR FORMATO DE JSON BD
		"DebtorAccount" => paymentMassiveResponse.SetDebtorAccount(),
		"CurrencyAccount" => paymentMassiveResponse.GetCurrency(),
		"DebtorCountry" => paymentFileFormatXml.ValorPorDefecto ?? "PE",
		_ => string.Empty
	};

    private static string GetValueFromResponseIBK(MassivePaymentResponse paymentMassiveResponse, PaymentFileFormatXml paymentFileFormatXml, string fileName, string BICOrBEI, string Identification, DateTime datePayment) => paymentFileFormatXml.Campo switch
    {
        "MessageIdentification" => fileName, //Nombre de Archivo con nomenglatura
        "CreatedDate" => datePayment.ToString("yyyy-MM-ddTHH:mm:ss"), //AGREGAR FORMATO DE JSON BD
        "NumberOfTransactions" => paymentMassiveResponse.Detalle.Count.ToString(),
        "TotalAmount" => paymentMassiveResponse.Detalle.Sum(d => d.Monto).ToString("F2"),//AGREGAR FORMATO DE JSON BD
        "CompanyName" => paymentFileFormatXml.ValorPorDefecto ?? "CORPORACION TURISTICA PERUANA S.A.C",
        "Identification" => Identification,
        "BICOrBEI" => BICOrBEI,
        "HashAuth" => paymentMassiveResponse.FirmaDigital,
        "CompanyOther" => paymentFileFormatXml.ValorPorDefecto ?? "20265815830 - CORPORACION TURISTICA PERUANA S.A.C",
        "BatchId" => paymentFileFormatXml.ValorPorDefecto ?? "0001",
        "PaymentMethod" => paymentFileFormatXml.ValorPorDefecto ?? "TRF",
        "PurposePayment" => paymentFileFormatXml.ValorPorDefecto ?? "SUPP",
        "PaymentDate" => paymentMassiveResponse.FechaPago.ToString("yyyy-MM-dd"), //AGREGAR FORMATO DE JSON BD
        "DebtorAccount" => paymentMassiveResponse.SetDebtorAccount(),
        "CurrencyAccount" => paymentMassiveResponse.GetCurrency(),
        "DebtorCountry" => paymentFileFormatXml.ValorPorDefecto ?? "PE",
        _ => string.Empty
    };


    private static string GetValueDetailFromResponseBBVA(MassivePaymentDetailResponse paymentMassiveDetailResponse, PaymentFileFormatXml paymentFileFormatXml)
	{
		return paymentFileFormatXml.Campo switch
		{
			"TransacctionCode" => string.Concat(paymentMassiveDetailResponse.Correlativo.ToString("000"), "-", paymentMassiveDetailResponse.CodigoUnico, "-", paymentMassiveDetailResponse.NumeroDocumento),
			"TransacctionId" => paymentMassiveDetailResponse.CodigoUnico,
			"TransacctionAmount" => paymentMassiveDetailResponse.Monto.ToString("F2"),
			"TransacctionCountry" => paymentFileFormatXml.ValorPorDefecto ?? "PE",
			"BeneficiaryName" => paymentMassiveDetailResponse.NombreBeneficiario,
			"BeneficiaryDocument" => paymentMassiveDetailResponse.NumeroDocumento,
			"BeneficiaryDocumentType" => paymentMassiveDetailResponse.GetDocumentType(paymentMassiveDetailResponse.ConfiguracionPago),
			"BeneficiaryAccount" => paymentMassiveDetailResponse.GetBeneficiaryAccount(paymentMassiveDetailResponse.ConfiguracionPago),
			"PaymentReference" => $"Referencia Pago {paymentMassiveDetailResponse.FechaPago:yyyyMMdd}-{paymentMassiveDetailResponse.IdPagoMasivo}-{paymentMassiveDetailResponse.Correlativo.ToString("000")}",
			_ => string.Empty
		};
	}

    private static string GetValueDetailFromResponseIBK(MassivePaymentResponse paymentMassiveResponse, PaymentFileFormatXml paymentFileFormatXml, PaymentOrder paymentOrder,MassivePaymentByPassResponse massivePaymentByPassResponse, string fileName)
    {

        string[] partes = fileName.Split('_');
        string codigo = partes[0].Substring(partes[0].IndexOf("CODE"));

        return paymentFileFormatXml.Campo switch
        {
            "PaymentInformationIdentification" => codigo,
            "PaymentMethod" => massivePaymentByPassResponse.GetTypePass(),
            "InstructionPriority" => paymentFileFormatXml.ValorPorDefecto ?? "NORM",
            "PurposePayment" => paymentFileFormatXml.ValorPorDefecto ?? "SUPP",
            "PaymentDate" => paymentOrder.FechaPago.ToString("yyyy-MM-dd"),
            "CompanyName" => paymentFileFormatXml.ValorPorDefecto ?? "CORPORACION TURISTICA PERUANA S.A.C",
            "Department" => paymentFileFormatXml.ValorPorDefecto ?? "LIMA",
            "StreetName" => paymentFileFormatXml.ValorPorDefecto ?? "Av. Benavides Nro. 430 Res. Miraflores",
            "TownName" => paymentFileFormatXml.ValorPorDefecto ?? "MIRAFLORES",
            "CountrySubDivision" => paymentFileFormatXml.ValorPorDefecto ?? "LIMA",
            "Country" => paymentFileFormatXml.ValorPorDefecto ?? "PE",
            "AddressLine" => paymentFileFormatXml.ValorPorDefecto ?? "Av. Benavides Nro. 430 Res. Miraflores",
            "Identification" => paymentFileFormatXml.ValorPorDefecto ?? "20265815830",
            "Other" => paymentFileFormatXml.ValorPorDefecto ?? "TXID",
            "CompanyOther" => paymentFileFormatXml.ValorPorDefecto ?? "1",
            "DebtorAccount" => paymentMassiveResponse.SetDebtorAccount(),
            "CurrencyAccount" => paymentMassiveResponse.GetCurrency(),
            "BIC" => paymentFileFormatXml.ValorPorDefecto ?? "BINPPEPL",
            "DebtorCountry" => paymentFileFormatXml.ValorPorDefecto ?? "PE",
            _ => string.Empty
        };
    }

    private static string GetValueDetailPaymentsFromResponseIBK(MassivePaymentResponse paymentMassiveResponse,MassivePaymentDetailResponse paymentMassiveDetailResponse, PaymentFileFormatXml paymentFileFormatXml, DateTime datePayment)
    {
        string rawCodigo = paymentMassiveDetailResponse.CodigoUnico;
        string codigo_unico = rawCodigo.Contains(".") ? rawCodigo.Substring(rawCodigo.IndexOf('.') + 1) : rawCodigo;
        string format_account_beneciario = paymentMassiveDetailResponse.CuentaBeneficiario.Trim().Replace("-", "");

        return paymentFileFormatXml.Campo switch
        {
            "InstructionIdentification" => codigo_unico,
            "EndToEndIdentification" => codigo_unico,
            "InstructedAmount" => paymentMassiveDetailResponse.Monto.ToString("F2"),
            "CurrencyAccount" => paymentMassiveResponse.NomenclaturaMoneda,
            "BeneficiaryName" => paymentMassiveDetailResponse.NombreBeneficiario.Trim().Replace(" ", ";"),
            "BeneficiaryDocument" => (paymentMassiveDetailResponse.TipoDocumento.Substring(0, 1)+"/"+ paymentMassiveDetailResponse.NumeroDocumento) ?? "",
            "PhoneNumber" => paymentFileFormatXml.ValorPorDefecto ?? " ",
            "EmailAddress" => paymentFileFormatXml.ValorPorDefecto ?? " ",
            "Identification" => format_account_beneciario ?? "",
            "Code" => paymentFileFormatXml.ValorPorDefecto ?? "CINV",
            "Number" => codigo_unico,
            "DateDocument" => datePayment.ToString("yyyy-MM-dd"),
            "DuePayableAmount" => paymentMassiveDetailResponse.Monto.ToString("F2"),
            _ => string.Empty
        };
    }
}

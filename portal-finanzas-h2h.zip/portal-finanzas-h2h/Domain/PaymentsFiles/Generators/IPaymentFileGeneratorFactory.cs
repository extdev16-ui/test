﻿using Domain.MassivesPayments.Common;
using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using Domain.ValueObjects.PaymentsFiles;

namespace Domain.PaymentsFiles.Generators;

public interface IPaymentFileGeneratorFactory
{
	Task<string> GenerateContent(MassivePaymentResponse massivePaymentResponse, PaymentSetting paymentSettings, string fileName, DateTime datePayment, PaymentOrder paymentOrder);
}

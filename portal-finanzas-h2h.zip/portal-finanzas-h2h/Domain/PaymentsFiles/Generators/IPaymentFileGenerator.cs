﻿using Domain.MassivesPayments.Common;
using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using Domain.ValueObjects.PaymentsFiles;

namespace Domain.PaymentsFiles.Generators;

public interface IPaymentFileGenerator<T>
{
	string GenerateContent(MassivePaymentResponse massivePaymentResponse, PaymentSetting paymentSettings, string fileName, DateTime datePayment, PaymentOrder paymentOrder);
}
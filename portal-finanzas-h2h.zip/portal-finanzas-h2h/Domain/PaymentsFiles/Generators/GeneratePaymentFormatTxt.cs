﻿using Domain.PaymentsFiles.Helpers;
using Domain.ValueObjects.PaymentsFiles; 
using System.Text;
using Domain.MassivesPayments.Common;
using Domain.PaymentsSettings;
using ErrorOr;
using Domain.Common;
using Domain.PaymentsOrders;

namespace Domain.PaymentsFiles.Generators;

public class GeneratePaymentFormatTxt : IPaymentFileGenerator<PaymentFileFormatTxt>
{
	public static int totalDigitalControl = 0;
	public static string rootModule = string.Empty;

	public string GenerateContent(MassivePaymentResponse massivePaymentResponse, PaymentSetting paymentSettings, string fileName, DateTime datePayment, PaymentOrder paymentOrder)
	{
		List<PaymentFileFormatTxt>? paymentFormat = paymentSettings.DetalleFormatoTxt ?? null;

		if (paymentFormat is null)
		{
			throw new ArgumentNullException(nameof(paymentFormat));
		}

		totalDigitalControl = 0;
		var stringBuilder = new StringBuilder();

		foreach (var massivePaymentDetailResponse in massivePaymentResponse.Detalle)
		{
			stringBuilder.AppendLine(GenerateLine(massivePaymentResponse, massivePaymentDetailResponse, paymentFormat.FindAll(c => c.Totales is null)).Value);
		}

		if (paymentFormat.Any(x => x.Totales is not null))
			stringBuilder.AppendLine(GenerateTotalLine(massivePaymentResponse, massivePaymentResponse.Detalle, paymentFormat.FindAll(c => c.Totales is not null)).Value);

		return stringBuilder.ToString();
	}

	private static ErrorOr<string> GenerateTotalLine(MassivePaymentResponse massivePaymentResponse, List<MassivePaymentDetailResponse> massivePaymentDetailResponse, List<PaymentFileFormatTxt> paymentFormats)
	{
		var paymentFormatInitialMax = paymentFormats.Where(c => c.Totales.GetValueOrDefault()).MaxBy(c => c.Inicio)!;

		var line = new char[(paymentFormatInitialMax.Inicio + paymentFormatInitialMax.Longitud) - 1];

		foreach (var paymentFormat in paymentFormats)
		{
			string value = string.Empty;

			switch (paymentFormat.Campo)
			{
				case "finArchivo":
					value = paymentFormat.ValorPorDefecto;
					break;
				case "cantidadRegistros":
					value = massivePaymentDetailResponse.Count.ToString(new string('0', paymentFormat.Longitud));
					break;
				case "importeTotal":
					value = massivePaymentDetailResponse.Sum(c => c.Monto).ToString("F2").Replace(".", "").PadLeft(paymentFormat.Longitud, '0');
					break;
				case "fechaOrdenPago":
					value = massivePaymentResponse.FechaPago.ToString(paymentFormat.FormatoFecha);
					break;
				case "sumatoriaDigitoControl":
					value = totalDigitalControl.ToString(new string('0', paymentFormat.Longitud));
					break;
			}

			if (!string.IsNullOrEmpty(value))
			{
				value = PaymentFileHelper.TruncarYPad(value, paymentFormat.Longitud);
				value.CopyTo(0, line, paymentFormat.Inicio - 1, paymentFormat.Longitud);
			}
		}

		return new string(line).Replace('\0', ' ');
	}
	private static ErrorOr<string> GenerateLine(MassivePaymentResponse massivePaymentResponse, MassivePaymentDetailResponse massivePaymentDetailResponse, List<PaymentFileFormatTxt> paymentFormats)
	{
		var paymentFormatInitialMax = paymentFormats.Where(c => c.Obligatorio.GetValueOrDefault()).MaxBy(c => c.Inicio)!;

		var line = new char[(paymentFormatInitialMax.Inicio + paymentFormatInitialMax.Longitud) - 1];

		massivePaymentDetailResponse.ModuloRaiz = 0;

		foreach (var paymentFormat in paymentFormats)
		{
			string value = GetFieldValue(massivePaymentResponse, massivePaymentDetailResponse, paymentFormat);

			if (!string.IsNullOrEmpty(value))
			{
				value = PaymentFileHelper.TruncarYPad(value, paymentFormat.Longitud);
				value.CopyTo(0, line, paymentFormat.Inicio - 1, paymentFormat.Longitud);

				if (paymentFormat.Campo == "moduloRaiz")
					massivePaymentDetailResponse.ModuloRaiz = int.Parse(value);
			}
		}

		return new string(line).Replace('\0', ' ');
	}
	private static string GetFieldValue(MassivePaymentResponse massivePaymentResponse, MassivePaymentDetailResponse massivePaymentDetailResponse, PaymentFileFormatTxt paymentFormat)
	{
		string result = string.Empty;

		switch (paymentFormat.Campo)
		{
			case "tipoOrden":
				result = paymentFormat.ValorPorDefecto;
				break;
			case "referencia1":
				result = massivePaymentDetailResponse.IdPagoMasivo.ToString();
				break;
			case "referencia2":
				result = massivePaymentDetailResponse.CodigoUnico;
				break;
			case "moneda":
				result = massivePaymentResponse.CodigoMoneda == Constants.PaymentFileCurrency.PEN ? "00" : "01";
				break;
			case "cuentaCargo":
				result = massivePaymentResponse.SetDebtorAccount();
				break;
			case "fechaOrdenPago":
				result = DateTime.Now.ToString(paymentFormat.FormatoFecha);
				break;
			case "documentoBeneficiario":
				result = massivePaymentDetailResponse.NumeroDocumento;
				break;
			case "nombreBeneficiario":
				{
					string nameBeneficiary = massivePaymentDetailResponse.TransformSpecialCharacters(massivePaymentDetailResponse.NombreBeneficiario);

					result = nameBeneficiary.Length >= 60
						? nameBeneficiary[..60]
						: nameBeneficiary;
					break;
				}
			case "formaPago":
				result = massivePaymentDetailResponse.TipoCuenta;
				break;
			case "cuentaAbonar":
				{
					string typeAccount = "";
					switch (massivePaymentDetailResponse.TipoCuenta)
					{
						case "3":
							if (massivePaymentResponse.CodigoMoneda == Constants.PaymentFileCurrency.PEN)
								typeAccount = paymentFormat.CuentaAhorroSoles;
							else
								typeAccount = paymentFormat.CuentaAhorroDolares;
							break;
						case "2":
							if (massivePaymentResponse.CodigoMoneda == Constants.PaymentFileCurrency.PEN)
								typeAccount = paymentFormat.CuentaCorrienteSoles;
							else
								typeAccount = paymentFormat.CuentaCorrienteDolares;

							break;
					}
					result = string.Concat(massivePaymentDetailResponse.CuentaBeneficiario.Substring(3, 7), massivePaymentDetailResponse.CuentaBeneficiario[..3], typeAccount);
					break;
				}
			case "importeNeto":
				result = massivePaymentDetailResponse.Monto.ToString("F2").Replace(".", "").PadLeft(paymentFormat.Longitud, '0');
				break;
			case "moduloRaiz":
				{
					if (string.IsNullOrEmpty(rootModule))
					{
						result = paymentFormat.ValorPorDefecto;
						rootModule = result;
					}
					else
					{
						result = rootModule;
					}
				}

				break;
			case "digitoControl":
				{
					var calculateControlDigitRequest = new CalculateControlDigitRequest(
						massivePaymentDetailResponse.ModuloRaiz,
						Constants.AGREEMENT_NUMBER,
						int.Parse(massivePaymentResponse.FechaPago.ToString("yyMMdd")),
						(int)massivePaymentDetailResponse.Monto,
						int.Parse(massivePaymentResponse.CodigoMoneda == Constants.PaymentFileCurrency.PEN ? "00" : "01"),
						int.Parse(massivePaymentDetailResponse.TipoCuenta),
						int.Parse(massivePaymentDetailResponse.GetBeneficiaryAccount(massivePaymentResponse.ConfiguracionPago)),
						massivePaymentResponse.GetDebtorAccount()
						);

					int resultCalculate = CalculateDigitControlRecord(calculateControlDigitRequest);
					result = resultCalculate.ToString("00");
					break;
				}
			case "signo":
				result = paymentFormat.ValorPorDefecto;
				break;
			case "referenciaPago":
				result = string.Concat(massivePaymentResponse.IdPagoMasivo.ToString(), " ", massivePaymentDetailResponse.TransformSpecialCharacters(massivePaymentDetailResponse.NombreBeneficiario).Substring(0, 3));
				break;
			default:
				result = string.Empty;
				break;

		}
		return result;
	}
	private static int CalculateDigitControlRecord(CalculateControlDigitRequest calculateControlDigitRequest)
	{
		string numberString = calculateControlDigitRequest.TotalSum.ToString();

		int factor = 0;
		int sumProduct = 0;
		for (int i = 0; i < numberString.Length; i++)
		{
			factor = i + 1;
			sumProduct += factor * int.Parse(numberString[i].ToString());
		}

		int rootModuleCalculate = !string.IsNullOrEmpty(rootModule) ? int.Parse(rootModule) : calculateControlDigitRequest.RootModule;

		int residue = sumProduct % rootModuleCalculate;
		int result = rootModuleCalculate - residue;

		int resultDigitTwoFormat = int.Parse(PaymentFileHelper.DigitTwoFormat(result));

		totalDigitalControl += resultDigitTwoFormat;

		return resultDigitTwoFormat;
	}

}

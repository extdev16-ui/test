using Domain.PaymentsFiles.Models;

namespace Domain.PaymentsFiles.Interfaces;

public interface IPaymentFileWriteRepository
{
    void Add(PaymentFile paymentFile);
    void Update(PaymentFile paymentFile);
	Task<int> GetHigherCode(DateTime dateNow, int idPaymentSetting, string type);
	Task<List<PaymentFile>?> GetByPaymentOrder(int idPaymentOrder, string type);
    Task<PaymentFile?> GetByMassivePayment(int idMassivePayment, string type);
	Task<PaymentFile?> GetById(int id);
}
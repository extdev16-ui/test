using Domain.PaymentsFiles.Models;

namespace Domain.PaymentsFiles.Interfaces;

public interface IPaymentFileReadRepository
{
    Task<List<PaymentFile>> GetByFileNames(string fileNames);
}
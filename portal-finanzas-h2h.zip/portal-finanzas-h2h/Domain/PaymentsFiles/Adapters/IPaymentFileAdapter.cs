﻿using Domain.PaymentsFiles.Models;

namespace Domain.PaymentsFiles.Adapter;

public interface IPaymentFileAdapter
{
	PaymentFileTxtScotiabank? AdaptStringToScotiabankTxt(string txtContent);
	PaymentFileXmlBBVA? AdaptStringToBBVAXml(string xmlContent);
	PaymentFileXmlIBK? AdaptStringToIBKXml(string xmlContent);
}
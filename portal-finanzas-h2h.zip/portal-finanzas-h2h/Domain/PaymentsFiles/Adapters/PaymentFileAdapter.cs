﻿
using System.Xml.Serialization;
using Domain.PaymentsFiles.Adapter;
using Domain.PaymentsFiles.Models;
namespace Domain.PaymentsFiles.Adapters;

public class PaymentFileAdapter : IPaymentFileAdapter
{
    public PaymentFileTxtScotiabank? AdaptStringToScotiabankTxt(string txtContent)
    {
        throw new NotImplementedException();
    }

    public PaymentFileXmlBBVA? AdaptStringToBBVAXml(string xmlContent)
    {
        var serializer = new XmlSerializer(typeof(PaymentFileXmlBBVA), "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03");

        using var reader = new StringReader(xmlContent);
        return (PaymentFileXmlBBVA?)serializer.Deserialize(reader);
    }

    public PaymentFileXmlIBK? AdaptStringToIBKXml(string xmlContent)
    {
        var serializer = new XmlSerializer(typeof(PaymentFileXmlIBK), "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03");

        using var reader = new StringReader(xmlContent);
        return (PaymentFileXmlIBK?)serializer.Deserialize(reader);
    }
}

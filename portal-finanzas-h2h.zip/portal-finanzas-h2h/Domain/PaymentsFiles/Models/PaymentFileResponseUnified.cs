using Domain.PaymentsOrdersDetails.Common;

namespace Domain.PaymentsFiles.Models;

public record PaymentFileResponseUnified
{

    public PaymentFileResponseUnified(string fileName, string fileContent)
    {
        FileName = fileName;
        FileContent = fileContent;
    }
    public PaymentFileResponseUnified()
    {

    }
    public string FileName { get; set; } = string.Empty;
    public string FileContent { get; set; } = string.Empty;
    public int IdMassivePayment { get; set; }
    public int IdPaymentOrder { get; set; }
    public int Index { get; set; }
    public bool IsRead { get; set; } = true;
	public bool NotFound { get; private set; }
	public int IdFileType { get; set; }
    public string FileType { get; set; } = string.Empty;
    public int FileOrder { get; set; }
    public List<PaymentOrderDetailDto> Details { get; set; } = [];

    public PaymentFileSetContentResponse PaymentFileContentResponse { get; set; } = new PaymentFileSetContentResponse();

    public void SetNotFound()
    {
        NotFound = true;
    }

	public void SetFileTypeNotImplement()
	{
		FileType = "NO IMPLEMENTADO";
	}
};


using System.Xml.Serialization;

namespace Domain.PaymentsFiles.Models;

[XmlRoot(ElementName = "Document", Namespace = "urn:iso:std:iso:20022:tech:xsd:pain.002.001.03")]
public class PaymentFileXmlBBVA
{
    [XmlElement("CstmrPmtStsRpt")]
    public CstmrPmtStsRpt CstmrPmtStsRpt { get; set; } = new();
}

public class CstmrPmtStsRpt
{
    [XmlElement("GrpHdr")]
    public GrpHdr GrpHdr { get; set; } = new();

    [XmlElement("OrgnlGrpInfAndSts")]
    public OrgnlGrpInfAndSts OrgnlGrpInfAndSts { get; set; } = new();

    [XmlElement("OrgnlPmtInfAndSts")]
    public OrgnlPmtInfAndSts? OrgnlPmtInfAndSts { get; set; }
}

public class GrpHdr
{
    public string MsgId { get; set; } = string.Empty;
    public string CreDtTm { get; set; } = string.Empty;
    public InitgPty? InitgPty { get; set; }
}

public class InitgPty
{
    public string Nm { get; set; } = string.Empty;
}


public class OrgnlGrpInfAndSts
{
    public string OrgnlMsgId { get; set; } = string.Empty;
    public string OrgnlMsgNmId { get; set; } = string.Empty;
    public string OrgnlCreDtTm { get; set; } = string.Empty;
    public string GrpSts { get; set; } = string.Empty;
    public StsRsnInf StsRsnInf { get; set; } = new();
    [XmlElement("NbOfTxsPerSts")]
    public NbOfTxsPerSts? NbOfTxsPerSts { get; set; }
}

public class OrgnlPmtInfAndSts
{
    public string OrgnlPmtInfId { get; set; } = string.Empty;
    public int OrgnlNbOfTxs { get; set; }
    public decimal OrgnlCtrlSum { get; set; }
    public string PmtInfSts { get; set; } = string.Empty;
    [XmlElement("NbOfTxsPerSts")]
    public NbOfTxsPerSts? NbOfTxsPerSts { get; set; }
    [XmlElement("TxInfAndSts")]
    public List<TxInfAndSts> TxInfAndSts { get; set; } = [];
}

public class NbOfTxsPerSts
{
    public int DtldNbOfTxs { get; set; }
    public string DtldSts { get; set; } = string.Empty;
    public decimal DtldCtrlSum { get; set; }
}
public class TxInfAndSts
{
    public string StsId { get; set; } = string.Empty;
    public string OrgnlInstrId { get; set; } = string.Empty;
    public string OrgnlEndToEndId { get; set; } = string.Empty;
    public string TxSts { get; set; } = string.Empty;
    [XmlElement("StsRsnInf")]
    public StsRsnInf? StsRsnInf { get; set; }

    [XmlElement("OrgnlTxRef")]
    public OrgnlTxRef OrgnlTxRef { get; set; } = new();
}

public class StsRsnInf
{
    [XmlElement("Rsn")]
    public Rsn? Rsn { get; set; }
    [XmlElement("AddtlInf")]
    public List<string> AddtlInf { get; set; } = [];
}
public class OrgnlTxRef
{
    [XmlElement("Amt")]
    public Amt Amt { get; set; } = new();
    public string ReqdExctnDt { get; set; } = string.Empty;
    [XmlElement("Dbtr")]
    public Dbtr Dbtr { get; set; } = new();
    [XmlElement("DbtrAcct")]
    public DbtrAcct DbtrAcct { get; set; } = new();
    [XmlElement("Cdtr")]
    public Cdtr Cdtr { get; set; } = new();
}

public class Rsn
{
    public string Prtry { get; set; } = string.Empty;
    public string Cd { get; set; } = string.Empty;
}

public class Amt
{
    public decimal InstdAmt { get; set; }
}
public class Dbtr
{
    public string Nm { get; set; } = string.Empty;
}

public class DbtrAcct
{
    [XmlElement("Id")]
    public DbtrAcctId DbtrAcctId { get; set; } = new();
}

public class DbtrAcctId
{
    [XmlElement("Othr")]
    public DbtrAcctIdOthr DbtrAcctIdOthr { get; set; } = new();
}

public class DbtrAcctIdOthr
{
    public string Id { get; set; } = string.Empty;
}
public class Cdtr
{
    public string Nm { get; set; } = string.Empty;
}
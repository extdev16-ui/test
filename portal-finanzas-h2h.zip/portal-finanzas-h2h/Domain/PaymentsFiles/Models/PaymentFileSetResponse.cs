﻿using Domain.ValueObjects;
namespace Domain.PaymentsFiles.Models;


public record PaymentFileSetResponse
{
    public PaymentFileSetResponse(int idPaymentOrderDetail, int idPaymentOrder, string uniqueCode, int idMassivePayment, decimal netAmount, string codeAnswer, string descriptionAnswer, string timePayment, AuditRecord auditRecord)
    {
        IdPaymentOrderDetail = idPaymentOrderDetail;
        IdPaymentOrder = idPaymentOrder;
        UniqueCode = uniqueCode;
        IdMassivePayment = idMassivePayment;
        NetAmount = netAmount;
        CodeAnswer = codeAnswer;
        DescriptionAnswer = descriptionAnswer;
        TimePayment = timePayment;
        AuditRecord = auditRecord;

    }

    public PaymentFileSetResponse(int idPaymentOrderDetail, int idPaymentOrder, string uniqueCode, int idMassivePayment, string descriptionAnswer, AuditRecord auditRecord, string codeAnswer)
    {
        IdPaymentOrderDetail = idPaymentOrderDetail;
        IdPaymentOrder = idPaymentOrder;
        UniqueCode = uniqueCode;
        IdMassivePayment = idMassivePayment;
        CodeAnswer = codeAnswer;
        DescriptionAnswer = descriptionAnswer;
        AuditRecord = auditRecord;
    }
    public int IdPaymentOrderDetail { get; set; }
    public int IdPaymentOrder { get; set; }
    public string UniqueCode { get; set; } = string.Empty;
    public int IdMassivePayment { get; set; }
    public decimal NetAmount { get; set; }
    public string CodeAnswer { get; set; } = string.Empty;
    public string DescriptionAnswer { get; set; } = string.Empty;
    public AuditRecord AuditRecord { get; set; }
    public string DescriptionError { get; set; } = string.Empty;
    public string TimePayment { get; set; } = string.Empty;
}
using Domain.Catalogs;
using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using Domain.Primitives;
using Domain.ValueObjects;
using Domain.ValueObjects.PaymentsFiles;
using System.Reflection.Metadata;

namespace Domain.PaymentsFiles.Models;

public sealed class PaymentFile : AggregateRoot
{

    public PaymentFile(string nombre, DateTime fecha, int idCatalogoEstado, Catalog catalogoTipo, string ruta, int idConfiguracionPago, int idOrdenPago, AuditRecord registroAuditoria)
    {
        Nombre = nombre;
        Fecha = fecha;
        IdCatalogoEstado = idCatalogoEstado;
        IdCatalogoTipo = catalogoTipo.Id;

        switch (catalogoTipo.Codigo)
        {
            case Common.Constants.PaymentFileType.SEND:
                RutaEnvioHistorico = ruta;
                break;
            case Common.Constants.PaymentFileType.RESPONSE:
                RutaRespuesta = ruta;
                break;
        }

        IdConfiguracionPago = idConfiguracionPago;
        RegistroAuditoria = registroAuditoria;
        IdOrdenPago = idOrdenPago;
    }

    public PaymentFile(string nombre, DateTime fecha, int idCatalogoEstado, Catalog catalogoTipo, string ruta, int idConfiguracionPago, int idOrdenPago, int orden, AuditRecord registroAuditoria)
    {
        Nombre = nombre;
        Fecha = fecha;
        IdCatalogoEstado = idCatalogoEstado;
        IdCatalogoTipo = catalogoTipo.Id;

        switch (catalogoTipo.Codigo)
        {
            case Common.Constants.PaymentFileType.SEND:
                RutaEnvioHistorico = ruta;
                break;
            case Common.Constants.PaymentFileType.RESPONSE:
                RutaRespuesta = ruta;
                break;
            case Common.Constants.PaymentFileType.VOUCHER:
                RutaRespuesta = ruta;
                break;
        }

        IdConfiguracionPago = idConfiguracionPago;
        RegistroAuditoria = registroAuditoria;
        IdOrdenPago = idOrdenPago;
        Orden = orden;
    }

    public PaymentFile(int id)
    {
        Id = id;
    }
    public PaymentFile(int id, string ruta, int idCatalogoEstado)
    {
        Id = id;
        RutaEnvio = RutaEnvio;
        IdCatalogoEstado = idCatalogoEstado;
    }

    public PaymentFile()
    {

    }

    public int Id { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string RutaEnvio { get; set; } = string.Empty;
    public string RutaEnvioHistorico { get; set; } = string.Empty;
    public string RutaRespuesta { get; set; } = string.Empty;
    public string RutaRespuestaHistorica { get; set; } = string.Empty;
    public DateTime Fecha { get; set; }
    public int IdCatalogoEstado { get; set; }
    public Catalog CatalogoEstado { get; set; }
    public int IdCatalogoTipo { get; set; }
    public Catalog CatalogoTipo { get; set; }
    public int IdConfiguracionPago { get; set; }
    public PaymentSetting ConfiguracionPago { get; set; }
    public int IdOrdenPago { get; set; }
    public PaymentOrder OrdenPago { get; set; }
    public byte[] ArchivoByte { get; set; }
    public int Orden { get; set; }
    public string ContentType { get; set; } = string.Empty;
    public string ContentDisposition { get; set; } = string.Empty;
    public AuditRecord RegistroAuditoria { get; set; }

    public bool CanUpdateState(string newStatus, out string? errorMessage)
    {

        if (string.IsNullOrEmpty(newStatus))
        {
            errorMessage = "Error, debe ingresar el estado";
            return false;
        }

        if (int.TryParse(CatalogoEstado.Codigo, out int currentStatus))
        {
            int nextStatus = currentStatus + 1;

            if (newStatus == nextStatus.ToString("000"))
            {
                errorMessage = null;
                return true;
            }
            else
            {
                errorMessage = "Error, el estado a actualizar es el mismo o uno anterior al actual estado del archivo de pago.";
                return false;
            }
        }
        else
        {
            errorMessage = "Error al convertir el estado actual del archivo a un valor num�rico.";
            return false;
        }
    }
    public string GetDownloadRoute(string fileType)
    {
        if (fileType == Common.Constants.PaymentFileType.SEND)
        {
            return RutaEnvioHistorico;
        }
        else
        {
            return RutaRespuestaHistorica;
        }
    }

    public string GetFileName(string fileName, string paymentSettingCode, string typeFile)
    {
        ContentType = "text/plain";
        ContentDisposition = "attachment";

        string fileNameResult = string.Empty;
        switch (paymentSettingCode)
        {
            case Common.Constants.PaymentSettings.H2H_SCOTIABANK_PV:
                {
                    fileNameResult = fileName;
                }
                break;
            case Common.Constants.PaymentSettings.H2H_BBVA_PP:
                {
                    fileNameResult = fileName;

                    if (typeFile == Common.Constants.PaymentFileType.VOUCHER && fileName.Contains(".pdf."))
                    {
                        fileNameResult = fileNameResult.Replace(".CAN", "");
                        ContentType = "application/pdf";
                        ContentDisposition = "inline";
                    }
                }
                break;
            case Common.Constants.PaymentSettings.H2H_IBK_PP:
                {
                    fileNameResult = fileName; 
                } 
                break;
            default:
                {
                    throw new NotImplementedException();
                }
        }

        return fileNameResult;
    }


    public string CreatePathHistoricalResponse(string fileName)
    {
        if (!string.IsNullOrEmpty(RutaRespuestaHistorica))
        {
            DateTime currentDate = DateTime.Now;
            return string.Concat(RutaRespuestaHistorica, @$"{currentDate:yyyy}/{currentDate:MM}/{fileName}");
        }
        return string.Empty;
    }

}
using Domain.Common;

namespace Domain.PaymentsFiles.Models;
public record PaymentFileSetContentResponse
{
    public List<PaymentFileSetResponse> ResponseSuccesses { get; set; } = [];
    public List<PaymentFileSetResponse> ResponseFailures { get; set; } = [];
    public List<PaymentFileSetResponse> ResponseErrors { get; set; } = [];

    public string StatusPaymentOrder
    {
        get
        {
            bool existSuccess = ResponseSuccesses.Count > 0;
            bool existFailure = ResponseFailures.Count > 0;
            bool existError = ResponseErrors.Count > 0;

            if (existSuccess && !existFailure && !existError)
                return Constants.PaymentOrderStatus.FULLYPAID;

            //Update Status Pay partial
            if (existSuccess && (existError || existFailure))
                return Constants.PaymentOrderStatus.PARTIALLYPAID;

            //Update Status Pay Error
            if (!existSuccess && (existError || existFailure))
                return Constants.PaymentOrderStatus.ERROR;

            return Constants.PaymentOrderStatus.CONFIRMED;
        }
    }
    public bool NotExistResponse
    {
        get
        {
            bool existSuccess = ResponseSuccesses.Count > 0;
            bool existFailure = ResponseFailures.Count > 0;
            bool existError = ResponseErrors.Count > 0;

            if (!existSuccess && !existFailure && !existError)
                return true;
            else
                return false;
        }
    }

};
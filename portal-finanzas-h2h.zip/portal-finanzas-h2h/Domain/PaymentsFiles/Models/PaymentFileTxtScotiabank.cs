namespace Domain.PaymentsFiles.Models;
public class PaymentFileTxtScotiabank
{
    public string Content { get; set; } = string.Empty;
}

namespace Domain.PaymentsFiles.Models;

public record PaymentFileResponse
{

    public PaymentFileResponse(string fileName, string fileContent)
    {
        FileName = fileName;
        FileContent = fileContent;
    }
    public PaymentFileResponse()
    {

    }
    public string FileName { get; set; } = string.Empty;
    public string FileContent { get; set; } = string.Empty;
    public int IdMassivePayment { get; set; }
    public int IdPaymentOrder { get; set; }

    public PaymentFileSetContentResponse PaymentFileContentResponse { get; set; } = new PaymentFileSetContentResponse();
};
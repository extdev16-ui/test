using System.Xml.Serialization;

namespace Domain.PaymentsFiles.Models;
[XmlRoot(ElementName = "Document", Namespace = "urn:iso:std:iso:20022:tech:xsd:pain.002.001.03")]

public class PaymentFileXmlIBK
{
    [XmlElement("CstmrPmtStsRpt")]
    public CstmrPmtStsRptIBK CstmrPmtStsRpt { get; set; } = new();
}

public class CstmrPmtStsRptIBK
{
    [XmlElement("GrpHdr")]
    public GrpHdrIBK GrpHdr { get; set; } = new();

    [XmlElement("OrgnlGrpInfAndSts")]
    public OrgnlGrpInfAndStsIBK OrgnlGrpInfAndSts { get; set; } = new();

    [XmlElement("OrgnlPmtInfAndSts")]
    public OrgnlPmtInfAndStsIBK? OrgnlPmtInfAndSts { get; set; }
}


#region GrpHdr
public class GrpHdrIBK
{
    public string MsgId { get; set; } = string.Empty;
    public string CreDtTm { get; set; } = string.Empty;
    public InitgPtyIBK? InitgPty { get; set; }
}

public class InitgPtyIBK
{
    public string Nm { get; set; } = string.Empty;
}

#endregion

#region OrgnlGrpInfAndSts

public class OrgnlGrpInfAndStsIBK
{
    public string OrgnlMsgId { get; set; } = string.Empty;
    public string OrgnlMsgNmId { get; set; } = string.Empty;
    public string OrgnlCreDtTm { get; set; } = string.Empty;
    public int OrgnlNbOfTxs { get; set; }   
    public decimal OrgnlCtrlSum {  get; set; }
    public string GrpSts { get; set; } = string.Empty;

    [XmlElement("NbOfTxsPerSts")]
    public NbOfTxsPerStsIBK? NbOfTxsPerSts { get; set; }
}

public class NbOfTxsPerStsIBK
{
    public int DtldNbOfTxs { get; set; }
    public string DtldSts { get; set; } = string.Empty;
    public decimal DtldCtrlSum { get; set; }
}

#endregion

#region OrgnlPmtInfAndSts

public class OrgnlPmtInfAndStsIBK
{
    public string OrgnlPmtInfId { get; set; } = string.Empty;
    public string PmtInfSts { get; set; } = string.Empty;
    
    [XmlElement("NbOfTxsPerSts")]
    public NbOfTxsPerStsIBK? NbOfTxsPerSts { get; set; }

    [XmlElement("TxInfAndSts")]
    public List<TxInfAndStsIBK> TxInfAndSts { get; set; } = [];
}

public class TxInfAndStsIBK
{
    public string StsId { get; set; } = string.Empty;
    public string OrgnlInstrId { get; set; } = string.Empty;
    public string OrgnlEndToEndId { get; set; } = string.Empty;
    public string TxSts { get; set; } = string.Empty;
	[XmlElement("StsRsnInf")]
	public StsRsnInf? StsRsnInf { get; set; }

	[XmlElement("OrgnlTxRef")]
    public OrgnlTxRefIBK OrgnlTxRef { get; set; } = new();
}

public class OrgnlTxRefIBK
{
    [XmlElement("Amt")]
    public AmtIBK Amt { get; set; } = new();
    public string ReqdExctnDt { get; set; } = string.Empty;
    [XmlElement("Dbtr")]
    public DbtrIBK Dbtr { get; set; } = new();
    [XmlElement("DbtrAcct")]
    public DbtrAcctIBK DbtrAcct { get; set; } = new();
    [XmlElement("Cdtr")]
    public CdtrIBK Cdtr { get; set; } = new();
}

public class AmtIBK
{
    public decimal InstdAmt { get; set; }
}

public class DbtrIBK
{
    public string Nm { get; set; } = string.Empty;
}

public class DbtrAcctIBK
{
    [XmlElement("Id")]
    public DbtrAcctIdIBK DbtrAcctId { get; set; } = new();
}


public class DbtrAcctIdIBK
{
    [XmlElement("Othr")]
    public DbtrAcctIdOthrIBK DbtrAcctIdOthr { get; set; } = new();
}

public class DbtrAcctIdOthrIBK
{
    public string Id { get; set; } = string.Empty;
}
public class CdtrIBK
{
    public string Nm { get; set; } = string.Empty;
}

#endregion
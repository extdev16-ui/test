﻿using Domain.PaymentsFiles.Models;
using Domain.PaymentsSettings;
namespace Domain.PaymentsFiles.ResponseGet;

public interface IPaymentFileResponseGetterFactory 
{
	PaymentFileResponseUnified? GetResponse(PaymentFileResponseUnified paymentResponseFile, PaymentSetting paymentSetting);
}
﻿using Domain.PaymentsFiles.Models;
using Domain.PaymentsOrdersDetails.Common;
using Domain.PaymentsSettings;
using Domain.ValueObjects;
using Domain.ValueObjects.PaymentsFiles;
using Domain.PaymentsFiles.Adapter;
using static Domain.Common.Constants;
using System.Linq;
using Domain.PaymentsOrdersDetails;
using NPOI.XWPF.UserModel;

namespace Domain.PaymentsFiles.ResponseGet;

public class PaymentFileXmlResponseReader(IPaymentFileAdapter paymentFileAdapter) : IPaymentFileResponseGetter<PaymentFileFormatXml>
{
	private readonly IPaymentFileAdapter _paymentFileAdapter = paymentFileAdapter;

	public PaymentFileResponseUnified? GetResponse(PaymentFileResponseUnified paymentFileResponseUnified, PaymentSetting paymentSetting)
	{
		PaymentFileResponseUnified? paymentFileResponseUnifiedResult = null;

		//Step 1: Get and Validate Payment Format
		List<PaymentFileFormatXml>? paymentSettingFormat = paymentSetting.DetalleFormatoXml ?? null;

		if (paymentSettingFormat is null || paymentSettingFormat.Count == 0)
		{
			throw new ArgumentNullException(nameof(paymentSettingFormat));
		}

		//Step 1: Set paymentFileResponseUnified to paymentFileResponseUnifiedResult
		if (paymentFileResponseUnified is null)
		{
			throw new ArgumentNullException(nameof(paymentFileResponseUnified));
		}

		//Step 2: Get and Validate Content File
		string stringsContent = paymentFileResponseUnified.FileContent;

		if (string.IsNullOrEmpty(stringsContent))
		{
			throw new ArgumentNullException(nameof(stringsContent));
		}

		switch (paymentSetting.Codigo)
		{
			case PaymentSettings.H2H_BBVA_PP:
				{
					paymentFileResponseUnifiedResult = ReadBBVA(stringsContent, paymentFileResponseUnified, paymentSetting);

				}
				break;
			case PaymentSettings.H2H_IBK_PP:
				{
					paymentFileResponseUnifiedResult = ReadIBK(stringsContent, paymentFileResponseUnified, paymentSetting);
				}
				break;
			default: throw new ArgumentException($"No se tiene soporte de lectura de XML para el codigo de banco {paymentSetting.Codigo}.");
		}

		return paymentFileResponseUnifiedResult;
	}

	#region READ BBVA
	private PaymentFileResponseUnified? ReadBBVA(string stringsContent, PaymentFileResponseUnified paymentFileResponseUnified, PaymentSetting paymentSetting)
	{
		PaymentFileResponseUnified? paymentFileResponseUnifiedResult = paymentFileResponseUnified;
		PaymentFileXmlBBVA? paymentFileXml = _paymentFileAdapter.AdaptStringToBBVAXml(stringsContent);

		if (paymentFileXml is null)
		{
			throw new ArgumentNullException(nameof(paymentFileXml));
		}

		switch (paymentFileResponseUnified.FileOrder)
		{
			case TypePaymentFileResponseBBVA.GLOBAL:
				{
					paymentFileResponseUnifiedResult = GetResponseGlobal(paymentFileResponseUnified, paymentFileXml);
				}
				break;
			case TypePaymentFileResponseBBVA.STRUCTURE:
				{
					paymentFileResponseUnifiedResult = GetResponseStructure(paymentFileResponseUnified, paymentFileXml, paymentSetting);
				}
				break;
			case TypePaymentFileResponseBBVA.TRANSACTION:
				{
					paymentFileResponseUnifiedResult = GetResponseTransaction(paymentFileResponseUnified, paymentFileXml);
				}
				break;
			default: throw new ArgumentException($"Solo se tiene soporte de lectura para máximo {PaymentResponseFileLimits.H2H_BBVA_PP} archivos de respuestas, Codigo de Banco: {paymentSetting.Codigo}.");
		}

		return paymentFileResponseUnifiedResult;
	}

	private static PaymentFileResponseUnified? GetResponseGlobal(PaymentFileResponseUnified paymentFileResponseUnified, PaymentFileXmlBBVA paymentFileXml)
	{
		PaymentFileResponseUnified? paymentFileResponseUnifiedResult = null;

		paymentFileResponseUnifiedResult = paymentFileResponseUnified;

		if (StatusResponseGlobalBBVA.STATUS.Contains(paymentFileXml.CstmrPmtStsRpt.OrgnlGrpInfAndSts.GrpSts)
			&& paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts is null
			&& paymentFileXml.CstmrPmtStsRpt.OrgnlGrpInfAndSts.NbOfTxsPerSts is null)
		{
			if (paymentFileXml.CstmrPmtStsRpt.OrgnlGrpInfAndSts.GrpSts == StatusResponseGlobalBBVA.ERROR)
			{
				return SetAllPaymentFilesAsError(TypePaymentFileResponseBBVA.STRUCTURE, paymentFileResponseUnified.Details, paymentFileResponseUnifiedResult);
			}
			else
			{
				paymentFileResponseUnifiedResult.IsRead = false;
			}
		}
		else
		{
			throw new NotImplementedException("El archivo de respuesta global no tiene el formato correcto.");
		}

		return paymentFileResponseUnified;
	}

	private static PaymentFileResponseUnified? GetResponseStructure(PaymentFileResponseUnified paymentFileResponseUnified, PaymentFileXmlBBVA paymentFileXml, PaymentSetting paymentSetting)
	{
		PaymentFileResponseUnified? paymentFileResponseUnifiedResult = null;

		paymentFileResponseUnifiedResult = paymentFileResponseUnified;

		if (paymentFileXml.CstmrPmtStsRpt.OrgnlGrpInfAndSts.NbOfTxsPerSts is not null
			&& paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts is not null
			&& StatusResponseStructureBBVA.STATUS.Contains(paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts.PmtInfSts))
		{
			//Step 1: Validate for head
			if (paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts.PmtInfSts == StatusResponseStructureBBVA.ERROR)
			{
				return SetAllPaymentFilesAsError(TypePaymentFileResponseBBVA.STRUCTURE, paymentFileResponseUnified.Details, paymentFileResponseUnifiedResult);
			}

			paymentFileResponseUnifiedResult = GetPaymentFileDetails(paymentFileResponseUnifiedResult, paymentFileXml);

			paymentFileResponseUnifiedResult.IsRead = false;

			int limit = int.Parse(paymentSetting.DetalleConfiguraciones!.Find(c => c.Nombre == "limiteRespuestas")?.Valor ?? "1");

			if (limit == 2)
			{
				paymentFileResponseUnifiedResult = GetPaymentFileDetails(paymentFileResponseUnifiedResult, paymentFileXml);
			}
		}
		else
		{
			throw new NotImplementedException("El archivo de respuesta de estructura no tiene el formato correcto.");
		}

		return paymentFileResponseUnified;
	}

	private static PaymentFileResponseUnified? GetResponseTransaction(PaymentFileResponseUnified paymentFileResponseUnified, PaymentFileXmlBBVA paymentFileXml)
	{
		PaymentFileResponseUnified? paymentFileResponseUnifiedResult = paymentFileResponseUnified;

		if (paymentFileXml.CstmrPmtStsRpt.OrgnlGrpInfAndSts.NbOfTxsPerSts is not null
			&& paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts is not null
			&& StatusResponseTransactionBBVA.STATUS.Contains(paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts.PmtInfSts))
		{
			//Step 1: Validate for head
			if (paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts.PmtInfSts == StatusResponseTransactionBBVA.ERROR)
			{
				return SetAllPaymentFilesAsError(TypePaymentFileResponseBBVA.TRANSACTION, paymentFileResponseUnified.Details, paymentFileResponseUnifiedResult);
			}

			//Step 2: Validate for details transaction
			paymentFileResponseUnifiedResult = GetPaymentFileDetails(paymentFileResponseUnifiedResult, paymentFileXml);
		}
		else
		{
			throw new NotImplementedException("El archivo de respuesta de transaction no tiene el formato correcto.");
		}

		return paymentFileResponseUnified;
	}

	private static PaymentFileResponseUnified SetAllPaymentFilesAsError(int typeResponse, List<PaymentOrderDetailDto> details, PaymentFileResponseUnified paymentFileResponseUnifiedRequest)
	{
		string descriptionError;
		PaymentFileResponseUnified paymentFileResponseUnifiedResult = paymentFileResponseUnifiedRequest;

		switch (typeResponse)
		{
			case TypePaymentFileResponseBBVA.GLOBAL:
				{
					descriptionError = "Error de global, No se pudo procesar el pago.";
				}
				break;
			case TypePaymentFileResponseBBVA.STRUCTURE:
				{
					descriptionError = "Error de estructura, No se pudo procesar el pago.";
				}
				break;
			case TypePaymentFileResponseBBVA.TRANSACTION:
				{
					descriptionError = "Error de transaccion, No se pudo procesar el pago.";
				}
				break;
			default: throw new NotImplementedException("No se soporta la implementación para este tipo de archivo de respuesta");
		}

		foreach (var paymentOrderDetailError in details)
		{
			paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseErrors.Add(new PaymentFileSetResponse(paymentOrderDetailError.Id, paymentFileResponseUnifiedResult.IdPaymentOrder, paymentOrderDetailError.CodigoUnico, paymentOrderDetailError.IdPagoMasivo, descriptionError, paymentOrderDetailError.RegistroAuditoria, StatusResponseDetailBBVA.PAYMENT_REJECTED));
		}

		paymentFileResponseUnifiedResult.IsRead = true;

		return paymentFileResponseUnifiedResult;
	}

	private static PaymentFileResponseUnified GetPaymentFileDetails(PaymentFileResponseUnified paymentFileResponseUnified, PaymentFileXmlBBVA paymentFileXmlBBVA)
	{
		PaymentFileResponseUnified paymentFileResponseUnifiedResult = paymentFileResponseUnified;
		List<TxInfAndSts> txInfAndSts = paymentFileXmlBBVA.CstmrPmtStsRpt.OrgnlPmtInfAndSts!.TxInfAndSts ?? throw new ArgumentException($"No se encontró el detalle de cada transacción de la orden de pago {paymentFileResponseUnifiedResult.IdMassivePayment}.");

		foreach (var item in txInfAndSts)
		{
			string uniqueCode = item.OrgnlEndToEndId;
			string codeAnswer = item.StsRsnInf != null ? item.StsRsnInf.Rsn != null ? item.StsRsnInf.Rsn.Cd : item.TxSts : item.TxSts;
			string descriptionAnswer = item.StsRsnInf != null ? item.StsRsnInf.AddtlInf.Count > 0 ? item.StsRsnInf.AddtlInf[0] : item.StsId : item.StsId;
			decimal netAmount = item.OrgnlTxRef.Amt.InstdAmt;

			if (!ValidateDetailsTransaction(uniqueCode, netAmount, codeAnswer, descriptionAnswer))
			{
				paymentFileResponseUnifiedResult.IsRead = true;
				throw new ArgumentException($"Error de transaccion, el detalle de transaccion esta imcompleto. {paymentFileResponseUnifiedResult.IdMassivePayment}.");
			}

			int IdPaymentOrderDetail = paymentFileResponseUnified.Details.Find(c => c.CodigoUnico == uniqueCode)!.Id;
			AuditRecord auditRecord = paymentFileResponseUnified.Details.Find(c => c.CodigoUnico == uniqueCode)!.RegistroAuditoria;

			if (item.TxSts == StatusResponseDetailBBVA.PAYMENT_ACCEPTED || item.TxSts == StatusResponseDetailBBVA.SUCCESS_STRUCTURE)
			{
				string dateTimePayment = descriptionAnswer[4..descriptionAnswer.IndexOf('/')];
				string timePayment = dateTimePayment.Split('T')[1];
				string timePaymentWithoutMillis = timePayment[..^4];

				paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseSuccesses.Add(
					new PaymentFileSetResponse(IdPaymentOrderDetail, paymentFileResponseUnified.IdPaymentOrder, uniqueCode, paymentFileResponseUnified.IdMassivePayment, netAmount, codeAnswer, string.Empty, timePaymentWithoutMillis, auditRecord));
			}
			else
			{
				paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseFailures.Add(
					new PaymentFileSetResponse(IdPaymentOrderDetail, paymentFileResponseUnified.IdPaymentOrder, uniqueCode, paymentFileResponseUnified.IdMassivePayment, netAmount, codeAnswer, descriptionAnswer, string.Empty, auditRecord));
			}
		}

		paymentFileResponseUnifiedResult.IsRead = true;

		return paymentFileResponseUnifiedResult;
	}
	private static bool ValidateDetailsTransaction(string uniqueCode, decimal netAmount, string codeAnswer, string descriptionAnswer)
	{
		if (string.IsNullOrEmpty(uniqueCode)
			|| string.IsNullOrEmpty(codeAnswer)
			|| string.IsNullOrEmpty(descriptionAnswer)
			|| netAmount == 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	#endregion;

	#region READ INTERBANK
	private PaymentFileResponseUnified? ReadIBK(string stringsContent, PaymentFileResponseUnified paymentFileResponseUnified, PaymentSetting paymentSetting)
	{
		PaymentFileResponseUnified? paymentFileResponseUnifiedResult = paymentFileResponseUnified;
		PaymentFileXmlIBK? paymentFileXml = _paymentFileAdapter.AdaptStringToIBKXml(stringsContent);

		if (paymentFileXml is null)
		{
			throw new ArgumentNullException(nameof(paymentFileXml));
		}

		switch (paymentFileResponseUnified.FileOrder)
		{
			case TypePaymentFileResponseIBK.STRUCTURE:
				{
					paymentFileResponseUnifiedResult = GetResponseStructureIBK(paymentFileResponseUnified, paymentFileXml, paymentSetting);
				}
				break;
			default: throw new ArgumentException($"Solo se tiene soporte de lectura para máximo {PaymentResponseFileLimits.H2H_IBK_PP} archivos de respuestas, Codigo de Banco: {paymentSetting.Codigo}.");
		}

		return paymentFileResponseUnifiedResult;
	}

	private static PaymentFileResponseUnified? GetResponseStructureIBK(PaymentFileResponseUnified paymentFileResponseUnified, PaymentFileXmlIBK paymentFileXml, PaymentSetting paymentSetting)
	{
		PaymentFileResponseUnified? paymentFileResponseUnifiedResult = null;
		int processOrdersSuccess = int.Parse(paymentSetting.DetalleConfiguraciones!.Find(c => c.Nombre == "procesarOrdenes")?.Valor ?? "0");

		if (processOrdersSuccess > 0)
		{
			paymentFileResponseUnifiedResult = GetPaymentFileDetailsIBKSuccess(paymentFileResponseUnified, paymentFileXml);
			return paymentFileResponseUnifiedResult;
		}

		paymentFileResponseUnifiedResult = paymentFileResponseUnified;				

		if (paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts is not null
			&& StatusResponseStructureIBK.STATUS.Contains(paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts.PmtInfSts))
		{
			//Step 1: Validate for head
			if (paymentFileXml.CstmrPmtStsRpt.OrgnlPmtInfAndSts.PmtInfSts == StatusResponseStructureIBK.ERROR)
			{
				return SetAllPaymentFilesAsErrorIBK(TypePaymentFileResponseIBK.STRUCTURE, paymentFileResponseUnified.Details, paymentFileResponseUnifiedResult);
			}

			//Step 2: Validate for details transaction
			paymentFileResponseUnifiedResult = GetPaymentFileDetailsIBK(paymentFileResponseUnifiedResult, paymentFileXml);

		}
		else
		{
			throw new NotImplementedException("El archivo de respuesta de estructura no tiene el formato correcto.");
		}

		return paymentFileResponseUnified;
	}


	private static PaymentFileResponseUnified SetAllPaymentFilesAsErrorIBK(int typeResponse, List<PaymentOrderDetailDto> details, PaymentFileResponseUnified paymentFileResponseUnifiedRequest)
	{
		string descriptionError;
		PaymentFileResponseUnified paymentFileResponseUnifiedResult = paymentFileResponseUnifiedRequest;

		switch (typeResponse)
		{
			case TypePaymentFileResponseIBK.STRUCTURE:
				{
					descriptionError = "Error de estructura, No se pudo procesar el pago.";
				}
				break;
			default: throw new NotImplementedException("No se soporta la implementación para este tipo de archivo de respuesta");
		}
		paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseErrors.AddRange(details.Select(paymentOrderDetailError => new PaymentFileSetResponse(paymentOrderDetailError.Id, paymentFileResponseUnifiedResult.IdPaymentOrder, paymentOrderDetailError.CodigoUnico, paymentOrderDetailError.IdPagoMasivo, descriptionError, paymentOrderDetailError.RegistroAuditoria, StatusResponseDetailIBK.PAYMENT_REJECTED)));
		paymentFileResponseUnifiedResult.IsRead = true;

		return paymentFileResponseUnifiedResult;
	}

	private static PaymentFileResponseUnified GetPaymentFileDetailsIBKSuccess(PaymentFileResponseUnified paymentFileResponseUnified, PaymentFileXmlIBK paymentFileXmlIBK)
	{
		PaymentFileResponseUnified paymentFileResponseUnifiedResult = paymentFileResponseUnified;		

		foreach (var paymentOrderDetailDto in paymentFileResponseUnified.Details)
		{

			paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseSuccesses.Add(
					new PaymentFileSetResponse(paymentOrderDetailDto.Id,
					paymentFileResponseUnified.IdPaymentOrder,
					paymentOrderDetailDto.CodigoUnico.Split('.')[^1],
					paymentFileResponseUnified.IdMassivePayment,
					decimal.Zero,
					StatusResponseDetailIBK.SUCCESS_STRUCTURE, string.Empty, DateTime.Now.ToString("HH:mm"), paymentOrderDetailDto.RegistroAuditoria));

		}

		paymentFileResponseUnifiedResult.IsRead = true;
		return paymentFileResponseUnifiedResult;

	}

	private static PaymentFileResponseUnified GetPaymentFileDetailsIBK(PaymentFileResponseUnified paymentFileResponseUnified, PaymentFileXmlIBK paymentFileXmlIBK)
	{
		PaymentFileResponseUnified paymentFileResponseUnifiedResult = paymentFileResponseUnified;
		List<TxInfAndStsIBK> txInfAndSts = paymentFileXmlIBK.CstmrPmtStsRpt.OrgnlPmtInfAndSts!.TxInfAndSts ?? throw new ArgumentException($"No se encontró el detalle de cada transacción de la orden de pago {paymentFileResponseUnifiedResult.IdMassivePayment}.");

		foreach (var item in txInfAndSts)
		{
			string uniqueCode = item.OrgnlEndToEndId;
			string codeAnswer = item.StsRsnInf != null ? item.StsRsnInf.Rsn != null ? item.StsRsnInf.Rsn.Prtry : item.TxSts : item.TxSts;
			string descriptionAnswer = item.StsRsnInf != null ? item.StsRsnInf.AddtlInf.Count > 0 ? item.StsRsnInf.AddtlInf[0] : item.StsId : item.StsId;
			decimal netAmount = item.OrgnlTxRef.Amt.InstdAmt;


			if (!ValidateDetailsTransactionIBK(uniqueCode, netAmount, codeAnswer, descriptionAnswer))
			{
				paymentFileResponseUnifiedResult.IsRead = true;
				throw new ArgumentException($"Error de transaccion, el detalle de transaccion esta imcompleto. {paymentFileResponseUnifiedResult.IdMassivePayment}.");
			}

			int IdPaymentOrderDetail = paymentFileResponseUnified.Details.Find(c => c.CodigoUnico.Split('.')[^1] == uniqueCode)!.Id;
			AuditRecord auditRecord = paymentFileResponseUnified.Details.Find(c => c.CodigoUnico.Split('.')[^1] == uniqueCode)!.RegistroAuditoria;

			if (item.TxSts == StatusResponseDetailIBK.PAYMENT_ACCEPTED || item.TxSts == StatusResponseDetailIBK.SUCCESS_STRUCTURE)
			{
				string dateTimePayment = descriptionAnswer[4..descriptionAnswer.IndexOf('/')];
				string timePayment = dateTimePayment.Split('T')[1];
				string timePaymentWithoutMillis = timePayment[..^4];

				paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseSuccesses.Add(
					new PaymentFileSetResponse(IdPaymentOrderDetail, paymentFileResponseUnified.IdPaymentOrder, uniqueCode, paymentFileResponseUnified.IdMassivePayment, netAmount, codeAnswer, string.Empty, timePaymentWithoutMillis, auditRecord));
			}
			else
			{
				paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseFailures.Add(
					new PaymentFileSetResponse(IdPaymentOrderDetail, paymentFileResponseUnified.IdPaymentOrder, uniqueCode, paymentFileResponseUnified.IdMassivePayment, netAmount, codeAnswer, descriptionAnswer, string.Empty, auditRecord));
			}
		}

		paymentFileResponseUnifiedResult.IsRead = true;

		return paymentFileResponseUnifiedResult;
	}

	private static bool ValidateDetailsTransactionIBK(string uniqueCode, decimal netAmount, string codeAnswer, string descriptionAnswer)
	{
		if (string.IsNullOrEmpty(uniqueCode)
			|| string.IsNullOrEmpty(codeAnswer)
			|| string.IsNullOrEmpty(descriptionAnswer)
			|| netAmount == 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	#endregion;

}

﻿using Domain.ValueObjects.PaymentsFiles;
using Domain.PaymentsOrdersDetails.Common;
using Domain.ValueObjects;
using Domain.PaymentsSettings;
using Domain.PaymentsFiles.Models;

namespace Domain.PaymentsFiles.ResponseGet;

public class PaymentFileTxtResponseReader : IPaymentFileResponseGetter<PaymentFileFormatTxt>
{
	public PaymentFileResponseUnified GetResponse(PaymentFileResponseUnified paymentFileResponseUnified, PaymentSetting paymentSetting)
	{
		PaymentFileResponseUnified? paymentFileResponseUnifiedResult = null;

		List<PaymentFileFormatTxt>? paymentSettingFormat = paymentSetting.DetalleFormatoTxt ?? null;

		if (paymentSettingFormat is null)
		{
			throw new ArgumentNullException(nameof(paymentSettingFormat));
		}

		bool error = false;
		string descriptionError = string.Empty;
		string[] stringsContent = paymentFileResponseUnified.FileContent.Split("\n").Where(c => c.Length > 0).ToArray();

		paymentFileResponseUnifiedResult = paymentFileResponseUnified;

		if (stringsContent.Length == 1)
		{
			error = true;
			descriptionError = stringsContent.FirstOrDefault()!;
		}
		else
		{
			//Exclude row from totals
			stringsContent = stringsContent[..^1];

			foreach (var row in stringsContent)
			{
				int lengthRow = row.Length;
				int initialMax = paymentSettingFormat.Max(c => c.Inicio);

				if (lengthRow > initialMax)
				{
					PaymentFileFormatTxt? referencia1 = paymentSettingFormat.Find(c => c.Campo == "referencia1");
					string idMassivePaymentString = row.Substring(referencia1!.Inicio - 1, referencia1!.Longitud).Trim();

					if (!int.TryParse(idMassivePaymentString, out int idMassivePayment))
					{
						error = true;
						descriptionError += @"El id pago masivo no cuenta con el formato correcto.\n";
					}

					PaymentFileFormatTxt? referencia2 = paymentSettingFormat.Find(c => c.Campo == "referencia2");
					string uniqueCode = row.Substring(referencia2!.Inicio - 1, referencia2!.Longitud).Trim();

					PaymentFileFormatTxt? importeNeto = paymentSettingFormat.Find(c => c.Campo == "importeNeto");
					string netAmountString = row.Substring(importeNeto!.Inicio - 1, importeNeto.Longitud).Trim();

					if (!decimal.TryParse(netAmountString, out decimal netAmount))
					{
						error = true;
						descriptionError += @"El importe del retiro no cuenta con el formato correcto.\n";
					}

					netAmount /= 100m;

					PaymentFileFormatTxt? codeResponseFormat = paymentSettingFormat.Find(c => c.Campo == "codigoRespuesta");
					string codeAnswer = row.Substring(codeResponseFormat!.Inicio - 1, codeResponseFormat.Longitud).Trim();
					if (string.IsNullOrEmpty(codeAnswer))
					{
						error = true;
						descriptionError += @"El código de respuesta no cuenta con el formato correcto.\n";
					}

					PaymentFileFormatTxt? descriptionResponseFormat = paymentSettingFormat.Find(c => c.Campo == "descripcionRespuesta");
					string descriptionAnswer = row.Substring(descriptionResponseFormat!.Inicio - 1, descriptionResponseFormat.Longitud).Trim();

					paymentFileResponseUnifiedResult.IdMassivePayment = idMassivePayment;

					int IdPaymentOrderDetail = paymentFileResponseUnified.Details.Find(c => c.CodigoUnico == uniqueCode)!.Id;
					AuditRecord auditRecord = paymentFileResponseUnified.Details.Find(c => c.CodigoUnico == uniqueCode)!.RegistroAuditoria;

					if (codeAnswer == "000")
					{
						PaymentFileFormatTxt? timePaymentFormat = paymentSettingFormat.Find(c => c.Campo == "horaPago");
						string timePayment = row.Substring(timePaymentFormat!.Inicio - 1, timePaymentFormat.Longitud).Trim();

						paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseSuccesses.Add(
						   new PaymentFileSetResponse(IdPaymentOrderDetail, paymentFileResponseUnified.IdPaymentOrder, uniqueCode, paymentFileResponseUnified.IdMassivePayment, netAmount, codeAnswer, descriptionAnswer, timePayment, auditRecord));
					}
					else
					{
						paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseFailures.Add(
						  new PaymentFileSetResponse(IdPaymentOrderDetail, paymentFileResponseUnified.IdPaymentOrder, uniqueCode, paymentFileResponseUnified.IdMassivePayment, netAmount, codeAnswer, descriptionAnswer, string.Empty, auditRecord));
					}
				}
			}
		}

		if (error)
		{
			var paymentsOrdersDetailsErrors = paymentFileResponseUnified.Details;

			foreach (var paymentOrderDetailError in paymentsOrdersDetailsErrors)
				paymentFileResponseUnifiedResult.PaymentFileContentResponse.ResponseErrors.Add(new PaymentFileSetResponse(paymentOrderDetailError.Id, paymentFileResponseUnified.IdPaymentOrder, paymentOrderDetailError.CodigoUnico, paymentOrderDetailError.IdPagoMasivo, descriptionError, paymentOrderDetailError.RegistroAuditoria, Common.Constants.StatusResponseDetailBBVA.PAYMENT_REJECTED));
		}

		return paymentFileResponseUnifiedResult;
	}
}
﻿using Domain.PaymentsFiles.Models;
using Domain.PaymentsOrdersDetails.Common;
using Domain.PaymentsSettings;

namespace Domain.PaymentsFiles.ResponseGet;

public interface IPaymentFileResponseGetter<T>
{
	PaymentFileResponseUnified? GetResponse(PaymentFileResponseUnified paymentResponseFile, PaymentSetting paymentSetting);
}
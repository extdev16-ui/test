﻿using System.Text.Json;

namespace Domain.PaymentsFiles.Helpers;

public static class PaymentFormatDeserializer
{
	public static List<T> Deserialize<T>(string json)
	{
		var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
		return JsonSerializer.Deserialize<List<T>>(json, options) ?? [];
	}
}

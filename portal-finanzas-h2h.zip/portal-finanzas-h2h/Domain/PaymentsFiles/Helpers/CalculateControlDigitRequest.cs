﻿namespace Domain.PaymentsFiles.Helpers;

public partial record CalculateControlDigitRequest
{

	public CalculateControlDigitRequest(
		int rootModule, int agreementNumber, int orderDate, int amountToPay, int currency,
		int paymentMethod, int destinationCount, int accountOrigin)
	{
		RootModule = rootModule;
		AgreementNumber = agreementNumber;
		OrderDate = orderDate;
		AmountToPay = amountToPay;
		Currency = currency;
		PaymentMethod = paymentMethod;
		DestinationCount = destinationCount;
		AccountOrigin = accountOrigin;
	}
	public int RootModule { get; set; }
	public int AgreementNumber { get; set; }
	public int OrderDate { get; set; }
	public int AmountToPay { get; set; }
	public int Currency { get; set; }
	public int PaymentMethod { get; set; }
	public int DestinationCount { get; set; }
	public int AccountOrigin { get; set; }
	public int TotalSum => AgreementNumber + OrderDate + AmountToPay +
							   Currency + PaymentMethod + DestinationCount + AccountOrigin;
}
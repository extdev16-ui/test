﻿using Domain.PaymentsSettings;
using ErrorOr;
using System.Reflection.Metadata;
using System.Text.RegularExpressions;

namespace Domain.PaymentsFiles.Helpers;

public static class PaymentFileHelper
{
	public static string DigitTwoFormat(int number)
	{
		return (number % 100).ToString("D2");
	}

	public static string TruncarYPad(string valor, int longitud)
	{
		if (valor.Length > longitud)
		{
			return valor[..longitud];
		}
		else
		{
			return valor.PadRight(longitud);
		}
	}

	public static string SetFileNameByPaymentSettingCode(string paymentSettingCode, string fileName, string status, out string typeFile)
	{
		string result;
		switch (paymentSettingCode)
		{
			case Common.Constants.PaymentSettings.H2H_SCOTIABANK_PV:
				{
					result = fileName;
					typeFile = Common.Constants.PaymentFileType.RESPONSE;
				}
				break;
			case Common.Constants.PaymentSettings.H2H_BBVA_PP:
				{
					switch (status)
					{
						case Common.Constants.PaymentFileStatus.RECEIVED:
							{
								if (fileName.Contains("R_pain002_"))
								{
									typeFile = Common.Constants.PaymentFileType.RESPONSE;
									result = Regex.Replace(fileName, @"pgp\.R_pain002_\d+\.", "");
								}
								else if (fileName.Contains(".pdf."))
								{
									typeFile = Common.Constants.PaymentFileType.VOUCHER;
									result = Regex.Replace(fileName, @"pgp_\d{14}_\d{3}\.pdf\.", "");
								}
								else
								{
									throw new NotImplementedException();
								}
							}
							break;
						default:
							{
								typeFile = Common.Constants.PaymentFileType.SEND;
								result = fileName;
							}
							break;
					}
				}
				break;
            case Common.Constants.PaymentSettings.H2H_IBK_PP:
                {
                    if (fileName.Contains(".xml"))
					{
                        string[] partes = fileName.Split('_');

                        if (partes.Length >= 2)
                        {
                            string codigo = partes[1];   // H2HXPGP03AAHC01CODE000000000000051293004
                            string fecha = partes[2];    // 20250716155933
                            string new_fileName = codigo + "_" + fecha + ".xml";
                            result = new_fileName;
                            typeFile = Common.Constants.PaymentFileType.RESPONSE;
                        }
						else
						{
                            throw new NotImplementedException();
                        }
                    }
                    else
                    {
                        throw new NotImplementedException();
                    }

                }
                break;
            default: throw new NotImplementedException();

		}

		return result;
	}
	public static bool ValidateResponseLimitsByPaymentSetting(PaymentSetting paymentSetting, int quantity, string typeFile, out string message)
	{
		int limit = int.Parse(paymentSetting.DetalleConfiguraciones!.Find(c => c.Nombre == "limiteRespuestas")?.Valor ?? "1");

		if (quantity >= limit && typeFile == Common.Constants.PaymentFileType.RESPONSE)
		{
			message = "Se excedió en el límite de cantidad de respuesta por orden de pago";
			return false;
		}
		else
		{
			message = "";
			return true;
		}
	}
}
﻿
namespace Domain.PaymentsFiles.Processors;
public interface IValidatorPaymentFileXml 

{
	public List<string> ValidateXmlWithXsd(string xmlContent, string xsdContent);
}

﻿using System.Xml.Schema;
using System.Xml;

namespace Domain.PaymentsFiles.Processors;
public class ValidatorPaymentFileXml : IValidatorPaymentFileXml

{
	public List<string> ValidateXmlWithXsd(string xmlContent, string xsdContent)
	{
		XmlSchemaSet schemas = new XmlSchemaSet();
		using (StringReader xsdReader = new StringReader(xsdContent))
		{
			schemas.Add("urn:iso:std:iso:20022:tech:xsd:pain.001.001.03", XmlReader.Create(xsdReader));
		}

		XmlReaderSettings settings = new XmlReaderSettings
		{
			ValidationType = ValidationType.Schema,
			Schemas = schemas
		};

		List<string> validationErrors = [];
		settings.ValidationEventHandler += (sender, e) =>
		{
			validationErrors.Add($"Error de validación XSD: {e.Message}");
		};

		try
		{
			using (StringReader xmlReader = new StringReader(xmlContent))
			using (XmlReader reader = XmlReader.Create(xmlReader, settings))
			{
				while (reader.Read()) { }
			}
		}
		catch (Exception ex)
		{
			validationErrors.Add($"Error crítico: {ex.Message}");
		}

		bool isValid = validationErrors.Count == 0; 

		return validationErrors;
	}
}

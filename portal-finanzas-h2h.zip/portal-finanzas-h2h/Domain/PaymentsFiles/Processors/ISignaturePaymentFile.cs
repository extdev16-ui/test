﻿namespace Domain.PaymentsFiles.Processors;
public interface ISignaturePaymentFile
{
	string SignFileHash(byte[] gpgBytes, string password, string fileContent, string execGPG);
}

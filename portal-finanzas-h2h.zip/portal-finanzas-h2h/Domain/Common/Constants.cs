namespace Domain.Common;

public static class Constants
{
	public const string NAMEAPP = "API GESTION PAGOS";
	public const int USER_OLD_DEFAULT = 1;
	public const int AGREEMENT_NUMBER = 4131;
	public const bool HISTORICAL_SFTP = true;
	public const bool TRANSACCTION_SFTP = false;

	public const bool DELETE_FILE = true;
	public const bool NOT_DELETE_FILE = false;


	// Constantes de Mensajes
	public static class CatalogType
	{
		public const string PAYMENT_ORDER_MONEY = "002";
		public const string PAYMENT_ORDER_DETAIL_STATUS = "003";
		public const string PAYMENT_FILE_STATUS = "004";
		public const string PAYMENT_ORDER_STATUS = "005";
		public const string PAYMENT_FILE_TYPE = "006";
	}

	public static class PaymentOrderMoney
	{
		public const string SOLES = "001";
		public const string DOLARES = "002";
	}
	public static class PaymentOrderDetailStatus
	{
		public const string PENDING = "001";
		public const string PAID = "002";
		public const string ERROR = "003";
	}

	public static class PaymentOrderStatus
	{
		public const string PENDING = "001";
		public const string CONFIRMED = "002";
		public const string FULLYPAID = "003";
		public const string PARTIALLYPAID = "004";
		public const string ERROR = "005";
	}

	public static class PaymentFileType
	{
		public const string SEND = "001";
		public const string RESPONSE = "002";
		public const string VOUCHER = "003";
		public const string NONE = "";
	}

	public static class PaymentFileCurrency
	{
		public const string PEN = "001";
		public const string DOLLAR = "002";
	}

	public static class PaymentSettings
	{
		public const string H2H_SCOTIABANK_PV = "001";
		public const string H2H_BBVA_PP = "002";
        public const string H2H_IBK_PP = "003";
    }
	public static class TypePaymentFileResponseBBVA
	{
		public const int GLOBAL = 1;
		public const int STRUCTURE = 2;
		public const int TRANSACTION = 3;
	}
	 
	public static class StatusResponseGlobalBBVA
	{
		public const string RECEIVED = "RCVD";
		public const string ERROR = "RJCT";
		public static readonly string[] STATUS = [RECEIVED, ERROR];
	}

	public static class StatusResponseStructureBBVA
	{
		public const string SUCCESS_STRUCTURE = "ACTC";
		public const string PARTIALLY_STRUCTURE = "PART";
		public const string ERROR = "RJCT";
		public static readonly string[] STATUS = [SUCCESS_STRUCTURE, PARTIALLY_STRUCTURE, ERROR];
	}

	public static class StatusResponseTransactionBBVA
	{
		public const string SUCCESS_CONTENT = "ACCP";
		public const string PAYMENT_ACCEPTED = "ACSP";
		public const string PARTIALLY_PAID = "PART";
		public const string ERROR = "RJCT";
		public static readonly string[] STATUS = [SUCCESS_CONTENT, PAYMENT_ACCEPTED, PARTIALLY_PAID, ERROR];
	}

	public static class StatusResponseDetailBBVA
	{
		public const string PAYMENT_ACCEPTED = "ACSP";
		public const string SUCCESS_STRUCTURE = "ACTC";
		public const string PAYMENT_REJECTED = "RJCT";
	}

	public static class PaymentResponseFileLimits
	{
		public const int H2H_SCOTIABANK_PV = 1;
		public const int H2H_BBVA_PP = 3;
        public const int H2H_IBK_PP = 1;
    }


	public static class PaymentFileStatus
	{
		public const string GENERATED = "001";
		public const string UPLOADED = "002";
		public const string SENT = "003";
		public const string RECEIVED = "004";
		public const string READ = "005";
	}


	public static class CatalogPaymentCalendarType
	{
		public const string IDLE = "001";
		public const string HOLIDAY = "002"; 
	}

    public static class  BankFormatNumber
    {
		public const string PaymentConfigurationFormat1 = "001,002";
        public const string PaymentConfigurationFormat2 = "003";
    }

    public static class ValidationDayCalendar
    {
		public static readonly string[] PaymentConfiguration = ["001", "002"];
	}

	public static class ConfigurationFormatXML
	{
		public const string ConfigurationPaymentSCOTIA = "001";
		public const string ConfigurationPaymentBBVA = "002";
		public const string ConfigurationPaymentIBK = "003";
	}

    public static class TypeDestinyPayment
    {
        public const string Self = "P";
        public const string Interbank = "I";
    }

    public static class TypeDestinyXML
	{
        public const string Self = "TRF";
        public const string Interbank = "EXT";
    }

    public static class TypePaymentFileResponseIBK
    {
        public const int STRUCTURE = 1;
    }

    public static class StatusResponseStructureIBK
    {
        public const string SUCCESS_STRUCTURE = "ACTC";
        public const string PARTIALLY_STRUCTURE = "PART";
        public const string ERROR = "RJCT";
        public static readonly string[] STATUS = [SUCCESS_STRUCTURE, PARTIALLY_STRUCTURE, ERROR];
    }

    public static class StatusResponseDetailIBK
    {
        public const string PAYMENT_ACCEPTED = "ACSP";
        public const string SUCCESS_STRUCTURE = "ACTC";
        public const string PAYMENT_REJECTED = "RJCT";
    }

    public static class ValidationReadNameFile
    {
        public const string PaymentConfigurationRead = "003";
    }

	public static class NomenclatureReadNameFile
	{
        public const string File_Observation = "OBS";
        public const string File_OK = "OK";
    }

    public static class SftpConnectionType
    {
        public const int Password = 1;
        public const int PrivateKey = 2;
    }
}
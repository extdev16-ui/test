using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.Catalogs;

public sealed class Catalog : AggregateRoot{
    
    public Catalog(string nombre, string descripcion, string tipo, AuditRecord registroAuditoria)
    {
        Nombre = nombre;
        Descripcion = descripcion;
        Tipo = tipo;
        RegistroAuditoria = registroAuditoria;
    }

    public Catalog(int id, string codigo)
    {
        Id = id;
        Codigo = codigo;
    }


    private Catalog()
    {
        
    }

    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre {get; set;} = string.Empty;
    public string Descripcion {get; set;} = string.Empty;
    public string NombreAlternativo { get; set; } = string.Empty;
    public string Tipo {get; set; } = string.Empty;
    public string Etiqueta { get; set; } = string.Empty;
    public AuditRecord RegistroAuditoria { get; set; } 
}
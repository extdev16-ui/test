namespace Domain.Catalogs;

public interface ICatalogRepository{
    Task<Catalog?> GetIdByCode(string codeType, string code);
	Task<Catalog?> GetById(int id);
}
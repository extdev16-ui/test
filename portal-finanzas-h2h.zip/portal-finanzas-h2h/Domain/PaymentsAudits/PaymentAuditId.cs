namespace Domain.PaymentsAudits;

public record PaymentAuditId(Guid value);
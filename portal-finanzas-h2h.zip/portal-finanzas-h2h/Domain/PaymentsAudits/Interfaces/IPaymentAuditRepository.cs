namespace Domain.PaymentsAudits.Interfaces;

public interface IPaymentAuditRepository
{
    void Add(PaymentAudit paymentAudit);
    void MassiveAdd(List<PaymentAudit> paymentAudits);
    Task<List<PaymentAudit>> GetAll();
}
using Domain.PaymentsOrders;
using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.PaymentsAudits;

public sealed class PaymentAudit : AggregateRoot
{

    public PaymentAudit(int idOrdenPago, int idOrdenPagoDetalle, string accion, string detalle, AuditRecord registroAuditoria)
    {
        IdOrdenPago = idOrdenPago;
        IdOrdenPagoDetalle = idOrdenPagoDetalle;
        Accion = accion;
        Detalle = detalle;
        RegistroAuditoria = registroAuditoria;
    }

    public PaymentAudit()
    {

    }

    public int Id { get; set; }
    public int IdOrdenPago { get; set; }
    public PaymentOrder? OrdenPago { get; set; }
    public int IdOrdenPagoDetalle { get; set; }
    public int IdPagoMasivo { get; set; }
    public string Accion { get; set; } = string.Empty;
    public string Detalle { get; set; } = string.Empty;
    public AuditRecord RegistroAuditoria { get; set; }

}
using Domain.Catalogs;
using Domain.PaymentsSettings;
using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.PaymentsCalendar;

public sealed class PaymentCalendar : AggregateRoot{    

    public PaymentCalendar(DateTime fecha, int idCatalogoTipo, int idConfiguracionPago, AuditRecord registroAuditoria)
    {
		Fecha = fecha;
		IdCatalogoTipo = idCatalogoTipo;
		IdConfiguracionPago = idConfiguracionPago;
		RegistroAuditoria = registroAuditoria;
    }

    private PaymentCalendar()
    {
        
    }
    public int Id { get; set; }
	public DateTime Fecha { get; set; }
    public string HoraInicio { get; set; } = string.Empty;
	public string HoraFin { get; set; } = string.Empty;
	public int IdCatalogoTipo { get; set; }
	public Catalog CatalogoTipo { get; set; }
	public int IdConfiguracionPago { get; set; }
	public PaymentSetting ConfiguracionPago { get; set; }
	public AuditRecord RegistroAuditoria { get; set; }
}
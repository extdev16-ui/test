﻿using ErrorOr;

namespace Domain.PaymentsCalendar.Common
{
	public class Helper
	{

		public static ErrorOr<DateTime> SearchDayActive(string initialDate, List<PaymentCalendar> paymentsCalendar)
		{

			DateTime paymentCalendarDate = DateTime.Now;

			paymentCalendarDate = paymentCalendarDate.Date;

			var paymentsCalendarDates = paymentsCalendar.Select(c => c.Fecha.Date);

			while (paymentsCalendarDates.Contains(paymentCalendarDate))
			{
				paymentCalendarDate = paymentCalendarDate.AddDays(1);
			}

			return paymentCalendarDate;
		}
	
	}
}

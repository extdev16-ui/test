namespace Domain.PaymentsCalendar.Interfaces;

public interface IPaymentCalendarRepository
{
    Task<List<PaymentCalendar>?> GetByPaymentSetting(string code);
	Task<PaymentCalendar?> GetByDate(string code, DateTime date, string type);
}
using Domain.Banks;
using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.Plataforms;

public sealed class Plataform : AggregateRoot{
    
    public Plataform(string nombre, string descripcion, AuditRecord registroAuditoria)
    {
        Nombre = nombre;
        Descripcion = descripcion;
        RegistroAuditoria = registroAuditoria;
    }

    private Plataform()
    {
        
    }

    public int Id { get; set;}
    public string Nombre  { get; set; } = string.Empty;
    public string Descripcion  { get; set; } = string.Empty;
    public AuditRecord RegistroAuditoria { get; set; }
}
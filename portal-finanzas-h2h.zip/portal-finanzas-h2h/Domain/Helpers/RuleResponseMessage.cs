namespace Domain.Helpers;

public class RuleResponseMessage
{
    public bool Validated { get; set; }
    public string? Title { get; set; }
    public string? Message { get; set; }
}
using Domain.MassivesPayments.Common;
using Domain.PaymentsSettings;

namespace Domain.Helpers;

public class ValidationResponseMessage
{
    public bool Validated { get; set; }
    public string? Title { get; set; }
    public string? Message { get; set; }
    public PaymentSetting? paymentSetting { get; set; }
    public MassivePaymentResponse? massivePaymentResponse { get; set; }
}
using Domain.Primitives;
using Domain.ValueObjects;

namespace Domain.CatalogsTypes;

public sealed class CatalogType : AggregateRoot
{
    public CatalogType(string codigo, string nombre, string descripcion, AuditRecord registroAuditoria)
    {
        Codigo = codigo;
        Nombre = nombre;
        Descripcion = descripcion;
        RegistroAuditoria = registroAuditoria;
    }

    private CatalogType()
    {

    }

    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Nombre { get; set; } = string.Empty;
    public string Descripcion { get; set; } = string.Empty;
    public AuditRecord RegistroAuditoria { get; set; }
}
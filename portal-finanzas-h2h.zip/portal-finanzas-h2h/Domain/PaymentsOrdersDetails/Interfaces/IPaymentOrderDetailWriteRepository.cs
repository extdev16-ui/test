using Domain.ValueObjects;

namespace Domain.PaymentsOrdersDetails.Interfaces;

public interface IPaymentOrderDetailWriteRepository
{
    void Add(List<PaymentOrderDetail> paymentsOrdersDetails);
    void UpdateUniqueCode(PaymentOrderDetail paymentOrderDetail);
    void Update(PaymentOrderDetail paymentOrderDetail, AuditRecord auditRecord);
}
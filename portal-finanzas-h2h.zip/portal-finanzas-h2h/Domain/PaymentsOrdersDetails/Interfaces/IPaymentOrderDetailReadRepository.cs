using Domain.PaymentsFiles;
using Domain.PaymentsOrdersDetails.Common;
using Domain.ValueObjects;

namespace Domain.PaymentsOrdersDetails.Interfaces;

public interface IPaymentOrderDetailReadRepository
{
    Task<bool> ExistsDuplicate(List<string> uniqueCodes);
    Task<List<PaymentOrderDetailDto>> GetByUniqueCodes(string uniqueCodes, int idPaymentOrder);
    Task<List<PaymentOrderDetailDto>> GetByStatusPaymentResponseFile(string codeStatusPaymentFile);
}
﻿
using Domain.ValueObjects;

namespace Domain.PaymentsOrdersDetails.Common
{
    public class PaymentOrderDetailDto
    {
        public int Id { get; set; }
        public int Estado { get; set; }
        public string CodigoUnico { get; set; } = string.Empty;
        public int IdOrdenPago { get; set; }
        public int IdPagoMasivo { get; set; }
        public string NombreArchivo { get; set; } = string.Empty;
		public int IdCatalogoTipo { get; set; }
		public string CatalogoTipo { get; set; } = string.Empty;
		public int OrdenArchivo { get; set; }
		public AuditRecord RegistroAuditoria { get; set; } = new();
    }
}

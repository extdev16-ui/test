using Domain.Catalogs;
using Domain.PaymentsOrders;
using Domain.Primitives;
using Domain.ValueObjects;
using System.Globalization;
using System.Text;

namespace Domain.PaymentsOrdersDetails;

public sealed class PaymentOrderDetail : AggregateRoot
{

    public PaymentOrderDetail(int idOrdenPago, string cuentaBeneficiario, string nombreBeneficiario, decimal monto, string descripcion, int idCatalogoEstado, string codigoUnico, AuditRecord registroAuditoria)
    {
        IdOrdenPago = idOrdenPago;
        CuentaBeneficiario = cuentaBeneficiario;
        NombreBeneficiario = nombreBeneficiario;
        Monto = monto;
        Descripcion = descripcion;
        IdCatalogoEstado = idCatalogoEstado;
        CodigoUnico = codigoUnico;
        RegistroAuditoria = registroAuditoria;
    }

    public PaymentOrderDetail(int id, int idCatalogoEstado, string horaProcesado, string codigoRespuesta, string descripcionRespuesta)
    {
        Id = id;
        IdCatalogoEstado = idCatalogoEstado;
        HoraProcesado = horaProcesado;
        CodigoRespuesta = codigoRespuesta;
        DescripcionRespuesta = descripcionRespuesta;
    }

    private PaymentOrderDetail()
    {

    }

    public int Id { get; set; }
    public int IdOrdenPago { get; set; }
    public PaymentOrder OrdenPago { get; set; }
    public string CuentaBeneficiario { get; set; } = string.Empty;

    private string _nombreBeneficiario = string.Empty;
    public string NombreBeneficiario
    {
        get => _nombreBeneficiario;
        set
        {
            if (string.IsNullOrEmpty(value))
            {
                _nombreBeneficiario = value;
            }
            else
            {
                string normalized = value.Normalize(NormalizationForm.FormD);
                var sb = new StringBuilder();

                foreach (char c in normalized)
                {
                    var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);

                    if (unicodeCategory != UnicodeCategory.NonSpacingMark)
                    {
                        switch (c)
                        {
                            case '\u00F1': // �
                                sb.Append('n');
                                break;
                            case '\u00D1': // �
                                sb.Append('N');
                                break;
                            case '&':
                                sb.Append("y");
                                break;
                            default:
                                sb.Append(c);
                                break;
                        }
                    }
                }

                _nombreBeneficiario = sb.ToString().Normalize(NormalizationForm.FormC);
            }
        }
    }
    public decimal Monto { get; set; }
    public string Descripcion { get; set; } = string.Empty;
    public int IdCatalogoEstado { get; set; }
    public Catalog CatalogoEstado { get; set; }
    public string CodigoUnico { get; set; } = string.Empty;
    public string Ticket { get; set; } = string.Empty;
    public string Comentario { get; set; } = string.Empty;
    public string HoraProcesado { get; set; } = string.Empty;
    public string CodigoRespuesta { get; set; } = string.Empty;
    public string DescripcionRespuesta { get; set; } = string.Empty;
    public AuditRecord RegistroAuditoria { get; set; }
}
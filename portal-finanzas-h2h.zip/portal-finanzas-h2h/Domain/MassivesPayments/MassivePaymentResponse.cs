﻿using System.Security.Principal;
using static Domain.Common.Constants;

namespace Domain.MassivesPayments.Common;

public record MassivePaymentResponse
{
	public int IdPagoMasivo { get; init; }
	public int IdOrdenPago { get; init; }
	public string ConfiguracionPago { get; init; } = string.Empty;
    public string NomenclaturaMoneda { get; init; } = string.Empty;
    public string CodigoMoneda { get; init; } = PaymentOrderMoney.SOLES;
	public string CuentaBancaria { get; init; } = string.Empty;
	public decimal ImporteTotal { get; init; }
	public string UsuarioCreador { get; set; } = string.Empty;
	public DateTime FechaPago { get; set; } = DateTime.Now;
	public List<MassivePaymentDetailResponse> Detalle { get; set; } = [];
	public string FirmaDigital { get; set; } = string.Empty;


	public int GetDebtorAccount()
	{
		int resultDebtorAccount = 0;
		switch (ConfiguracionPago)
		{
			case PaymentSettings.H2H_SCOTIABANK_PV: int.TryParse(CuentaBancaria[..7], out resultDebtorAccount); break;
		}
		
		return resultDebtorAccount;

	}
	public string SetDebtorAccount()
	{
		string typeCurrency = GetCurrency();
		string officeNumber;
		string debtorAccount = string.Empty;
		string bankAccount = CuentaBancaria;

		switch (ConfiguracionPago)
		{
			case PaymentSettings.H2H_SCOTIABANK_PV:
				{
					officeNumber = "000";
					debtorAccount = $"{bankAccount}{officeNumber}{typeCurrency}";
				}
				break;
			case PaymentSettings.H2H_BBVA_PP:
				{
					if (!bankAccount.StartsWith("0011"))
						throw new ArgumentException("Cuenta inválida. Debe comenzar con '0011'.");

					debtorAccount = bankAccount;
				}
				break;
			case PaymentSettings.H2H_IBK_PP:
				{
                    //if (!bankAccount.StartsWith("0033"))
                    //    throw new ArgumentException("Cuenta inválida. Debe comenzar con '0033'.");

                    debtorAccount = bankAccount;
                }
                break;

        }

		return debtorAccount;
	}

	public string GetCurrency()
	{
		string currency = string.Empty;
		switch (ConfiguracionPago)
		{
			case PaymentSettings.H2H_SCOTIABANK_PV:
				{
					if (CodigoMoneda == PaymentOrderMoney.SOLES)
						currency = "01";
					else
						currency = "07";
				}
				break;
			case PaymentSettings.H2H_BBVA_PP:
				{

					if (CodigoMoneda == PaymentOrderMoney.SOLES)
						currency = "PEN";
					else
						currency = "USD";
				}
				break;
            case PaymentSettings.H2H_IBK_PP:
                {

                    if (CodigoMoneda == PaymentOrderMoney.SOLES)
                        currency = "PEN";
                    else
                        currency = "USD";
                }
                break;
        }
		return currency;
	}
}

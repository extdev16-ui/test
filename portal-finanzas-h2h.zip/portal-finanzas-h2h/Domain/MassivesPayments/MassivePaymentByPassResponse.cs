﻿using System.Security.Principal;
using Org.BouncyCastle.Bcpg;
using static Domain.Common.Constants;

namespace Domain.MassivesPayments.Common;

public record MassivePaymentByPassResponse
{

	public string TipoAbono { get; init; } = string.Empty;

    public List<MassivePaymentDetailResponse> Detalle { get; set; } = [];

	public string GetTypePass()
	{
		string currency = string.Empty;
		switch (TipoAbono)
		{
			case TypeDestinyPayment.Self:
				{
					currency = TypeDestinyXML.Self;
                }
				break;
			case TypeDestinyPayment.Interbank:
				{
                    currency = TypeDestinyXML.Interbank;
                }
				break;
        }
		return currency;
	}
}

﻿using Domain.PaymentsSettings;
using System.Globalization;
using System.Text;

namespace Domain.MassivesPayments.Common;

public record MassivePaymentDetailResponse
{
	public int IdPagoMasivoDetalle;
	public int IdPagoMasivo;
	public string ConfiguracionPago = string.Empty;
	public string CuentaBeneficiario = string.Empty;
	public string NumeroDocumento = string.Empty;
	public string TipoDocumento = string.Empty;
	public string NombreBeneficiario { get; set; } = string.Empty;
	public decimal Monto;
	public string CodigoUnico = string.Empty;
	public string CuentaBeneficiarioCci = string.Empty;
	public string TipoCuenta = string.Empty;
    public string TipoAbono = string.Empty;
    public int ModuloRaiz = 0;
	public int Correlativo = 1;
	public DateTime FechaPago;

	public string TransformSpecialCharacters(string input)
	{
		if (string.IsNullOrEmpty(input)) return input;

		string normalized = input.Normalize(NormalizationForm.FormD);
		var sb = new StringBuilder();

		foreach (char c in normalized)
		{
			var unicodeCategory = CharUnicodeInfo.GetUnicodeCategory(c);
			// Mantener solo los caracteres que no son marcas de acentuación
			if (unicodeCategory != UnicodeCategory.NonSpacingMark)
			{
				switch (c)
				{
					case 'ñ':
						sb.Append('n');
						break;
					case 'Ñ':
						sb.Append('N');
						break;
					case '&':
						sb.Append("y");
						break;
					default:
						sb.Append(c);
						break;
				}
			}
		}

		return sb.ToString().Normalize(NormalizationForm.FormC);
	}

	public string GetBeneficiaryAccount(string paymentSetting)
	{
		string beneficiaryAccount = string.Empty;

		switch (paymentSetting)
		{
			case "001":
				{
					if (CuentaBeneficiario.Length == 20)
					{
						int.TryParse(CuentaBeneficiario.Substring(13, 7), out int result);
						beneficiaryAccount = result.ToString();
					}
					else
					{
						string concatBeneficiaryAccount = CuentaBeneficiario.Substring(3, 7);
						int.TryParse(concatBeneficiaryAccount, out int result);
						beneficiaryAccount = result.ToString();
					}
				} break;
			case "002":
				{
					if (CuentaBeneficiario.Length != 20 || !CuentaBeneficiario.StartsWith("0011"))
						throw new ArgumentException("Cuenta inválida. Debe tener 20 dígitos y comenzar con '0011'.");

					beneficiaryAccount = CuentaBeneficiario;

				}
				break;
		}

		return beneficiaryAccount;
	}

	public string GetDocumentType(string paymentSetting)
	{
		string documentType = TipoDocumento;

		switch (paymentSetting)
		{
			case "002":
				{

					switch (documentType) {
						case "DNI": documentType = "L"; break;
						case "CEX": documentType = "E"; break;
						case "PSS": documentType = "P"; break;
						case "": documentType = "S"; break;
					}
				}
				break;
		}

		return documentType;
	}

}



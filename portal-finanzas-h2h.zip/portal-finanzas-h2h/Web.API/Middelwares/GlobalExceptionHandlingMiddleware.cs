using System.Net;
using System.Text.Json;
using Application.Dependencies;
using Microsoft.AspNetCore.Mvc;
using Web.API.Common;
using Web.API.Common.Logging;

namespace Web.API.Middlewares;

public class GlobalExceptionHandlingMiddleware : IMiddleware
{
    private readonly ILogger<GlobalExceptionHandlingMiddleware> _logger;
    private const string APIKEYNAME = "x-api-key";
    private readonly ISecretsManagerCredentialsProvider _vaultCredentialsProvider;

    public GlobalExceptionHandlingMiddleware(ILogger<GlobalExceptionHandlingMiddleware> logger, ISecretsManagerCredentialsProvider vaultCredentialsProvider)
    {
        _vaultCredentialsProvider = vaultCredentialsProvider;
        _logger = logger;
    }
    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        try
        {
            // Validaci�n de API Key
            if (!context.Request.Headers.TryGetValue(APIKEYNAME, out var extractedApiKey))
            {
                context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                await context.Response.WriteAsync("API Key was not provided.");
                return;
            }

            string apiKey = _vaultCredentialsProvider.GetApiKeyByApp();

            if (apiKey != extractedApiKey)
            {
                context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                await context.Response.WriteAsync("Unauthorized client.");
                return;
            }

            await next(context);
        }
        catch (Exception ex)
        {
			_logger.LogException(ex);

			context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            ProblemDetails problem = new()
            {
                Status = (int)HttpStatusCode.InternalServerError,
                Type = Constants.HttpResponse.FAILURE_TITLE,
                Title = Constants.HttpResponse.FAILURE_MESSAGE,
                Detail = Constants.HttpResponse.FAILURE_MESSAGE
            };

            string json = JsonSerializer.Serialize(problem);

            context.Response.ContentType = "application/json";

            await context.Response.WriteAsync(json);
        }
    }
}
﻿namespace Web.API.Common.Logging;


public static class LoggerExtensions
{
	public static void LogException(this ILogger logger, Exception ex)
	{
		logger.LogError("Excepción en Tipo: {Tipo} | Mensaje: {Mensaje} | Inner: {Inner}",
			ex.GetType().Name,
			ex.Message,
			ex.InnerException?.Message ?? "No inner exception");
	}
}
using Application.Services.ValidateRulePendingPayment;
using MediatR;
using Microsoft.AspNetCore.Mvc;
namespace Web.API.Controllers;

[Route("api/v1/pendingpayments")]
public class PendingPaymentController : ApiController
{
    private readonly ISender _mediator;

    public PendingPaymentController(ISender mediator)
    {
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
    }
        
    /// <summary>
    /// Creates a new payment file
    /// </summary>
    /// <param name="command">The command containing the data for the new payment file</param>
    /// <returns>The result of the operation, which is either a payment file or a list of errors</returns>
    [HttpPost("rule/validate")]
    public async Task<IActionResult> ValidateRule([FromBody] ValidateRulePendingPaymentCommand command)
    {
        var validateRulePendingPaymentCommandResult = await _mediator.Send(command);

        return validateRulePendingPaymentCommandResult.Match(
            validateRulePendingPayment => Ok(validateRulePendingPayment),
            errors => Problem(errors)
        );
    }
}


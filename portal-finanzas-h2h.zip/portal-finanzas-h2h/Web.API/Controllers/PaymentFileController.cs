using Application.PaymentsFiles.Download;
using Application.Services.GeneratePaymentOrderFile;
using Application.Services.InsertPaymentFileResponse;
using Application.Services.PaymentResponseFileProcessor;
using Application.Services.ReleasePaymentProcess;
using Application.Services.SetStatusPaymentFile;
using Application.Services.UploadPaymentOrderFile;
using Domain.Common;
using MediatR;
using Microsoft.AspNetCore.Mvc;
namespace Web.API.Controllers;

[Route("api/v1/paymentsfiles")]
public class PaymentFileController : ApiController
{
    private readonly ISender _mediator;

	public PaymentFileController(ISender mediator)
	{
		_mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
	}

	/// <summary>
	/// Creates a new payment file
	/// </summary>
	/// <param name="command">The command containing the data for the new payment file</param>
	/// <returns>The result of the operation, which is either a payment file or a list of errors</returns>
	[HttpPost("generate")]
    public async Task<IActionResult> GenerateFile([FromBody] GeneratePaymentOrderFileCommand command)
    {
        var generatePaymentOrderFileCommandResult = await _mediator.Send(command);

        return generatePaymentOrderFileCommandResult.Match(
            generatePaymentOrderFile => Created(string.Empty, generatePaymentOrderFile),
            errors => Problem(errors)
        );
    }

    /// <summary>
    /// Creates a new payment file
    /// </summary>
    /// <param name="command">The command containing the data for the new payment file</param>
    /// <returns>The result of the operation, which is either a payment file or a list of errors</returns>
    [HttpPost("upload")]
    public async Task<IActionResult> UploadFile([FromBody] UploadPaymentOrderFileCommand command)
    {
        var sendPaymentOrderFileCommandResult = await _mediator.Send(command);

        return sendPaymentOrderFileCommandResult.Match(
            sendPaymentOrderFile => Created(string.Empty, sendPaymentOrderFile),
            errors => Problem(errors)
        );
    }


    /// <summary>
    /// Creates a new payment file
    /// </summary>
    /// <param name="command">The command containing the data for the new payment file</param>
    /// <returns>The result of the operation, which is either a payment file or a list of errors</returns>
    [HttpPut("status/send")]
    public async Task<IActionResult> UpdateStatusSend([FromBody] SetStatusPaymentFileCommand command)
    {
        command.Status = Constants.PaymentFileStatus.SENT;
        command.FileType = Constants.PaymentFileType.SEND;
        var updateStatusPaymentFileCommandResult = await _mediator.Send(command);

        return updateStatusPaymentFileCommandResult.Match(
            updateStatusPaymentFile => Created(string.Empty, updateStatusPaymentFile),
            errors => Problem(errors)
        );
    }

    /// <summary>
    /// Creates a new payment file
    /// </summary>
    /// <param name="command">The command containing the data for the new payment file</param>
    /// <returns>The result of the operation, which is either a payment file or a list of errors</returns>
    [HttpPut("status/receive")]
    public async Task<IActionResult> UpdateStatusReceive([FromBody] SetStatusPaymentFileCommand command)
    {
        command.Status = Constants.PaymentFileStatus.RECEIVED;
		command.FileType = Constants.PaymentFileType.RESPONSE;
		var updateStatusPaymentFileCommandResult = await _mediator.Send(command);

        return updateStatusPaymentFileCommandResult.Match(
            updateStatusPaymentFile => Created(string.Empty, updateStatusPaymentFile),
            errors => Problem(errors)
        );
    }

	/// <summary>
	/// Creates a new payment file
	/// </summary>
	/// <param name="command">The command containing the data for the new payment file</param>
	/// <returns>The result of the operation, which is either a payment file or a list of errors</returns>
	[HttpPost("response/processor")]
    public async Task<IActionResult> PaymentResponseFileProcessor([FromBody] PaymentResponseFileProcessorCommand command)
    {
        var paymentResponseFileProcessorCommandResult = await _mediator.Send(command);

        return paymentResponseFileProcessorCommandResult.Match(
            paymentResponseFileProcessor => Ok(paymentResponseFileProcessor),
            errors => Problem(errors)
        );
    }

	/// <summary>
	/// Gets all payment file
	/// </summary>
	/// <returns>The result of the operation, which is either a list of payment file or a list of errors</returns>
	// [HttpGet("download/{idPaymentFile}")]
	// public async Task<IActionResult> GetFileById([FromRoute] int idPaymentFile)
	// {
	//     var downloadPaymentFileQueryResult = await _mediator.Send(new DownloadPaymentFileQuery(idPaymentFile));

	//     return downloadPaymentFileQueryResult.Match(
	//downloadPaymentFile => File(downloadPaymentFile.ArchivoByte, downloadPaymentFile.ContentType, downloadPaymentFile.Nombre),
	//         errors => Problem(errors)
	//     );
	// }

	[HttpGet("download/{idPaymentFile}")]
	public async Task<IActionResult> GetFileById([FromRoute] int idPaymentFile)
	{
		var result = await _mediator.Send(new DownloadPaymentFileQuery(idPaymentFile));

		return result.Match(
			downloadPaymentFile =>
			{
				var contentDisposition = downloadPaymentFile.ContentDisposition;

				var cdHeader = new System.Net.Mime.ContentDisposition
				{
					FileName = downloadPaymentFile.Nombre,
					Inline = contentDisposition == "inline"
				};

				Response.Headers.ContentDisposition = cdHeader.ToString();

				return new FileContentResult(downloadPaymentFile.ArchivoByte, downloadPaymentFile.ContentType);
			},
			errors => Problem(errors)
		);
	}




	/// <summary>
	/// Creates a new payment response file 
	/// </summary>
	/// <param name="command">The command containing the data for the new payment file</param>
	/// <returns>The result of the operation, which is either a payment file or a list of errors</returns>
	[HttpPost("response")]
	public async Task<IActionResult> InsertPaymentFileResponse([FromBody] ProcessPaymentFileResponseCommand command)
	{
		command.Status = Constants.PaymentFileStatus.RECEIVED;
		var insertPaymentFileResponseCommandResult = await _mediator.Send(command);

		return insertPaymentFileResponseCommandResult.Match(
			insertPaymentFileResponse => Created(string.Empty, insertPaymentFileResponse),
			errors => Problem(errors)
		);
	}


    [HttpPost("liberacionPago")]
    public async Task<IActionResult> RecoverByFilename([FromBody] ReleasePaymentFileProcessCommand command)
    {
        var result = await _mediator.Send(command);

        return result.Match(
            value => Ok(value),
            errors => Problem(errors)
        );
    }

}


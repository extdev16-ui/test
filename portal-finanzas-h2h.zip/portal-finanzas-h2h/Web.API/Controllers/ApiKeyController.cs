using Application.ApiKeys.Create;
using Domain.ApiKeys;
using ErrorOr;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace Web.API.Controllers;

[Route("api/v1/apikeys")]
public class ApiKey : ApiController
{
    private readonly ISender _mediator;

    public ApiKey(ISender mediator)
    {
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
    }

    /// <summary>
    /// Creates a new API key
    /// </summary>
    /// <param name="command">The command containing the data for the new API key</param>
    /// <returns>The result of the operation, which is either an API key or a list of errors</returns>
    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateApiKeyCommand command)
    {
        var createApiKeyResult = await _mediator.Send(command);

        return createApiKeyResult.Match(
            auditoria => Ok(),
            errors => Problem(errors)
        );
    }
}


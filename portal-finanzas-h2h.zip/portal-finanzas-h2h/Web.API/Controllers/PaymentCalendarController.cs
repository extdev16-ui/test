using Application.Services.ExistsPaymentCalendar;
using Application.Services.GetDateByPaymentCalendar;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Domain.Common;
using Application.PaymentsFiles.Download;
namespace Web.API.Controllers;

[Route("api/v1/paymentscalendar")]
public class PaymentCalendarController : ApiController
{
    private readonly ISender _mediator;

	public PaymentCalendarController(ISender mediator)
	{
		_mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
	}

	/// <summary>
	/// Gets all payment calendar
	/// </summary>
	/// <returns>The result of the operation, which is either a list of payment file or a list of errors</returns>
	[HttpGet("exists/{code}")]
	public async Task<IActionResult> ExistsPaymentCalendar([FromRoute] string code, [FromQuery] string date)
	{
		var existsPaymentCalendarQueryResult = await _mediator.Send(new ExistsPaymentCalendarQuery(code, date));

		return existsPaymentCalendarQueryResult.Match(
			existsPaymentCalendar => Ok(existsPaymentCalendar),
			errors => Problem(errors)
		);
	}

}


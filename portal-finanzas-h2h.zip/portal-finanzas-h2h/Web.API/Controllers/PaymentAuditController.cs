using Application.PaymentsAudits.Create;
using Application.PaymentsAudits.GetAll;
using ErrorOr;
using MediatR;
using Microsoft.AspNetCore.Mvc;
namespace Web.API.Controllers;

[Route("api/v1/paymentsaudits")]
public class PaymentAuditController : ApiController
{
    private readonly ISender _mediator;

    public PaymentAuditController(ISender mediator)
    {
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
    }

    /// <summary>
    /// Creates a new payment audit
    /// </summary>
    /// <param name="command">The command containing the data for the new payment audit</param>
    /// <returns>The result of the operation, which is either a payment audit or a list of errors</returns>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreatePaymentAuditCommand command)
    {
        var createPaymentAuditResult = await _mediator.Send(command);

        return createPaymentAuditResult.Match(
            paymentAudit => Ok(),
            errors => Problem(errors)
        );
    }


    /// <summary>
    /// Gets all payment audits
    /// </summary>
    /// <returns>The result of the operation, which is either a list of payment audits or a list of errors</returns>
    [HttpGet]
    public async Task<IActionResult> GetAllPaymentAudits()
    {
        var paymentsAuditsResult = await _mediator.Send(new GetAllPaymentAuditQuery());

        return paymentsAuditsResult.Match(
            paymentsAudits => Ok(paymentsAudits),
            errors => Problem(errors)
        );
    }


}


﻿using Amazon.Extensions.NETCore.Setup;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Application.Data;
using Application.Dependencies;
using Application.Dependencies.Models;
using Application.Mappings;
using Application.PaymentsFiles.Common;
using Application.PaymentsFiles.Interfaces;
using Application.PaymentsFiles.ReleasePayment;
using Application.Services;
using Domain.ApiKeys;
using Domain.Catalogs;
using Domain.PaymentsAudits.Interfaces;
using Domain.PaymentsCalendar.Interfaces;
using Domain.PaymentsFiles.Adapter;
using Domain.PaymentsFiles.Adapters;
using Domain.PaymentsFiles.Generators;
using Domain.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Processors;
using Domain.PaymentsFiles.ResponseGet;
using Domain.PaymentsOrders.Interfaces;
using Domain.PaymentsOrdersDetails.Interfaces;
using Domain.PaymentsSettings.Interfaces;
using Domain.PaymentsSettings.Validators;
using Domain.Primitives;
using Domain.ValueObjects.PaymentsFiles;
using ErrorOr;
using Infrastructure.Persistence;
using Infrastructure.Persistence.Providers;
using Infrastructure.Persistence.Repositories;
using Infrastructure.Persistence.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Text.Json;

namespace Infrastructure;

public static class DependencyInjection{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration){
        services.AddPersistence(configuration);
        return services;
    }

     public static IServiceCollection AddPersistence(this IServiceCollection services, IConfiguration configuration){

        services.AddDefaultAWSOptions(configuration.GetAWSOptions());
        services.AddAWSService<IAmazonSecretsManager>();

        services.AddSingleton<DbSecret>(sp =>
        {
            var config = sp.GetRequiredService<IConfiguration>();
            return LoadDbSecret(sp, config);
        });

        //EntityFramework
        services.AddDbContext<ApplicationDbContext>((sp, options) =>
        {
            var dbSecret = sp.GetRequiredService<DbSecret>();
            var connectionString = dbSecret.DBCredentials.GetConnectionString();

            options.UseSqlServer(connectionString);
        });

        //Dapper
        services.AddSingleton<DapperContext>(sp =>
        {
            var dbSecret = sp.GetRequiredService<DbSecret>();
            var connectionString = dbSecret.DBCredentials.GetConnectionString();

            return new DapperContext(connectionString);
        });

        //AutoMapper
        services.AddAutoMapper(typeof(MappingProfile));
        
        services.AddScoped<IApplicationDbContext>(sp => 
                sp.GetRequiredService<ApplicationDbContext>()
        );

        services.AddScoped<IUnitOfWork>(sp => 
                sp.GetRequiredService<ApplicationDbContext>());

        //Repository
        services.AddScoped<IPaymentAuditRepository, PaymentAuditRepository>();
        services.AddScoped<IApiKeyRepository, ApiKeyRepository>();
        services.AddScoped<IPaymentFileWriteRepository, PaymentFileWriteRepository>();
        services.AddScoped<IPaymentFileReadRepository, PaymentFileReadRepository>();
        services.AddScoped<IPaymentOrderRepository, PaymentOrderRepository>();
        services.AddScoped<IPaymentOrderDetailWriteRepository, PaymentOrderDetailWriteRepository>();
        services.AddScoped<IPaymentOrderDetailReadRepository, PaymentOrderDetailReadRepository>();
        services.AddScoped<IMassivePaymentReadRepository, MassivePaymentReadRepository>();
        services.AddScoped<IPaymentSettingRepository, PaymentSettingRepository>();
        services.AddScoped<ICatalogRepository, CatalogRepository>();
		services.AddScoped<IPaymentCalendarRepository, PaymentCalendarRepository>();
        services.AddScoped<IReleasePaymentRepository, ReleasePaymentRepository>();

        //Domain
        services.AddScoped<IPaymentFileGenerator<PaymentFileFormatTxt>, GeneratePaymentFormatTxt>();
        services.AddScoped<IPaymentFileGenerator<PaymentFileFormatXml>, GeneratePaymentFormatXml>();
        services.AddScoped<IPaymentFileGeneratorFactory, PaymentFileGeneratorFactory>();
		services.AddScoped<IPaymentFileAdapter, PaymentFileAdapter>();
		services.AddScoped<IPaymentFileResponseGetter<PaymentFileFormatTxt>, PaymentFileTxtResponseReader>();
		services.AddScoped<IPaymentFileResponseGetter<PaymentFileFormatXml>, PaymentFileXmlResponseReader>();
		services.AddScoped<IPaymentFileResponseGetterFactory, PaymentFileResponseGetterFactory>();

		services.AddScoped<IValidatePaymentSetting, ValidatePaymentSetting>();
        services.AddScoped<IValidatorPaymentFileXml, ValidatorPaymentFileXml>();

		//Services
		services.AddScoped<IPaymentFileSFTP, PaymentFileSFTP>();
		services.AddScoped<ISignaturePaymentFile, SignaturePaymentFile>();

        //Singleton
        services.AddSingleton<ISecretsManagerCredentialsProvider, SecretsManagerCredentialsProvider>();

        services.AddTransient<SomeApplication>();

        return services;
    }

    private static DbSecret LoadDbSecret(IServiceProvider sp, IConfiguration configuration)
    {
        var client = sp.GetRequiredService<IAmazonSecretsManager>();

        var secretName = configuration["AWS:SecretName"];

        if (string.IsNullOrEmpty(secretName))
        {
            throw new Exception("AWS:SecretName no está configurado en appsettings.json");
        }

        var response = client.GetSecretValueAsync(new GetSecretValueRequest
        {
            SecretId = secretName
        }).GetAwaiter().GetResult();

        if (string.IsNullOrEmpty(response.SecretString))
        {
            throw new Exception("El secreto en AWS está vacío o no tiene SecretString");
        }

        var dbSecret = JsonSerializer.Deserialize<DbSecret>(response.SecretString, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });

        if (dbSecret == null)
        {
            throw new Exception("No se pudo deserializar el secreto a DbSecret");
        }

        return dbSecret;
    }
}
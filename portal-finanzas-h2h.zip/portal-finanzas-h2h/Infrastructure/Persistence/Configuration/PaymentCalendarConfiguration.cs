using Domain.PaymentsCalendar;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class PaymentCalendarConfiguration : IEntityTypeConfiguration<PaymentCalendar>{
    public void Configure(EntityTypeBuilder<PaymentCalendar> builder){
        builder.ToTable("mae_calendario_pago", "sch_gespago");
        builder.HasKey(c=> c.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_calendario_pago")
           .ValueGeneratedOnAdd();
        
        builder.HasIndex(e => e.IdCatalogoTipo);   
        builder.Property(c => c.IdCatalogoTipo).HasColumnName("id_catalogo_tipo");        
        builder.HasOne(d => d.CatalogoTipo)
               .WithMany()
               .HasForeignKey(d => d.IdCatalogoTipo)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(e => e.IdConfiguracionPago);   
        builder.Property(c => c.IdConfiguracionPago).HasColumnName("id_configuracion_pago");        
        builder.HasOne(d => d.ConfiguracionPago)
               .WithMany()
               .HasForeignKey(d => d.IdConfiguracionPago)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(c => new { c.Fecha }).IsUnique();

        builder.Property(c => c.Fecha).HasColumnName("fecha").HasColumnType("date");
        builder.Property(c => c.HoraInicio).HasColumnName("hora_inicio").HasMaxLength(20);
        builder.Property(c => c.HoraFin).HasColumnName("hora_fin").HasMaxLength(20);

		builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
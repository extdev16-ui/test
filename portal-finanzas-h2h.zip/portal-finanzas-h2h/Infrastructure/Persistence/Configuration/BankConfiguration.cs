using Domain.Banks;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class BankConfiguration : IEntityTypeConfiguration<Bank>{
    public void Configure(EntityTypeBuilder<Bank> builder){
        builder.ToTable("mae_banco", "sch_gespago");
        builder.HasKey(c=> c.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_banco")
           .ValueGeneratedOnAdd();

        builder.Property(c => c.Nombre).IsRequired().HasMaxLength(50).HasColumnName("nombre");
        builder.Property(c => c.Descripcion).IsRequired().HasMaxLength(100).HasColumnName("descripcion");
        
        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
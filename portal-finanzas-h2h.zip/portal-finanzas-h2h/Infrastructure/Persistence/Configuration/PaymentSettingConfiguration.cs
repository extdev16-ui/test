using Domain.PaymentsSettings;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class PaymentSettingConfiguration : IEntityTypeConfiguration<PaymentSetting>{
    public void Configure(EntityTypeBuilder<PaymentSetting> builder){
        builder.ToTable("mae_configuracion_pago", "sch_gespago");
        builder.HasKey(a=> a.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_configuracion_pago")
           .ValueGeneratedOnAdd();

        builder.Property(a => a.Codigo).HasColumnType("char(3)").HasColumnName("codigo");
        builder.Property(a => a.IdAplicacion).HasColumnName("id_aplicacion");
        builder.Ignore(a=> a.Aplicacion);
        builder.Property(a => a.IdBanco).HasColumnName("id_banco");
        builder.Ignore(a=> a.Banco);
        builder.Property(a => a.IdPlataforma).HasColumnName("id_plataforma");
        builder.Ignore(a=> a.Plataforma);
        builder.Property(a => a.IdModalidad).HasColumnName("id_modalidad");
        builder.Ignore(a=> a.Modalidad);

        builder.Property(a => a.Version).HasColumnName("version");

        builder.Property(a => a.Configuraciones).HasColumnName("configuraciones").HasColumnType("NVARCHAR(MAX)");
        builder.Ignore(a=> a.DetalleConfiguraciones);
        builder.Property(a => a.Reglas).HasColumnName("reglas").HasColumnType("NVARCHAR(MAX)");
        builder.Ignore(a => a.DetalleReglas);
        builder.Property(a => a.Formato).HasColumnName("formato").HasColumnType("NVARCHAR(MAX)");
        builder.Ignore(a => a.DetalleFormato);
		builder.Ignore(a => a.DetalleFormatoTxt);
		builder.Ignore(a => a.DetalleFormatoXml);
		builder.Property(a => a.Errores).HasColumnName("errores").HasColumnType("NVARCHAR(MAX)");
        builder.Ignore(a => a.DetalleErrores);
        builder.Property(a => a.CuentasBancos).HasColumnName("cuentas_bancos").HasColumnType("NVARCHAR(MAX)");
        builder.Ignore(a => a.DetalleBancos);
        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
using Domain.Plataforms;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class PlataformConfiguration : IEntityTypeConfiguration<Plataform>{
    public void Configure(EntityTypeBuilder<Plataform> builder){
        builder.ToTable("mae_tipo_plataforma", "sch_gespago");
        builder.HasKey(c=> c.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_plataforma")
           .ValueGeneratedOnAdd();

        builder.Property(c => c.Nombre).IsRequired().HasMaxLength(50).HasColumnName("nombre");
        builder.Property(c => c.Descripcion).IsRequired().HasMaxLength(100).HasColumnName("descripcion");
                
        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
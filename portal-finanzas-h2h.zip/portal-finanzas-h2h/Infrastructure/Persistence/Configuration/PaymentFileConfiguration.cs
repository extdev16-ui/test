using Domain.PaymentsFiles.Models;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class PaymentFileConfiguration : IEntityTypeConfiguration<PaymentFile>{
    public void Configure(EntityTypeBuilder<PaymentFile> builder){
        builder.ToTable("trx_archivo_pago", "sch_gespago");
        builder.HasKey(c=> c.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_archivo_pago")
           .ValueGeneratedOnAdd();

        builder.HasIndex(e => e.IdCatalogoEstado);   
        builder.Property(c => c.IdCatalogoEstado).HasColumnName("id_catalogo_estado");        
        builder.HasOne(d => d.CatalogoEstado)
               .WithMany()
               .HasForeignKey(d => d.IdCatalogoEstado)
               .OnDelete(DeleteBehavior.Restrict);
        
        builder.HasIndex(e => e.IdCatalogoTipo);   
        builder.Property(c => c.IdCatalogoTipo).HasColumnName("id_catalogo_tipo");        
        builder.HasOne(d => d.CatalogoTipo)
               .WithMany()
               .HasForeignKey(d => d.IdCatalogoTipo)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(e => e.IdConfiguracionPago);   
        builder.Property(c => c.IdConfiguracionPago).HasColumnName("id_configuracion_pago");        
        builder.HasOne(d => d.ConfiguracionPago)
               .WithMany()
               .HasForeignKey(d => d.IdConfiguracionPago)
               .OnDelete(DeleteBehavior.Restrict);


        builder.HasIndex(e => e.IdOrdenPago);
        builder.Property(c => c.IdOrdenPago).HasColumnName("id_orden_pago");
        builder.HasOne(d => d.OrdenPago)
               .WithMany()
               .HasForeignKey(d => d.IdOrdenPago)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasIndex(c => new { c.Nombre, c.IdCatalogoTipo }).IsUnique();

        builder.Property(c => c.Nombre).IsRequired().HasMaxLength(50).HasColumnName("nombre");
        builder.Property(c => c.RutaEnvio).IsRequired().HasMaxLength(200).HasColumnName("ruta_envio");
        builder.Property(c => c.RutaEnvioHistorico).IsRequired().HasMaxLength(200).HasColumnName("ruta_envio_historico");
        builder.Property(c => c.RutaRespuesta).IsRequired().HasMaxLength(200).HasColumnName("ruta_respuesta");
        builder.Property(c => c.RutaRespuestaHistorica).IsRequired().HasMaxLength(200).HasColumnName("ruta_respuesta_historica");

		builder.Property(c => c.Orden).IsRequired().HasColumnName("orden");

		builder.Property(c => c.Fecha).HasColumnName("fecha").HasColumnType("date");

        builder.Ignore(c => c.ArchivoByte);
		builder.Ignore(c => c.ContentType);
		builder.Ignore(c => c.ContentDisposition);

		builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
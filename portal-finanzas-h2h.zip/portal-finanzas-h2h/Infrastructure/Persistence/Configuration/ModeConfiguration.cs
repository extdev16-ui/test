using Domain.Modalities;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class ModeConfiguration : IEntityTypeConfiguration<Mode>{
    public void Configure(EntityTypeBuilder<Mode> builder){
        builder.ToTable("mae_tipo_modalidad", "sch_gespago");
        builder.HasKey(c=> c.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_modalidad")
           .ValueGeneratedOnAdd();
            
        builder.Property(c => c.Nombre).IsRequired().HasMaxLength(50).HasColumnName("nombre");
        builder.Property(c => c.Descripcion).IsRequired().HasMaxLength(100).HasColumnName("descripcion"); 
        builder.Property(c => c.Version).HasColumnName("version");

        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
using Domain.PaymentsOrdersDetails;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class PaymentOrderDetailConfiguration : IEntityTypeConfiguration<PaymentOrderDetail>
{
    public void Configure(EntityTypeBuilder<PaymentOrderDetail> builder)
    {
        builder.ToTable("trx_orden_pago_detalle", "sch_gespago");
        builder.HasKey(a => a.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_orden_pago_detalle")
           .ValueGeneratedOnAdd();

        builder.HasIndex(a => a.IdOrdenPago);
        builder.Property(a => a.IdOrdenPago).HasColumnName("id_orden_pago");
        builder.HasOne(d => d.OrdenPago)
            .WithMany()
            .HasForeignKey(d => d.IdOrdenPago)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Property(a => a.CuentaBeneficiario).HasMaxLength(30).HasColumnName("cuenta_beneficiario");
        builder.Property(a => a.NombreBeneficiario).HasMaxLength(100).HasColumnName("nombre_beneficiario");
        builder.Property(a => a.Monto).HasPrecision(18, 2).HasColumnName("monto");
        builder.Property(a => a.Descripcion).HasColumnName("descripcion");

        builder.Property(a => a.IdCatalogoEstado).HasColumnName("id_catalogo_estado");
        builder.HasOne(d => d.CatalogoEstado)
            .WithMany()
            .HasForeignKey(d => d.IdCatalogoEstado)
            .OnDelete(DeleteBehavior.Restrict);
        
        builder.Property(a => a.CodigoUnico).HasMaxLength(50).HasColumnName("codigo_unico");
        builder.Property(a => a.Ticket).HasMaxLength(20).HasColumnName("ticket");
        builder.Property(a => a.Comentario).HasColumnName("comentario");
      
        builder.Property(c => c.HoraProcesado).IsRequired().HasMaxLength(30).HasColumnName("hora_procesado");
        builder.Property(a => a.CodigoRespuesta).HasColumnType("char(3)").HasColumnName("codigo_respuesta");
        builder.Property(c => c.DescripcionRespuesta).IsRequired().HasMaxLength(100).HasColumnName("descripcion_respuesta");

        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
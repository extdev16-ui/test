using Domain.PaymentsOrders;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Infraestructure.Persistence.Configuracion;

namespace Infrastructure.Persistence.Configuration;

public class PaymentOrderConfiguration : IEntityTypeConfiguration<PaymentOrder>{
    public void Configure(EntityTypeBuilder<PaymentOrder> builder){
        builder.ToTable("trx_orden_pago", "sch_gespago");
        builder.HasKey(a=> a.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_orden_pago")
           .ValueGeneratedOnAdd();

        builder.HasIndex(a => a.IdPagoMasivo);
        builder.Property(a => a.IdPagoMasivo).HasColumnName("id_pago_masivo");
        
        builder.Property(a => a.IdCatalogoEstado).HasColumnName("id_catalogo_estado");
        builder.HasOne(d => d.CatalogoEstado)
            .WithMany()
            .HasForeignKey(d => d.IdCatalogoEstado)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Property(a => a.MontoTotal).HasPrecision(18, 9).HasColumnName("monto_total");

        builder.Property(a => a.IdCatalogoMoneda).HasColumnName("id_catalogo_moneda");
        builder.HasOne(d => d.CatalogoMoneda)
            .WithMany()
            .HasForeignKey(d => d.IdCatalogoMoneda)
            .OnDelete(DeleteBehavior.Restrict);

        builder.Property(a => a.Comentarios).HasColumnName("comentarios");
        
               
        builder.HasIndex(e => e.IdConfiguracionPago);   
        builder.Property(c => c.IdConfiguracionPago).HasColumnName("id_configuracion_pago");        
        builder.HasOne(d => d.ConfiguracionPago)
               .WithMany()
               .HasForeignKey(d => d.IdConfiguracionPago)
               .OnDelete(DeleteBehavior.Restrict);

        builder.Property(a => a.FechaPago).IsRequired().HasColumnName("fecha_pago");

        builder.Property(a => a.FechaEnvio).IsRequired().HasColumnName("fecha_envio").HasMaxLength(30);
        builder.Property(a => a.FechaRespuesta).IsRequired().HasColumnName("fecha_respuesta").HasMaxLength(30);

        //Auditoria
        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
        //Ignore
        builder.Ignore(d => d.Detalle);

    }
}
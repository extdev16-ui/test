using Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infraestructure.Persistence.Configuracion
{
    public static class AuditRecordConfiguration
    {
        public static void ConfigureAuditRecord<T>(OwnedNavigationBuilder<T, AuditRecord> auditRecordBuilder) where T : class
        {
            auditRecordBuilder.Property(a => a.Activo).IsRequired().HasColumnName("activo");
            auditRecordBuilder.Property(a => a.UsuarioCreador).IsRequired().HasMaxLength(30).HasColumnName("usuario_creador");
            auditRecordBuilder.Property(a => a.UsuarioActualizador).IsRequired().HasMaxLength(30).HasColumnName("usuario_actualizador");
            auditRecordBuilder.Property(a => a.HostCreador).IsRequired().HasMaxLength(100).HasColumnName("host_creador");
            auditRecordBuilder.Property(a => a.HostActualizador).IsRequired().HasMaxLength(100).HasColumnName("host_actualizador");
            auditRecordBuilder.Property(a => a.FechaCreacion).IsRequired().HasColumnName("fecha_creacion");
            auditRecordBuilder.Property(a => a.FechaActualizacion).IsRequired().HasColumnName("fecha_actualizacion");
            auditRecordBuilder.Property(a => a.AppCreador).IsRequired().HasMaxLength(50).HasColumnName("app_creador");
            auditRecordBuilder.Property(a => a.AppActualizador).IsRequired().HasMaxLength(50).HasColumnName("app_actualizador");
        }
    }
}
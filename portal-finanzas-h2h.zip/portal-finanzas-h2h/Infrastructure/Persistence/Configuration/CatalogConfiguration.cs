using Domain.Catalogs;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class CatalogConfiguration : IEntityTypeConfiguration<Catalog>{
    public void Configure(EntityTypeBuilder<Catalog> builder){
        builder.ToTable("mae_catalogo", "sch_gespago");
        builder.HasKey(a=> a.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_catalogo")
           .ValueGeneratedOnAdd();

        builder.Property(a => a.Tipo).HasColumnName("tipo_catalogo");
        
        builder.Property(a => a.Codigo).HasColumnType("char(3)").HasColumnName("codigo");

        builder.Property(a => a.Nombre).HasMaxLength(50).HasColumnName("nombre");
        builder.Property(a => a.NombreAlternativo).HasMaxLength(50).HasColumnName("nombre_alternativo");
        builder.Property(a => a.Descripcion).HasColumnName("descripcion");
        builder.Property(a => a.Etiqueta).HasMaxLength(30).HasColumnName("etiqueta");

        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
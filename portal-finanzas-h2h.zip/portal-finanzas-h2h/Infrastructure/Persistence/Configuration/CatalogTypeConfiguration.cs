using Domain.CatalogsTypes;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class CatalogTypeConfiguration : IEntityTypeConfiguration<CatalogType>{
    public void Configure(EntityTypeBuilder<CatalogType> builder){
        builder.ToTable("mae_tipo_catalogo", "sch_gespago");
        builder.HasKey(a=> a.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_tipo_catalogo")
           .ValueGeneratedOnAdd();

        builder.Property(a => a.Codigo).HasColumnType("char(3)").HasColumnName("codigo");
        builder.Property(a => a.Nombre).HasMaxLength(50).HasColumnName("nombre");
        builder.Property(a => a.Descripcion).HasColumnName("descripcion");
        
        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
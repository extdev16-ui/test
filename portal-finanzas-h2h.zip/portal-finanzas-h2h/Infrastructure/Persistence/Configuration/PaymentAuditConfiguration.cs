using Domain.PaymentsAudits;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class AuditoriaConfiguration : IEntityTypeConfiguration<PaymentAudit>{
    public void Configure(EntityTypeBuilder<PaymentAudit> builder){
        builder.ToTable("aud_auditoria_pago", "sch_gespago");
        builder.HasKey(a=> a.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_auditoria_pago")
           .ValueGeneratedOnAdd();

        builder.HasIndex(a => a.IdOrdenPago);
        builder.Property(a => a.IdOrdenPago).HasColumnName("id_orden_pago");
        builder.Ignore(a => a.OrdenPago); 

        builder.HasIndex(a => a.IdOrdenPagoDetalle);
        builder.Property(a => a.IdOrdenPagoDetalle).HasColumnName("id_orden_pago_detalle");

        builder.Property(a => a.IdPagoMasivo).HasColumnName("id_pago_masivo");

        builder.Property(a => a.Accion).HasColumnName("accion").HasMaxLength(60);
        builder.Property(a => a.Detalle).HasColumnName("detalle");
        
        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
        
    }

    
}
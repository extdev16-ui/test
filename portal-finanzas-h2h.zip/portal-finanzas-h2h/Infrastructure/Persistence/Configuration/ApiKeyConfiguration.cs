using Domain.ApiKeys;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class ApiKeyConfiguration : IEntityTypeConfiguration<ApiKey>{
    public void Configure(EntityTypeBuilder<ApiKey> builder){
        builder.ToTable("mae_apikey", "sch_gespago");
        builder.HasKey(c=> c.Id);
        builder.HasIndex(e => e.Id);
        builder.Property(d => d.Id).HasColumnName("id_apikey")
           .ValueGeneratedOnAdd();

        builder.HasIndex(c=> c.Key).IsUnique();
        builder.Property(c=> c.Key).HasMaxLength(100).IsRequired().HasColumnName("key");

        builder.Property(a => a.IdAplicacion).HasColumnName("id_aplicacion");
        builder.Ignore(d => d.Aplicacion);

        builder.Property(c=> c.FechaExpiracion).IsRequired().HasColumnName("fecha_expiracion");

        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
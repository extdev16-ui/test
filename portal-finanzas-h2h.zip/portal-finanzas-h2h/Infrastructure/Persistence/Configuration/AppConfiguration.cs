using Domain.Apps;
using Infraestructure.Persistence.Configuracion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration;

public class AppConfiguration : IEntityTypeConfiguration<App>{
    public void Configure(EntityTypeBuilder<App> builder){
        builder.ToTable("mae_aplicacion", "sch_gespago");
        builder.HasKey(c=> c.Id);
        builder.HasIndex(a => a.Id);
        builder.Property(a => a.Id).HasColumnName("id_aplicacion")
           .ValueGeneratedOnAdd();

        builder.Property(c => c.Nombre).IsRequired().HasMaxLength(50).HasColumnName("nombre");
        builder.Property(c => c.Descripcion).IsRequired().HasMaxLength(100).HasColumnName("descripcion");
        
        builder.OwnsOne(c => c.RegistroAuditoria, auditRecordBuilder =>
        {
            AuditRecordConfiguration.ConfigureAuditRecord(auditRecordBuilder);
        });
    }
}
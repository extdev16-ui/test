﻿using Application.Dependencies;
using Application.Dependencies.Models;
using ErrorOr;
using Infrastructure.Common.Logging;
using Microsoft.Extensions.Logging;
using System.Net.Http.Headers;
using System.Text.Json;

namespace Infrastructure.Persistence.Services;

public class VaultService : IVaultService
{
	private readonly HttpClient _httpClient;
	private readonly ILogger<VaultService> _logger;
	public VaultService(HttpClient httpClient, ILogger<VaultService> logger)
	{
		_httpClient = httpClient;
		_logger = logger;
	}

	public async Task<ErrorOr<DbSecret>> GetDatabaseCredentialsAsync(VaultRequest request)
	{
		try
		{
			_httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", request.Token);

			var response = await _httpClient.GetAsync(request.Url);
			if (!response.IsSuccessStatusCode)
			{
				return new DbSecret();
			}

			var responseData = await response.Content.ReadAsStringAsync();

			using var document = JsonDocument.Parse(responseData);
			var root = document.RootElement;

			var secretData = root.GetProperty("data").GetProperty("data");

			var options = new JsonSerializerOptions
			{
				PropertyNameCaseInsensitive = true
			};
			var credentials = JsonSerializer.Deserialize<DbSecret>(secretData, options);

			if (credentials is null)
				return Error.Failure("Database Credentials", "No se pudieron obtener las credenciales de la base de datos.");

			return credentials;
		}
		catch (Exception ex)
		{
			_logger.LogException(ex);
			return Error.Failure("Database Credentials", "No se pudieron obtener las credenciales de la base de datos.");
		}
	}
}

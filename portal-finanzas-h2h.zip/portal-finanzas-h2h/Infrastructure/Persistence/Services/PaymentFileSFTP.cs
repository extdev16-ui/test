using Application.Dependencies;
using Application.Dependencies.Models;
using Application.PaymentsFiles.Interfaces;
using Application.PaymentsFiles.Request;
using Domain.PaymentsFiles.Models;
using Infrastructure.Common.Logging;
using Infrastructure.Persistence.Providers;
using Microsoft.Extensions.Logging;
using NPOI.SS.Formula.Functions;
using Renci.SshNet;
using Renci.SshNet.Common;
using System.Text;
using static Domain.Common.Constants;

namespace Infrastructure.Persistence.Services;

public class PaymentFileSFTP : IPaymentFileSFTP
{

	private readonly ISecretsManagerCredentialsProvider _secretProvider;

	private readonly ILogger<PaymentFileSFTP> _logger;

	public PaymentFileSFTP(ISecretsManagerCredentialsProvider secretProvider, ILogger<PaymentFileSFTP> logger)
	{
        _secretProvider = secretProvider;
		_logger = logger;
	}

	public async Task<byte[]> Generate(string concatenatedContent)
	{
		using var memoryStream = new MemoryStream();
		using var streamWriter = new StreamWriter(memoryStream, new UTF8Encoding(false));
		await streamWriter.WriteAsync(concatenatedContent);

		await streamWriter.FlushAsync();
		memoryStream.Position = 0;
		return memoryStream.ToArray();
	}

	public async Task<bool> UploadToFtps(UploadToFtpsRequest uploadToFtpsRequest)
	{
		var connectionInfo = GetConnectionInfo(uploadToFtpsRequest.HistoricalFtps, uploadToFtpsRequest.PaymentSettingCode);

		using SftpClient sftpClient = new(connectionInfo);

		await Task.Run(() =>
		{
			sftpClient.Connect();

			string directoryPath = Path.GetDirectoryName(uploadToFtpsRequest.PathFtps)?.Replace("\\", "/") ?? "";

			if (!string.IsNullOrEmpty(directoryPath))
			{
				CreateDirectoriesRecursively(sftpClient, directoryPath);
			}

			using MemoryStream stream = new(uploadToFtpsRequest.FileBuffer);
			stream.Position = 0;
			sftpClient.UploadFile(stream, uploadToFtpsRequest.PathFtps, true);
			sftpClient.Disconnect();
		});

		return true;
	}
    public async Task<bool> SendToFtps(SendToFtpsRequest sendToFtpsRequest)
	{
		try
		{
			var connectionInfoHistorical = GetConnectionInfo(Domain.Common.Constants.HISTORICAL_SFTP, sendToFtpsRequest.PaymentSettingCode);
			using var sftpClientHistorical = new SftpClient(connectionInfoHistorical);
			var connectionInfo = GetConnectionInfo(Domain.Common.Constants.TRANSACCTION_SFTP, sendToFtpsRequest.PaymentSettingCode);
			using var sftpClient = new SftpClient(connectionInfo);

			await Task.Run(() =>
			{
				sftpClientHistorical.Connect();
				sftpClient.Connect();

				string ftpsDirectoryDestinationRoute = Path.GetDirectoryName(sendToFtpsRequest.FtpsDestinationRoute)?.Replace("\\", "/") ?? "";

				if (!string.IsNullOrEmpty(ftpsDirectoryDestinationRoute))
				{
					CreateDirectoriesRecursively(sftpClient, ftpsDirectoryDestinationRoute);
				}

				using var memoryStream = new MemoryStream();
				sftpClientHistorical.DownloadFile(sendToFtpsRequest.FtpsSourceRoute, memoryStream);

				memoryStream.Position = 0;

				sftpClient.UploadFile(memoryStream, sendToFtpsRequest.FtpsDestinationRoute, true);

				if (sendToFtpsRequest.Delete)
					sftpClientHistorical.DeleteFile(sendToFtpsRequest.FtpsSourceRoute);

				sftpClientHistorical.Disconnect();
				sftpClient.Disconnect();
			});

			return true;
		}
		catch (Exception ex)
		{
			_logger.LogException(ex);
			return false; 
		}
	}
	public async Task<bool> SendToFtpsHistorical(SendToFtpsRequest sendToFtpsRequest)
	{
		try
		{
			var connectionInfo = GetConnectionInfo(Domain.Common.Constants.TRANSACCTION_SFTP, sendToFtpsRequest.PaymentSettingCode);
			using var sftpClient = new SftpClient(connectionInfo);
			var connectionInfoHistorical = GetConnectionInfo(Domain.Common.Constants.HISTORICAL_SFTP, sendToFtpsRequest.PaymentSettingCode);
			using var sftpClientHistorical = new SftpClient(connectionInfoHistorical);

			await Task.Run(() =>
			{
				sftpClient.Connect();
				sftpClientHistorical.Connect();

				string ftpsDirectoryDestinationRoute = Path.GetDirectoryName(sendToFtpsRequest.FtpsDestinationRoute)?.Replace("\\", "/") ?? "";

				if (!string.IsNullOrEmpty(ftpsDirectoryDestinationRoute))
				{
					CreateDirectoriesRecursively(sftpClientHistorical, ftpsDirectoryDestinationRoute);
				}

				using var memoryStream = new MemoryStream();
				sftpClient.DownloadFile(sendToFtpsRequest.FtpsSourceRoute, memoryStream);

				memoryStream.Position = 0;

				sftpClientHistorical.UploadFile(memoryStream, sendToFtpsRequest.FtpsDestinationRoute, true);

				if (sendToFtpsRequest.Delete)
					sftpClient.DeleteFile(sendToFtpsRequest.FtpsSourceRoute);

				sftpClient.Disconnect();
				sftpClientHistorical.Disconnect();
			});

			return true;
		}
		catch(Exception ex)
		{
			_logger.LogException(ex);
			return false;
		}
	}

	public async Task<List<PaymentFileResponse>> GetFilesByRemoteDirectory(FileToFtpsRequest fileToFtpsRequest)
	{
		List<PaymentFileResponse> fileResponsePaymentFiles = [];

		var connectionInfo = GetConnectionInfo(fileToFtpsRequest.HistoricalSFtp, fileToFtpsRequest.PaymentSettingCode);

		using var sftpClient = new SftpClient(connectionInfo);

		await Task.Run(async () =>
		{
			sftpClient.Connect();

			IEnumerable<Renci.SshNet.Sftp.ISftpFile> files = sftpClient.ListDirectory(fileToFtpsRequest.PathFtps).Where(f => !f.IsDirectory);

			foreach (var file in files)
			{
				using var memoryStream = new MemoryStream();

				sftpClient.DownloadFile(file.FullName, memoryStream);

				memoryStream.Position = 0;

				using var reader = new StreamReader(memoryStream);

				string fileContent = await reader.ReadToEndAsync();

				fileResponsePaymentFiles.Add(new PaymentFileResponse(file.Name, fileContent));
			}

			sftpClient.Disconnect();
		});

		return fileResponsePaymentFiles;
	}

	public async Task<bool> DeleteFileFromFtp(FileToFtpsRequest fileToFtpsRequest)
	{
		var connectionInfo = GetConnectionInfo(fileToFtpsRequest.HistoricalSFtp, fileToFtpsRequest.PaymentSettingCode);
		using var sftpClient = new SftpClient(connectionInfo);

		await Task.Run(() =>
		{
			sftpClient.Connect();

			if (sftpClient.Exists(fileToFtpsRequest.PathFtps))
			{
				sftpClient.Delete(fileToFtpsRequest.PathFtps);
			}

			sftpClient.Disconnect();
		});

		return true;
	}

	public async Task<byte[]?> GetFileToFtps(FileToFtpsRequest fileToFtpsRequest)
	{
		try
		{
			using var memoryStream = new MemoryStream();
			var connectionInfo = GetConnectionInfo(fileToFtpsRequest.HistoricalSFtp, fileToFtpsRequest.PaymentSettingCode);
			using var sftpClient = new SftpClient(connectionInfo);

			await Task.Run(() =>
			{

				sftpClient.Connect();
                _logger.LogInformation("Intentando descargar archivo desde: {Path}", fileToFtpsRequest.PathFtps);

                if (!sftpClient.Exists(fileToFtpsRequest.PathFtps))
                {
                    _logger.LogError("Error SFTP: Archivo no encontrado en la ruta '{Path}'.", fileToFtpsRequest.PathFtps);
                    sftpClient.Disconnect();

                    throw new SftpPathNotFoundException($"No such file found at: {fileToFtpsRequest.PathFtps}");
                }

                sftpClient.DownloadFile(fileToFtpsRequest.PathFtps, memoryStream);

				sftpClient.Disconnect();

			});

			memoryStream.Seek(0, SeekOrigin.Begin);

			return memoryStream.ToArray();
		}
		catch (Exception ex)
		{
			_logger.LogException(ex);
			return null;
		}
	}

	public async Task<string?> GetContentToFtps(FileToFtpsRequest fileToFtpsRequest)
	{
		try
		{
			string? fileContent = null;
			var connectionInfo = GetConnectionInfo(fileToFtpsRequest.HistoricalSFtp, fileToFtpsRequest.PaymentSettingCode);
			using var sftpClient = new SftpClient(connectionInfo);

			await Task.Run(async () =>
			{

				sftpClient.Connect();
				using var memoryStream = new MemoryStream();

				sftpClient.DownloadFile(fileToFtpsRequest.PathFtps, memoryStream);

				memoryStream.Position = 0;

				using var reader = new StreamReader(memoryStream);

				fileContent = await reader.ReadToEndAsync();

				sftpClient.Disconnect();

			});

			return fileContent;
		}
		catch (Exception ex)
		{
			_logger.LogException(ex);
			return null;
		}
	}

	private static void CreateDirectoriesRecursively(SftpClient sftpClient, string fullPath)
	{
		if (fullPath.StartsWith("/"))
			fullPath = fullPath.TrimStart('/');

		var directories = fullPath.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
		string currentPath = "";

		foreach (var dir in directories)
		{
			currentPath = string.IsNullOrEmpty(currentPath) ? dir : $"{currentPath}/{dir}";

			if (!sftpClient.Exists(currentPath))
			{
				sftpClient.CreateDirectory(currentPath);
			}
		}
	}

    private ConnectionInfo GetConnectionInfo(bool historicalFtps, string paymentSettingCode)
    {
        var dbSecret = _secretProvider
            .GetDbSecretAsync()
            .GetAwaiter()
            .GetResult();

        var sftpCredentials = dbSecret.SFTPCredentials
            .Find(c => c.PaymentSettingCode == paymentSettingCode)
            ?? throw new Exception("No se encontr� credenciales SFTP");

        var activeSettings = historicalFtps
            ? sftpCredentials.SFTPSettingsHistorical
            : sftpCredentials.SFTPSettings;

        if (activeSettings.Type == SftpConnectionType.PrivateKey)
        {
            var privateKey = activeSettings.Key;

            if (string.IsNullOrWhiteSpace(privateKey))
            {
                throw new Exception("La llave privada no est� configurada en los secretos para esta conexi�n.");
            }

            using var keyStream = new MemoryStream(Encoding.UTF8.GetBytes(privateKey));
            var privateKeyFile = new PrivateKeyFile(keyStream);

            return new ConnectionInfo(
                activeSettings.Host,
                activeSettings.Port,
                activeSettings.User,
                new PrivateKeyAuthenticationMethod(
                    activeSettings.User,
                    new[] { privateKeyFile }
                )
            );
        }
        else
        {
            return new ConnectionInfo(
                activeSettings.Host,
                activeSettings.Port,
                activeSettings.User,
                new PasswordAuthenticationMethod(
                    activeSettings.User,
                    activeSettings.Password
                )
            );
        }
    }
}
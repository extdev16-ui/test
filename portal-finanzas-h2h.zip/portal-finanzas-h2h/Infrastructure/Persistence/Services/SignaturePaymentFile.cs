﻿using Application.Dependencies;
using Domain.PaymentsFiles.Processors;
using Infrastructure.Common.Logging;
using Microsoft.Extensions.Logging;
using PgpCore;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;

namespace Infrastructure.Persistence.Services;
public class SignaturePaymentFile : ISignaturePaymentFile
{
	private readonly ILogger<SignaturePaymentFile> _logger;
	public SignaturePaymentFile(ILogger<SignaturePaymentFile> logger)
	{
		_logger = logger;
	}
	public string SignFileHash(byte[] gpgBytes, string password, string fileContent, string execGPG)
	{
		string signature = string.Empty;
		try
		{
			using MemoryStream gpgStream = new(gpgBytes);
			using MemoryStream decryptedKeyStream = new();

			//1. Create proccess for execute gpg with input/output 
			ProcessStartInfo psi = new()
			{
				FileName = execGPG,
				Arguments = $"--batch --yes --passphrase {password} --decrypt",
				RedirectStandardInput = true,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				UseShellExecute = false,
				CreateNoWindow = true
			};

			using (Process process = new()
			{ StartInfo = psi })
			{
				process.Start();

				//Write the encrypted data to the GPG input
				gpgStream.CopyTo(process.StandardInput.BaseStream);
				process.StandardInput.BaseStream.Close();

				//Read the decrypted output into memory
				process.StandardOutput.BaseStream.CopyTo(decryptedKeyStream);
				process.WaitForExit();

				if (process.ExitCode != 0)
				{
					string error = process.StandardError.ReadToEnd();
					throw new Exception($"Error al descifrar la clave GPG: {error}");
				}
			}

			//2. Create Hash to fileContent
			byte[] xmlHash = GenerateHashFileContent(fileContent);
			string base64Hash = Convert.ToBase64String(xmlHash);
			using MemoryStream hashStream = new(xmlHash);

			//3. Save the decrypted pass to a string 
			decryptedKeyStream.Position = 0;
			string privateKey = new StreamReader(decryptedKeyStream).ReadToEnd();

			//4. Convert private key to MemoryStream
			byte[] privateKeyBytes = Encoding.UTF8.GetBytes(privateKey);
			MemoryStream privateKeyStream = new(privateKeyBytes);

			//5. Sign the file Content
			using (PGP pgp = new(new EncryptionKeys(privateKeyStream, password)))
			{
				signature = pgp.SignArmoredString(fileContent);
			}

			byte[] hashSignature = ExtractSignatureBytes(signature);
			string hashSignatureBase64 = Convert.ToBase64String(hashSignature);

			return hashSignatureBase64;
		}
		catch(Exception ex)
		{
			_logger.LogException(ex);
			throw new Exception(ex.Message);
		}

	}

	private static byte[] GenerateHashFileContent(string content)
	{
		return SHA256.HashData(Encoding.UTF8.GetBytes(content));
	}

	private static byte[] GenerateHashSignature(string armoredSignature)
	{
		byte[] signatureBytes = ExtractSignatureBytes(armoredSignature);
		return SHA256.HashData(signatureBytes);
	}

	private static byte[] ExtractSignatureBytes(string armoredSignature)
	{
		string base64Content = armoredSignature
			.Replace("-----BEGIN PGP MESSAGE-----", "")
			.Replace("-----END PGP MESSAGE-----", "")
			.Trim();

		string[] lines = base64Content.Split('\n');
		List<string> filteredLines = [];

		foreach (var line in lines)
		{
			if (!line.StartsWith("Version:") && !line.StartsWith("="))
			{
				filteredLines.Add(line.Trim());
			}
		}

		string cleanBase64 = string.Join("", filteredLines);
		return Convert.FromBase64String(cleanBase64);
	}

}

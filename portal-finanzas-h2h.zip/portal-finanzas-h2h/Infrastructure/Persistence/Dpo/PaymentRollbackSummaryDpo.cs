﻿namespace Infrastructure.Persistence.Dpo
{
    public sealed class PaymentRollbackSummaryDpo
    {
        public int IdPagoMasivo { get; init; }
        public int CantidadRetiros { get; init; }
    }
}

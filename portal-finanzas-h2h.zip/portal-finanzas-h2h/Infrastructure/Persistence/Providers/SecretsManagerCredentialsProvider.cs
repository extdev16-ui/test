﻿using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Application.Dependencies;
using Application.Dependencies.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace Infrastructure.Persistence.Providers;

public class SecretsManagerCredentialsProvider : ISecretsManagerCredentialsProvider
{
	private readonly DbSecret _dbSecret;
    private readonly IAmazonSecretsManager _secretsManager;
    private readonly ILogger<SecretsManagerCredentialsProvider> _logger;
    private readonly IConfiguration _configuration;
    private DbSecret? _cachedSecret;

    public SecretsManagerCredentialsProvider(DbSecret dbSecret,
        IAmazonSecretsManager secretsManager,
        IConfiguration configuration,
        ILogger<SecretsManagerCredentialsProvider> logger)
	{
        _dbSecret = dbSecret;
        _secretsManager = secretsManager;
        _configuration = configuration;
        _logger = logger;
	}

	public async Task<string> GetSecretAsync(string secretName)
    {
        try
        {
            var request = new GetSecretValueRequest
            {
                SecretId = secretName
            };

            var response = await _secretsManager.GetSecretValueAsync(request);

            return response.SecretString;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo secreto {SecretName}", secretName);
            throw;
        }
    }

    public async Task<DbSecret> GetDbSecretAsync()
    {
        if (_cachedSecret != null)
            return _cachedSecret;

        try
        {
            var secretName = _configuration["AWS:SecretName"];

            if (string.IsNullOrEmpty(secretName))
                throw new Exception("AWS:SecretName no configurado");

            var response = await _secretsManager.GetSecretValueAsync(new GetSecretValueRequest
            {
                SecretId = secretName
            });

            if (string.IsNullOrEmpty(response.SecretString))
                throw new Exception("SecretString vacío");

            _cachedSecret = JsonSerializer.Deserialize<DbSecret>(
                response.SecretString,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (_cachedSecret == null)
                throw new Exception("Error deserializando DbSecret");

            return _cachedSecret;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error cargando DbSecret desde Secrets Manager");
            throw;
        }
    }

    public string GetApiKeyByApp(string app = "001")
	{
		if (_dbSecret == null)
		{
			_logger.LogError("_dbSecret es null. No se han cargado las credenciales desde Secret Manager.");
			throw new NullReferenceException("_dbSecret es null.");
		}

		if (_dbSecret.ApiKeys == null)
		{
			_logger.LogError("_dbSecret.ApiKeys es null. No hay claves API cargadas.");
			throw new NullReferenceException("_dbSecret.ApiKeys es null.");
		}

		_logger.LogInformation("Se encontraron {Count} API Keys en Secret Manager.", _dbSecret.ApiKeys.Count);

		var apiKeyObj = _dbSecret.ApiKeys.Find(c => c.App == app);

		if (apiKeyObj == null)
		{
			_logger.LogError("No se encontró una API Key para App: {App}.", app);
			throw new KeyNotFoundException($"No se encontró una API Key para App: {app}");
		}

		_logger.LogInformation("Se encontró API Key para App: {App}.", app);
		return apiKeyObj.Key;
	}

	public PGPkey? GetPgpKeyByPaymentSetting(string paymentSettingCode) => _dbSecret.PGPkeys.Find(c => c.PaymentSettingCode == paymentSettingCode) ?? null;


}

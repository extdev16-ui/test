﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class Host_To_HostV2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "sch_gespago");

            migrationBuilder.CreateTable(
                name: "aud_auditoria_pago",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_auditoria_pago = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    id_orden_pago = table.Column<int>(type: "int", nullable: false),
                    id_orden_pago_detalle = table.Column<int>(type: "int", nullable: false),
                    accion = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: false),
                    detalle = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_aud_auditoria_pago", x => x.id_auditoria_pago);
                });

            migrationBuilder.CreateTable(
                name: "mae_apikey",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_apikey = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    key = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    id_aplicacion = table.Column<int>(type: "int", nullable: false),
                    fecha_expiracion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_apikey", x => x.id_apikey);
                });

            migrationBuilder.CreateTable(
                name: "mae_aplicacion",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_aplicacion = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_aplicacion", x => x.id_aplicacion);
                });

            migrationBuilder.CreateTable(
                name: "mae_banco",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_banco = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_banco", x => x.id_banco);
                });

            migrationBuilder.CreateTable(
                name: "mae_catalogo",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_catalogo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    codigo = table.Column<string>(type: "char(3)", nullable: false),
                    nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    nombre_alternativo = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    tipo_catalogo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    etiqueta = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_catalogo", x => x.id_catalogo);
                });

            migrationBuilder.CreateTable(
                name: "mae_configuracion_pago",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_configuracion_pago = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    codigo = table.Column<string>(type: "char(3)", nullable: false),
                    id_aplicacion = table.Column<int>(type: "int", nullable: false),
                    id_banco = table.Column<int>(type: "int", nullable: false),
                    id_plataforma = table.Column<int>(type: "int", nullable: false),
                    id_modalidad = table.Column<int>(type: "int", nullable: false),
                    version = table.Column<int>(type: "int", nullable: false),
                    configuraciones = table.Column<string>(type: "NVARCHAR(MAX)", nullable: false),
                    reglas = table.Column<string>(type: "NVARCHAR(MAX)", nullable: false),
                    formato = table.Column<string>(type: "NVARCHAR(MAX)", nullable: false),
                    errores = table.Column<string>(type: "NVARCHAR(MAX)", nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_configuracion_pago", x => x.id_configuracion_pago);
                });

            migrationBuilder.CreateTable(
                name: "mae_tipo_catalogo",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_tipo_catalogo = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    codigo = table.Column<string>(type: "char(3)", nullable: false),
                    nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_tipo_catalogo", x => x.id_tipo_catalogo);
                });

            migrationBuilder.CreateTable(
                name: "mae_tipo_modalidad",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_modalidad = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    version = table.Column<int>(type: "int", nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_tipo_modalidad", x => x.id_modalidad);
                });

            migrationBuilder.CreateTable(
                name: "mae_tipo_plataforma",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_plataforma = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_tipo_plataforma", x => x.id_plataforma);
                });

            migrationBuilder.CreateTable(
                name: "trx_orden_pago",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_orden_pago = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    id_pago_masivo = table.Column<int>(type: "int", nullable: false),
                    id_catalogo_estado = table.Column<int>(type: "int", nullable: false),
                    monto_total = table.Column<decimal>(type: "decimal(18,9)", precision: 18, scale: 9, nullable: false),
                    id_catalogo_moneda = table.Column<int>(type: "int", nullable: false),
                    comentarios = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    id_configuracion_pago = table.Column<int>(type: "int", nullable: false),
                    fecha_pago = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_envio = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    fecha_respuesta = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_trx_orden_pago", x => x.id_orden_pago);
                    table.ForeignKey(
                        name: "FK_trx_orden_pago_mae_catalogo_id_catalogo_estado",
                        column: x => x.id_catalogo_estado,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_catalogo",
                        principalColumn: "id_catalogo",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_trx_orden_pago_mae_catalogo_id_catalogo_moneda",
                        column: x => x.id_catalogo_moneda,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_catalogo",
                        principalColumn: "id_catalogo",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_trx_orden_pago_mae_configuracion_pago_id_configuracion_pago",
                        column: x => x.id_configuracion_pago,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_configuracion_pago",
                        principalColumn: "id_configuracion_pago",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "trx_archivo_pago",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_archivo_pago = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    nombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ruta_envio = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    ruta_envio_historico = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    ruta_respuesta = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    ruta_respuesta_historica = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    fecha = table.Column<DateTime>(type: "date", nullable: false),
                    id_catalogo_estado = table.Column<int>(type: "int", nullable: false),
                    id_catalogo_tipo = table.Column<int>(type: "int", nullable: false),
                    id_configuracion_pago = table.Column<int>(type: "int", nullable: false),
                    id_orden_pago = table.Column<int>(type: "int", nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_trx_archivo_pago", x => x.id_archivo_pago);
                    table.ForeignKey(
                        name: "FK_trx_archivo_pago_mae_catalogo_id_catalogo_estado",
                        column: x => x.id_catalogo_estado,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_catalogo",
                        principalColumn: "id_catalogo",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_trx_archivo_pago_mae_catalogo_id_catalogo_tipo",
                        column: x => x.id_catalogo_tipo,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_catalogo",
                        principalColumn: "id_catalogo",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_trx_archivo_pago_mae_configuracion_pago_id_configuracion_pago",
                        column: x => x.id_configuracion_pago,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_configuracion_pago",
                        principalColumn: "id_configuracion_pago",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_trx_archivo_pago_trx_orden_pago_id_orden_pago",
                        column: x => x.id_orden_pago,
                        principalSchema: "sch_gespago",
                        principalTable: "trx_orden_pago",
                        principalColumn: "id_orden_pago",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "trx_orden_pago_detalle",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_orden_pago_detalle = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    id_orden_pago = table.Column<int>(type: "int", nullable: false),
                    cuenta_beneficiario = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    nombre_beneficiario = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    monto = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    id_catalogo_estado = table.Column<int>(type: "int", nullable: false),
                    codigo_unico = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ticket = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    comentario = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    hora_procesado = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    codigo_respuesta = table.Column<string>(type: "char(3)", nullable: false),
                    descripcion_respuesta = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_trx_orden_pago_detalle", x => x.id_orden_pago_detalle);
                    table.ForeignKey(
                        name: "FK_trx_orden_pago_detalle_mae_catalogo_id_catalogo_estado",
                        column: x => x.id_catalogo_estado,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_catalogo",
                        principalColumn: "id_catalogo",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_trx_orden_pago_detalle_trx_orden_pago_id_orden_pago",
                        column: x => x.id_orden_pago,
                        principalSchema: "sch_gespago",
                        principalTable: "trx_orden_pago",
                        principalColumn: "id_orden_pago",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_aud_auditoria_pago_id_auditoria_pago",
                schema: "sch_gespago",
                table: "aud_auditoria_pago",
                column: "id_auditoria_pago");

            migrationBuilder.CreateIndex(
                name: "IX_aud_auditoria_pago_id_orden_pago",
                schema: "sch_gespago",
                table: "aud_auditoria_pago",
                column: "id_orden_pago");

            migrationBuilder.CreateIndex(
                name: "IX_aud_auditoria_pago_id_orden_pago_detalle",
                schema: "sch_gespago",
                table: "aud_auditoria_pago",
                column: "id_orden_pago_detalle");

            migrationBuilder.CreateIndex(
                name: "IX_mae_apikey_id_apikey",
                schema: "sch_gespago",
                table: "mae_apikey",
                column: "id_apikey");

            migrationBuilder.CreateIndex(
                name: "IX_mae_apikey_key",
                schema: "sch_gespago",
                table: "mae_apikey",
                column: "key",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_mae_aplicacion_id_aplicacion",
                schema: "sch_gespago",
                table: "mae_aplicacion",
                column: "id_aplicacion");

            migrationBuilder.CreateIndex(
                name: "IX_mae_banco_id_banco",
                schema: "sch_gespago",
                table: "mae_banco",
                column: "id_banco");

            migrationBuilder.CreateIndex(
                name: "IX_mae_catalogo_id_catalogo",
                schema: "sch_gespago",
                table: "mae_catalogo",
                column: "id_catalogo");

            migrationBuilder.CreateIndex(
                name: "IX_mae_configuracion_pago_id_configuracion_pago",
                schema: "sch_gespago",
                table: "mae_configuracion_pago",
                column: "id_configuracion_pago");

            migrationBuilder.CreateIndex(
                name: "IX_mae_tipo_catalogo_id_tipo_catalogo",
                schema: "sch_gespago",
                table: "mae_tipo_catalogo",
                column: "id_tipo_catalogo");

            migrationBuilder.CreateIndex(
                name: "IX_mae_tipo_modalidad_id_modalidad",
                schema: "sch_gespago",
                table: "mae_tipo_modalidad",
                column: "id_modalidad");

            migrationBuilder.CreateIndex(
                name: "IX_mae_tipo_plataforma_id_plataforma",
                schema: "sch_gespago",
                table: "mae_tipo_plataforma",
                column: "id_plataforma");

            migrationBuilder.CreateIndex(
                name: "IX_trx_archivo_pago_id_archivo_pago",
                schema: "sch_gespago",
                table: "trx_archivo_pago",
                column: "id_archivo_pago");

            migrationBuilder.CreateIndex(
                name: "IX_trx_archivo_pago_id_catalogo_estado",
                schema: "sch_gespago",
                table: "trx_archivo_pago",
                column: "id_catalogo_estado");

            migrationBuilder.CreateIndex(
                name: "IX_trx_archivo_pago_id_catalogo_tipo",
                schema: "sch_gespago",
                table: "trx_archivo_pago",
                column: "id_catalogo_tipo");

            migrationBuilder.CreateIndex(
                name: "IX_trx_archivo_pago_id_configuracion_pago",
                schema: "sch_gespago",
                table: "trx_archivo_pago",
                column: "id_configuracion_pago");

            migrationBuilder.CreateIndex(
                name: "IX_trx_archivo_pago_id_orden_pago",
                schema: "sch_gespago",
                table: "trx_archivo_pago",
                column: "id_orden_pago");

            migrationBuilder.CreateIndex(
                name: "IX_trx_archivo_pago_nombre_id_catalogo_tipo",
                schema: "sch_gespago",
                table: "trx_archivo_pago",
                columns: new[] { "nombre", "id_catalogo_tipo" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_trx_orden_pago_id_catalogo_estado",
                schema: "sch_gespago",
                table: "trx_orden_pago",
                column: "id_catalogo_estado");

            migrationBuilder.CreateIndex(
                name: "IX_trx_orden_pago_id_catalogo_moneda",
                schema: "sch_gespago",
                table: "trx_orden_pago",
                column: "id_catalogo_moneda");

            migrationBuilder.CreateIndex(
                name: "IX_trx_orden_pago_id_configuracion_pago",
                schema: "sch_gespago",
                table: "trx_orden_pago",
                column: "id_configuracion_pago");

            migrationBuilder.CreateIndex(
                name: "IX_trx_orden_pago_id_orden_pago",
                schema: "sch_gespago",
                table: "trx_orden_pago",
                column: "id_orden_pago");

            migrationBuilder.CreateIndex(
                name: "IX_trx_orden_pago_id_pago_masivo",
                schema: "sch_gespago",
                table: "trx_orden_pago",
                column: "id_pago_masivo");

            migrationBuilder.CreateIndex(
                name: "IX_trx_orden_pago_detalle_id_catalogo_estado",
                schema: "sch_gespago",
                table: "trx_orden_pago_detalle",
                column: "id_catalogo_estado");

            migrationBuilder.CreateIndex(
                name: "IX_trx_orden_pago_detalle_id_orden_pago",
                schema: "sch_gespago",
                table: "trx_orden_pago_detalle",
                column: "id_orden_pago");

            migrationBuilder.CreateIndex(
                name: "IX_trx_orden_pago_detalle_id_orden_pago_detalle",
                schema: "sch_gespago",
                table: "trx_orden_pago_detalle",
                column: "id_orden_pago_detalle");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "aud_auditoria_pago",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "mae_apikey",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "mae_aplicacion",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "mae_banco",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "mae_tipo_catalogo",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "mae_tipo_modalidad",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "mae_tipo_plataforma",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "trx_archivo_pago",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "trx_orden_pago_detalle",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "trx_orden_pago",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "mae_catalogo",
                schema: "sch_gespago");

            migrationBuilder.DropTable(
                name: "mae_configuracion_pago",
                schema: "sch_gespago");
        }
    }
}

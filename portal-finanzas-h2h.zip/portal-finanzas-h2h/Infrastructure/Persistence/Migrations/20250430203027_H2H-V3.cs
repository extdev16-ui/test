﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class H2HV3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "mae_calendario_pago",
                schema: "sch_gespago",
                columns: table => new
                {
                    id_calendario_pago = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    fecha = table.Column<DateTime>(type: "date", nullable: false),
                    hora_inicio = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    hora_fin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    id_catalogo_tipo = table.Column<int>(type: "int", nullable: false),
                    id_configuracion_pago = table.Column<int>(type: "int", nullable: false),
                    activo = table.Column<bool>(type: "bit", nullable: false),
                    usuario_creador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    usuario_actualizador = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    host_creador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    host_actualizador = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    app_creador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    app_actualizador = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mae_calendario_pago", x => x.id_calendario_pago);
                    table.ForeignKey(
                        name: "FK_mae_calendario_pago_mae_catalogo_id_catalogo_tipo",
                        column: x => x.id_catalogo_tipo,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_catalogo",
                        principalColumn: "id_catalogo",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_mae_calendario_pago_mae_configuracion_pago_id_configuracion_pago",
                        column: x => x.id_configuracion_pago,
                        principalSchema: "sch_gespago",
                        principalTable: "mae_configuracion_pago",
                        principalColumn: "id_configuracion_pago",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_mae_calendario_pago_fecha",
                schema: "sch_gespago",
                table: "mae_calendario_pago",
                column: "fecha",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_mae_calendario_pago_id_calendario_pago",
                schema: "sch_gespago",
                table: "mae_calendario_pago",
                column: "id_calendario_pago");

            migrationBuilder.CreateIndex(
                name: "IX_mae_calendario_pago_id_catalogo_tipo",
                schema: "sch_gespago",
                table: "mae_calendario_pago",
                column: "id_catalogo_tipo");

            migrationBuilder.CreateIndex(
                name: "IX_mae_calendario_pago_id_configuracion_pago",
                schema: "sch_gespago",
                table: "mae_calendario_pago",
                column: "id_configuracion_pago");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "mae_calendario_pago",
                schema: "sch_gespago");
        }
    }
}

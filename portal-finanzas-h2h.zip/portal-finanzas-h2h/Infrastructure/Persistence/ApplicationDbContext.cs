using Application.Data;
using Domain.Primitives;
using Domain.PaymentsAudits;
using Domain.ApiKeys;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Domain.PaymentsOrders;
using Domain.PaymentsOrdersDetails;
using Domain.PaymentsSettings;
using Domain.Catalogs;
using Microsoft.EntityFrameworkCore.Storage;
using Domain.PaymentsCalendar;
using Domain.PaymentsFiles.Models;

namespace Infrastructure.Persistence;

public class ApplicationDbContext : DbContext, IApplicationDbContext, IUnitOfWork
{
    public readonly IPublisher _publiser;
    private IDbContextTransaction? _currentTransaction;


    public ApplicationDbContext(DbContextOptions options, IPublisher publiser) : base(options)
    {
        _publiser = publiser ?? throw new ArgumentNullException(nameof(publiser));
    }

    public DbSet<PaymentAudit> paymentAudit { get; set;}
    public DbSet<ApiKey> apiKey { get; set;}
    public DbSet<PaymentFile> paymentFile { get; set; }
    public DbSet<PaymentOrder> paymentOrder { get; set; }
    public DbSet<PaymentOrderDetail> paymentOrderDetail { get; set; }
    public DbSet<PaymentSetting> paymentSetting { get; set; }
    public DbSet<Catalog> catalog { get; set; }
	public DbSet<PaymentCalendar> paymentCalendar { get; set; }

	protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken()){
        var domainEvents = ChangeTracker.Entries<AggregateRoot>()
        .Select(e=> e.Entity)
        .Where(e=> e.GetDomainEvents().Any())
        .SelectMany(e=> e.GetDomainEvents());

        var result = await base.SaveChangesAsync(cancellationToken);

        foreach(var domainEvent in domainEvents){
            await _publiser.Publish(domainEvent, cancellationToken);
        }

        return result;

    }


    // M�todos para manejar las transacciones
    public async Task BeginTransactionAsync(CancellationToken cancellationToken = default)
    {
        if (_currentTransaction != null)
        {
            return;
        }

        _currentTransaction = await Database.BeginTransactionAsync(cancellationToken);
    }

    public async Task CommitTransactionAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            if (_currentTransaction != null)
            {
                await _currentTransaction.CommitAsync(cancellationToken);
            }
        }
        catch
        {
            await RollbackTransactionAsync(cancellationToken);
            throw;
        }
        finally
        {
            if (_currentTransaction != null)
            {
                await _currentTransaction.DisposeAsync();
                _currentTransaction = null;
            }
        }
    }

    public async Task RollbackTransactionAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            if (_currentTransaction != null)
            {
                await _currentTransaction.RollbackAsync(cancellationToken);
            }
        }
        finally
        {
            if (_currentTransaction != null)
            {
                await _currentTransaction.DisposeAsync();
                _currentTransaction = null;
            }
        }
    }


}
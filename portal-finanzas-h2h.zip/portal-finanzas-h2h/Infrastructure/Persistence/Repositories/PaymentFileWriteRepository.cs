using Domain.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Models;
using Domain.PaymentsOrdersDetails;
using Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace Infrastructure.Persistence.Repositories;

public class PaymentFileWriteRepository : IPaymentFileWriteRepository
{
	private readonly ApplicationDbContext _context;

	public PaymentFileWriteRepository(ApplicationDbContext context)
	{
		_context = context ?? throw new ArgumentNullException(nameof(context));
	}

	public void Add(PaymentFile paymentFile) => _context.paymentFile.Add(paymentFile);
	public void Update(PaymentFile paymentFile)
	{
		_context.paymentFile.Update(paymentFile);

		var trackedEntity = _context.ChangeTracker.Entries<PaymentFile>()
							   .FirstOrDefault(e => e.Entity.Id == paymentFile.Id);

		if (trackedEntity == null)
		{
			var entry = _context.Entry(paymentFile);

			entry.Property(po => po.RutaEnvio).IsModified = true;
			entry.Property(po => po.RutaEnvioHistorico).IsModified = true;
			entry.Property(po => po.RutaRespuesta).IsModified = true;
			entry.Property(po => po.RutaRespuestaHistorica).IsModified = true;
			entry.Property(po => po.IdCatalogoEstado).IsModified = true;
			entry.Property(po => po.IdCatalogoTipo).IsModified = false;
			paymentFile.RegistroAuditoria = paymentFile.RegistroAuditoria;
		}
		else
		{
			paymentFile = trackedEntity.Entity;

			paymentFile.RutaEnvio = paymentFile.RutaEnvio;
			paymentFile.RutaEnvioHistorico = paymentFile.RutaEnvioHistorico;
			paymentFile.RutaRespuesta = paymentFile.RutaRespuesta;
			paymentFile.RutaRespuestaHistorica = paymentFile.RutaRespuestaHistorica;
			paymentFile.IdCatalogoEstado = paymentFile.IdCatalogoEstado;
			paymentFile.RegistroAuditoria = paymentFile.RegistroAuditoria;
		}

	}

	public async Task<int> GetHigherCode(DateTime dateNow, int idPaymentSetting, string type)
	{
		int result = await _context.paymentFile
			.Include(pf => pf.CatalogoTipo)
			.Where(c => c.Fecha.Date == dateNow.Date && c.CatalogoTipo.Codigo == type && c.ConfiguracionPago.Id == idPaymentSetting)
			.CountAsync();

		return result + 1;
	}
	public async Task<List<PaymentFile>?> GetByPaymentOrder(int idPaymentOrder, string type)
	{
		return await _context.paymentFile
		.Include(pf => pf.ConfiguracionPago)
		.Include(pf => pf.CatalogoTipo)
		.Where(po => po.IdOrdenPago == idPaymentOrder && po.CatalogoTipo.Codigo == type && po.RegistroAuditoria.Activo)
		.ToListAsync();
	}

	public async Task<PaymentFile?> GetByMassivePayment(int idMassivePayment, string type)
	{
		return await _context.paymentFile
			.Include(pf => pf.CatalogoEstado)
			.Include(pf => pf.CatalogoTipo)
			.Where(pf => pf.IdOrdenPago > 0
					&& pf.OrdenPago.IdPagoMasivo == idMassivePayment
					&& pf.CatalogoTipo.Codigo == type
					&& pf.RegistroAuditoria.Activo
					&& pf.OrdenPago.RegistroAuditoria.Activo)
			.FirstOrDefaultAsync();
	}


	public async Task<PaymentFile?> GetById(int id)
	{
		return await _context.paymentFile
			.Include(ce => ce.CatalogoEstado)
			.Include(ct => ct.CatalogoTipo)
			.Include(cp => cp.ConfiguracionPago)
			.Where(pf => pf.Id == id && pf.RegistroAuditoria.Activo)
			.FirstOrDefaultAsync();
	}
}
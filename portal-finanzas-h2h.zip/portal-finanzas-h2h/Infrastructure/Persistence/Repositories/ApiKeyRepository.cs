using Domain.ApiKeys;
using System.Data;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Persistence.Repositories;

public class ApiKeyRepository : IApiKeyRepository
{
    private readonly ApplicationDbContext _context;

    public ApiKeyRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public void Add(ApiKey apiKey) => _context.apiKey.Add(apiKey);

    public async Task<bool> ExistByKey(string key)
    {
        return await _context.apiKey
           .Where(po => po.Key == key && po.RegistroAuditoria.Activo).AnyAsync();
    }
}
using Microsoft.EntityFrameworkCore;
using Domain.Catalogs;

namespace Infrastructure.Persistence.Repositories;

public class CatalogRepository : ICatalogRepository
{
    private readonly ApplicationDbContext _context;

    public CatalogRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<Catalog?> GetIdByCode(string codeType, string code)
    {
        Catalog? catalog = await _context.catalog
                        .Where(po => po.Tipo == codeType && po.Codigo == code
                        && po.RegistroAuditoria.Activo
                        ).FirstOrDefaultAsync();

        return catalog!;
    }
	public async Task<Catalog?> GetById(int id)
	{
		Catalog? catalog = await _context.catalog
						.Where(po => po.Id == id
						&& po.RegistroAuditoria.Activo
						).FirstOrDefaultAsync();

		return catalog!;
	}
}
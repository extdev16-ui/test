using Domain.PaymentsFiles;
using Domain.PaymentsOrders;
using Domain.PaymentsOrders.Interfaces;
using Domain.PaymentsOrdersDetails;
using Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Persistence.Repositories;

public class PaymentOrderRepository : IPaymentOrderRepository
{
    private readonly ApplicationDbContext _context;

    public PaymentOrderRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }
    public async Task<PaymentOrder?> GetByMassivePayment(int idMassivePayment)
    {
        //return await _context.paymentOrder
        //   .Where(po => po.IdPagoMasivo == idMassivePayment && po.RegistroAuditoria.Activo).AsNoTracking().FirstOrDefaultAsync();
        return await _context.paymentOrder
         .FromSqlRaw("SELECT * FROM  sch_gespago.trx_orden_pago WITH (NOLOCK) WHERE id_pago_masivo = {0} AND activo = 1", idMassivePayment)
         .AsNoTracking()
         .FirstOrDefaultAsync();
    }
    public async Task<AuditRecord?> GetAuditRecordById(int id)
    {
        return await _context.paymentOrder
           .AsNoTracking()
           .Include(po => po.RegistroAuditoria)
           .Where(po => po.Id == id && po.RegistroAuditoria.Activo)
           .Select(po => po.RegistroAuditoria)
           .FirstOrDefaultAsync();
    }

    public void Add(PaymentOrder paymentOrder) => _context.paymentOrder.Add(paymentOrder);
    public void Update(PaymentOrder paymentOrder, AuditRecord auditRecord)
    {
        var trackedEntity = _context.ChangeTracker.Entries<PaymentOrder>()
                               .FirstOrDefault(e => e.Entity.Id == paymentOrder.Id);

        if (trackedEntity == null)
        {
            var entry = _context.Entry(paymentOrder);

            entry.Property(po => po.IdCatalogoEstado).IsModified = true;

            if(paymentOrder.CatalogoEstado.Codigo == Domain.Common.Constants.PaymentOrderStatus.CONFIRMED)
                entry.Property(po => po.FechaEnvio).IsModified = true;
            
            entry.Property(po => po.FechaRespuesta).IsModified = true;
            paymentOrder.RegistroAuditoria = auditRecord;
        }
        else
        {
            paymentOrder = trackedEntity.Entity;

            paymentOrder.IdCatalogoEstado = paymentOrder.IdCatalogoEstado;

            if (paymentOrder.CatalogoEstado.Codigo == Domain.Common.Constants.PaymentOrderStatus.CONFIRMED)
                paymentOrder.FechaEnvio = paymentOrder.FechaEnvio;

            paymentOrder.FechaRespuesta = paymentOrder.FechaRespuesta;
            paymentOrder.RegistroAuditoria = auditRecord;
        }
    }

}
﻿using Application.PaymentsFiles.ReleasePayment;
using Application.PaymentsFiles.ReleasePayment.Requests;
using Application.PaymentsFiles.ReleasePayment.Results;
using Dapper;
using System.Data;

namespace Infrastructure.Persistence.Repositories;

public sealed class ReleasePaymentRepository : IReleasePaymentRepository
{
    private readonly DapperContext _contextDapper;

    public ReleasePaymentRepository(DapperContext contextDapper)
    {
        _contextDapper = contextDapper;
    }

    public async Task<ReleasePaymentResult> ReleasePaymentAsync(
        ReleasePaymentRequest request,
        CancellationToken cancellationToken)
    {
        using IDbConnection connection = _contextDapper.CreateConnection();

        DynamicParameters parameters = new();
        parameters.Add("@idPagoMasivo", request.IdPagoMasivo, DbType.Int32);
        parameters.Add("@usuario_id", request.UserId, DbType.Int32);

        var result = (await connection.QueryAsync<long>(
            new CommandDefinition(
                "[sch_pagos].[usp_proceso_liberacion_pago_masivo]",
                parameters,
                commandType: CommandType.StoredProcedure,
                cancellationToken: cancellationToken
            )
        )).ToList();

        return new ReleasePaymentResult
        {
            IdPagoMasivo = request.IdPagoMasivo,
            CantidadRetiros = result.Count,
            IdsRetiro = result
        };
    }

    public async Task<int> ReleasePaymentOrderAsync(
        ReleasePaymentRequest request,
        CancellationToken cancellationToken)
    {
        using IDbConnection connection = _contextDapper.CreateConnection();

        DynamicParameters parameters = new();
        parameters.Add("@idPagoMasivo", request.IdPagoMasivo, DbType.Int32);
        parameters.Add("@usuario_id", request.UserId, DbType.Int32);

        var affectedRows = await connection.ExecuteAsync(
            new CommandDefinition(
                "[sch_gespago].[usp_proceso_liberacion_orden_pago]",
                parameters,
                commandType: CommandType.StoredProcedure,
                cancellationToken: cancellationToken
            )
        );

        return affectedRows;
    }
}
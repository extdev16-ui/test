using Dapper;
using Domain.Catalogs;
using Domain.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Models;
using Domain.PaymentsOrdersDetails.Common;
using Domain.ValueObjects;
using System.Data;

namespace Infrastructure.Persistence.Repositories;

public class PaymentFileReadRepository : IPaymentFileReadRepository
{
    private readonly DapperContext _context;

    public PaymentFileReadRepository(DapperContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }
    public async Task<List<PaymentFile>> GetByFileNames(string fileNames)
    {
        using IDbConnection connection = _context.CreateConnection();
        DynamicParameters parameters = new();
        parameters.Add("@nombres", fileNames, DbType.String);

        var paymentFiles = await connection.QueryAsync<PaymentFile, Catalog, Catalog, AuditRecord, PaymentFile>(
                "[sch_gespago].[ssp_archivo_pago_nombres]",
                (paymentFile, catalogEstado,catalogTipo, auditRecord) =>
                {
                    paymentFile.CatalogoEstado = catalogEstado;
					paymentFile.CatalogoTipo = catalogTipo;
					paymentFile.RegistroAuditoria = auditRecord;
                    return paymentFile;
                },
                parameters,
                splitOn: "Codigo, Codigo, UsuarioCreador",
                commandType: CommandType.StoredProcedure
            );

        return paymentFiles.ToList();
    }
}
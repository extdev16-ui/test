using Domain.PaymentsOrders;
using Microsoft.EntityFrameworkCore;
using Domain.PaymentsSettings;
using Domain.PaymentsSettings.Interfaces;

namespace Infrastructure.Persistence.Repositories;

public class PaymentSettingRepository : IPaymentSettingRepository
{
    private readonly ApplicationDbContext _context;
    public PaymentSettingRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }
    public async Task<PaymentSetting?> GetPaymentSettingById(int idPaymentSetting)
    {
        PaymentSetting? paymentSetting = await _context.paymentSetting
                        .Where(po => po.Id == idPaymentSetting
                        && po.RegistroAuditoria.Activo
                        ).FirstOrDefaultAsync();

        return paymentSetting;
    }
    public async Task<PaymentSetting?> GetPaymentSettingByCode(string code)
    {
        PaymentSetting? paymentSetting = await _context.paymentSetting
                        .Where(po => po.Codigo == code
                        && po.RegistroAuditoria.Activo
                        ).FirstOrDefaultAsync();

        return paymentSetting;
    }

    public void Add(PaymentOrder paymentOrder) => _context.paymentOrder.Add(paymentOrder);
    
}
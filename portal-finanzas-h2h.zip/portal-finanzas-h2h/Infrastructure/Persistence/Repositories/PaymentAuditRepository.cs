using Domain.PaymentsAudits;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Domain.PaymentsAudits.Interfaces;

namespace Infrastructure.Persistence.Repositories;

public class PaymentAuditRepository : IPaymentAuditRepository
{
    private readonly ApplicationDbContext _context;

    public PaymentAuditRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public void Add(PaymentAudit paymentAudit) => _context.paymentAudit.Add(paymentAudit);
    public void MassiveAdd(List<PaymentAudit> paymentAudits) => _context.paymentAudit.AddRange(paymentAudits);

    //public async Task<List<PaymentAudit>> GetAll() => await _context.paymentAudit.AsNoTracking().ToListAsync();

	public async Task<List<PaymentAudit>> GetAll()
	{
		return await _context.paymentAudit
			.FromSqlRaw("SELECT * FROM sch_gespago.aud_auditoria_pago WITH (NOLOCK)")
			.AsNoTracking()
			.ToListAsync();
	}

}
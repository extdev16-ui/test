using Dapper;
using System.Data;
using Application.Data;
using Domain.MassivesPayments.Common;

namespace Infrastructure.Persistence.Repositories;

public class MassivePaymentReadRepository : IMassivePaymentReadRepository
{
    private readonly DapperContext _contextDapper;

    public MassivePaymentReadRepository(DapperContext contextDapper)
    {
        _contextDapper = contextDapper;
    }

    public async Task<IEnumerable<MassivePaymentResponse>> GetById(int id)
    {
        using IDbConnection connection = _contextDapper.CreateConnection();

        DynamicParameters parameters = new();
        parameters.Add("@id_pago_masivo", id, DbType.Int32);

        return await connection.QueryAsync<MassivePaymentResponse>(
            "[sch_gespago].[ssp_pago_masivo_por_id]",
            parameters,
            commandType: CommandType.StoredProcedure
        );
    }

    public async Task<List<MassivePaymentDetailResponse>> GetDetailByIdMassivePayment(int id)
    {
        using IDbConnection connection = _contextDapper.CreateConnection();
        DynamicParameters parameters = new();
        parameters.Add("@id_pago_masivo", id, DbType.Int32);

        IEnumerable<MassivePaymentDetailResponse> massivePaymentDetailResponses = await connection.QueryAsync<MassivePaymentDetailResponse>(
            "[sch_gespago].[ssp_pago_masivo_detalle_por_id_pago_masivo]",
            parameters,
            commandType: CommandType.StoredProcedure
        );

        return massivePaymentDetailResponses.ToList();
    }


    public async void UpdateStatusMassivePayment(int idMassivePayment, int status, int userModifier)
    {
        using IDbConnection connection = _contextDapper.CreateConnection();

        DynamicParameters parameters = new();
        parameters.Add("@id_pago_masivo", idMassivePayment, DbType.Int32);
        parameters.Add("@estado", status, DbType.Int32);
        parameters.Add("@usuario_modifica_id", userModifier, DbType.Int32);

        IEnumerable<MassivePaymentDetailResponse> massivePaymentDetailResponses = await connection.QueryAsync<MassivePaymentDetailResponse>(
            "[sch_gespago].[usp_pago_masivo_estado]",
            parameters,
            commandType: CommandType.StoredProcedure
        );

    }
    public async void UpdateStatusMassivePaymentDetail(string uniqueCode, int idMassivePayment, int status, int userModifier)
    {
        using IDbConnection connection = _contextDapper.CreateConnection();

        DynamicParameters parameters = new();
        parameters.Add("@codigo_unico", uniqueCode, DbType.String);
        parameters.Add("@id_pago_masivo", idMassivePayment, DbType.Int32);
        parameters.Add("@estado", status, DbType.Int32);
        parameters.Add("@usuario_modifica_id", userModifier, DbType.Int32);

        IEnumerable<MassivePaymentDetailResponse> massivePaymentDetailResponses = await connection.QueryAsync<MassivePaymentDetailResponse>(
            "[sch_gespago].[usp_pago_masivo_detalle_estado]",
            parameters,
            commandType: CommandType.StoredProcedure
        );

    }
}
using Dapper;
using Domain.PaymentsOrdersDetails;
using Domain.PaymentsOrdersDetails.Common;
using Domain.PaymentsOrdersDetails.Interfaces;
using Domain.ValueObjects;
using System.Data;

namespace Infrastructure.Persistence.Repositories;

public class PaymentOrderDetailWriteRepository : IPaymentOrderDetailWriteRepository
{
    private readonly ApplicationDbContext _context;

    public PaymentOrderDetailWriteRepository(ApplicationDbContext context, DapperContext contextDapper)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }
    
    public void Add(List<PaymentOrderDetail> paymentsOrdersDetails) => _context.paymentOrderDetail.AddRange(paymentsOrdersDetails);
    public void Update(PaymentOrderDetail paymentOrderDetail) => _context.paymentOrderDetail.Add(paymentOrderDetail);
    public void UpdateUniqueCode(PaymentOrderDetail paymentOrderDetail) => _context.paymentOrderDetail.Add(paymentOrderDetail);
    public void Update(PaymentOrderDetail paymentOrderDetail, AuditRecord auditRecord)
    {
        var trackedEntity = _context.ChangeTracker.Entries<PaymentOrderDetail>()
                               .FirstOrDefault(e => e.Entity.Id == paymentOrderDetail.Id);

        if (trackedEntity == null)
        {
            var entry = _context.Entry(paymentOrderDetail);

            entry.Property(po => po.IdCatalogoEstado).IsModified = true;
            entry.Property(po => po.HoraProcesado).IsModified = true;
            entry.Property(po => po.CodigoRespuesta).IsModified = true;
            entry.Property(po => po.DescripcionRespuesta).IsModified = true;
            paymentOrderDetail.RegistroAuditoria = auditRecord;
        }
        else
        {
            paymentOrderDetail = trackedEntity.Entity;

            paymentOrderDetail.IdCatalogoEstado = paymentOrderDetail.IdCatalogoEstado;
            paymentOrderDetail.HoraProcesado = paymentOrderDetail.HoraProcesado;
            paymentOrderDetail.CodigoRespuesta = paymentOrderDetail.CodigoRespuesta;
            paymentOrderDetail.DescripcionRespuesta = paymentOrderDetail.DescripcionRespuesta;
            paymentOrderDetail.RegistroAuditoria = auditRecord;
        }
    }
}
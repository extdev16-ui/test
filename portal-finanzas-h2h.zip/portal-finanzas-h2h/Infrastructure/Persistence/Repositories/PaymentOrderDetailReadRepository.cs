using Dapper;
using Domain.Catalogs;
using Domain.PaymentsFiles;
using Domain.PaymentsOrders;
using Domain.PaymentsOrdersDetails.Common;
using Domain.PaymentsOrdersDetails.Interfaces;
using Domain.ValueObjects;
using System.Data;

namespace Infrastructure.Persistence.Repositories;

public class PaymentOrderDetailReadRepository : IPaymentOrderDetailReadRepository
{
    private readonly DapperContext _context;

    public PaymentOrderDetailReadRepository(DapperContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }
    
    public async Task<bool> ExistsDuplicate(List<string> uniqueCodes)
    {
        string uniqueCodesString = string.Join(",", uniqueCodes);

        using IDbConnection connection = _context.CreateConnection();

        DynamicParameters parameters = new();
        parameters.Add("@codigos_unicos", uniqueCodesString, DbType.String);

        var contador = await connection.QueryAsync<int>(
            "[sch_gespago].[ssp_orden_pago_detalle_por_codigo]",
            parameters,
            commandType: CommandType.StoredProcedure
        );

        return contador.First() > 0;
    }
    public async Task<List<PaymentOrderDetailDto>> GetByUniqueCodes(string uniqueCodes, int idPaymentOrder)
    {
        using IDbConnection connection = _context.CreateConnection();
        DynamicParameters parameters = new();
        parameters.Add("@id_orden_pago", idPaymentOrder, DbType.Int32);
        parameters.Add("@codigosunicos", uniqueCodes, DbType.String);

        var paymentOrderDetailDtos = await connection.QueryAsync<PaymentOrderDetailDto, AuditRecord, PaymentOrderDetailDto>(
                "[sch_gespago].[ssp_orden_pago_detalle_codigos_unicos]",
                (detailDto, auditRecord) =>
                {
                    detailDto.RegistroAuditoria = auditRecord;
                    return detailDto;
                },
                parameters,
                splitOn: "UsuarioCreador",
                commandType: CommandType.StoredProcedure
            );

        return paymentOrderDetailDtos.ToList();
    }


    public async Task<List<PaymentOrderDetailDto>> GetByStatusPaymentResponseFile(string codeStatusPaymentFile)
    {
        using IDbConnection connection = _context.CreateConnection();
        DynamicParameters parameters = new();
        parameters.Add("@estado_archivo_pago", codeStatusPaymentFile, DbType.String);

        var paymentOrderDetailDtos = await connection.QueryAsync<PaymentOrderDetailDto, AuditRecord, PaymentOrderDetailDto>(
                "[sch_gespago].[ssp_orden_pago_detalle_estado_archivo_pago]",
                (paymentOrderDetailDto, auditRecord) =>
                {
                    paymentOrderDetailDto.RegistroAuditoria = auditRecord;
                    return paymentOrderDetailDto;
                },
                parameters,
                splitOn: "UsuarioCreador",
                commandType: CommandType.StoredProcedure
            );

        return paymentOrderDetailDtos.ToList();
    }
}
using Domain.PaymentsCalendar;
using Domain.PaymentsCalendar.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Persistence.Repositories;

public class PaymentCalendarRepository : IPaymentCalendarRepository
{
	private readonly ApplicationDbContext _context;

	public PaymentCalendarRepository(ApplicationDbContext context)
	{
		_context = context ?? throw new ArgumentNullException(nameof(context));
	}
	public async Task<List<PaymentCalendar>?> GetByPaymentSetting(string code)
	{
		return await _context.paymentCalendar
			.Include(c => c.ConfiguracionPago)
		 .Where(po => po.ConfiguracionPago.Codigo == code && po.RegistroAuditoria.Activo).ToListAsync();
	}
	public async Task<PaymentCalendar?> GetByDate(string code, DateTime date, string type)
	{
		return await _context.paymentCalendar
			.Include(cp => cp.ConfiguracionPago)
			.Include(ct => ct.CatalogoTipo)
		 .Where(po => po.ConfiguracionPago.Codigo == code && po.CatalogoTipo.Codigo == type && po.Fecha.Date == date.Date && po.RegistroAuditoria.Activo).FirstOrDefaultAsync();
	}
}
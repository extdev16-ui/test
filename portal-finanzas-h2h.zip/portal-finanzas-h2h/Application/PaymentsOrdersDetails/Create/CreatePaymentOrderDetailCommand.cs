using Domain.MassivesPayments.Common;
using Domain.PaymentsOrders;
using ErrorOr;
using MediatR;

namespace Application.PaymentsOrdersDetails.Create;

public record CreatePaymentOrderDetailCommand(
    PaymentOrder PaymentOrder,
    List<MassivePaymentDetailResponse> MassivePaymentDetailResponses,
    string UserCreated
) : IRequest<ErrorOr<PaymentOrder>>;

using FluentValidation;

namespace Application.PaymentsOrdersDetails.Create;

public class CreatePaymentOrderDetailCommandValidator : AbstractValidator<CreatePaymentOrderDetailCommand>
{
    public CreatePaymentOrderDetailCommandValidator()
    {

        RuleFor(r => r.PaymentOrder).NotNull()
             .WithName("Orden Pago");
        RuleFor(r => r.MassivePaymentDetailResponses).NotNull()
             .WithName("Orden Pago Masivo Detalle");
        RuleFor(r => r.UserCreated).NotEmpty().NotNull()
             .WithName("Usuario Creador");
    }
}
using Application.Services;
using Domain.Primitives;
using Domain.ValueObjects;
using ErrorOr;
using MediatR;
using Domain.PaymentsOrders;
using Domain.Catalogs;
using Domain.PaymentsOrdersDetails;
using static Domain.Common.Constants;
using Application.PaymentsAudits.Create;
using Domain.PaymentsOrdersDetails.Interfaces;

namespace Application.PaymentsOrdersDetails.Create;

internal sealed class CreatePaymentOrderDetailCommandHandler : IRequestHandler<CreatePaymentOrderDetailCommand, ErrorOr<PaymentOrder>>
{
    private readonly IPaymentOrderDetailWriteRepository _paymentOrderDetailRepository;
    private readonly ICatalogRepository _catalogRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ISender _mediator;
    private readonly SomeApplication _someApplication;

    public CreatePaymentOrderDetailCommandHandler(
        IPaymentOrderDetailWriteRepository paymentOrderDetailRepository,
        ICatalogRepository catalogRepository,
        IUnitOfWork unitOfWork,
        ISender mediator,
        SomeApplication someApplication)
    {
        _paymentOrderDetailRepository = paymentOrderDetailRepository ?? throw new ArgumentNullException(nameof(paymentOrderDetailRepository));
        _catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
        _someApplication = someApplication;
    }

    public async Task<ErrorOr<PaymentOrder>> Handle(CreatePaymentOrderDetailCommand command, CancellationToken cancellationToken)
    {
        //Insert Payment Order Detail
        if (command.PaymentOrder.Id == 0)
            return Error.Failure("Orden de Pago", "No se realiz� la inserci�n de orden pago.");

        command.PaymentOrder.Detalle = new List<PaymentOrderDetail>();
        foreach (var massivePaymentDetailResponse in command.MassivePaymentDetailResponses)
        {
            if (AuditRecord.Create(command.UserCreated, _someApplication.GetRequestHost(), NAMEAPP) is not AuditRecord auditRecord)
                return Error.Validation("Auditoria", "Campos de Auditoria no tiene el formato correcto.");

            PaymentOrderDetail paymentOrderDetail = new PaymentOrderDetail(
                command.PaymentOrder.Id,
                massivePaymentDetailResponse.CuentaBeneficiario,
                massivePaymentDetailResponse.NombreBeneficiario,
                massivePaymentDetailResponse.Monto,
                "",
                _catalogRepository.GetIdByCode(CatalogType.PAYMENT_ORDER_DETAIL_STATUS, PaymentOrderDetailStatus.PENDING).Result!.Id,
                massivePaymentDetailResponse.CodigoUnico,
                auditRecord
                );
            command.PaymentOrder.Detalle.Add(paymentOrderDetail);
        }

        _paymentOrderDetailRepository.Add(command.PaymentOrder.Detalle);

        await _unitOfWork.SaveChangesAsync(cancellationToken);


        foreach (var detail in command.PaymentOrder.Detalle)
        {
            var commandAudit = new CreatePaymentAuditCommand(
            command.PaymentOrder.Id,
            detail.Id,
            "INSERTAR ORDEN PAGO DETALLE",
            $"Se inserto el detalle de la orden de pago {command.PaymentOrder.Id}",
            command.UserCreated,
            _someApplication.GetRequestHost(),
            NAMEAPP
            );

            var createPaymentAuditResult = await _mediator.Send(commandAudit);

            if (createPaymentAuditResult.IsError)
                return Error.Failure("Auditoria", "Error en registrar la auditoria para al crear una orden pago detalle.");
        }


        return command.PaymentOrder;
    }
}

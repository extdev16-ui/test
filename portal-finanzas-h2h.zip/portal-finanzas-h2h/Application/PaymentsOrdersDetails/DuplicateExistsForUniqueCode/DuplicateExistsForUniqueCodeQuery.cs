﻿using ErrorOr;
using MediatR;
namespace Application.PaymentsOrdersDetails.DuplicateExistsForUniqueCode;

public record DuplicateExistsForUniqueCodeQuery(List<string> UniquesCodes) : IRequest<ErrorOr<bool>>;
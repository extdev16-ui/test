using AutoMapper;
using Domain.PaymentsAudits;
using PaymentsAudits.Common;
using ErrorOr;
using MediatR;
using Domain.PaymentsOrdersDetails.Interfaces;

namespace Application.PaymentsOrdersDetails.DuplicateExistsForUniqueCode;

internal sealed class DuplicateExistsForUniqueCodeQueryHandler : IRequestHandler<DuplicateExistsForUniqueCodeQuery, ErrorOr<bool>>
{
    private readonly IPaymentOrderDetailReadRepository _paymentOrderDetailDapperRepository;
    private readonly IMapper _mapper;


    public DuplicateExistsForUniqueCodeQueryHandler(IPaymentOrderDetailReadRepository paymentOrderDetailDapperRepository, IMapper mapper)
    {
        _paymentOrderDetailDapperRepository = paymentOrderDetailDapperRepository;
        _mapper = mapper;
    }

    public async Task<ErrorOr<bool>> Handle(DuplicateExistsForUniqueCodeQuery query, CancellationToken cancellationToken) => await _paymentOrderDetailDapperRepository.ExistsDuplicate(query.UniquesCodes);

}

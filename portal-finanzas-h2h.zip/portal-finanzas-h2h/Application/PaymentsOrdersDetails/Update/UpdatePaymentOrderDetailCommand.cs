using ErrorOr;
using MediatR;
using Domain.Common;
using Domain.PaymentsFiles.Models;

namespace Application.PaymentsOrdersDetails.Update;

public record UpdatePaymentOrderDetailCommand(
     List<PaymentFileSetResponse> PaymentFileResponses,
    PaymentOrderDetailStatus PaymentOrderDetailStatus,
    string UserAction
) : IRequest<ErrorOr<Unit>>;

public record PaymentOrderDetailStatus(string Code, int Status, string Name) {
    public int StatusOld => Code switch
    {
        Constants.PaymentOrderDetailStatus.PAID => 3,
        Constants.PaymentOrderDetailStatus.ERROR => 4,
        _ => 1
    };
};

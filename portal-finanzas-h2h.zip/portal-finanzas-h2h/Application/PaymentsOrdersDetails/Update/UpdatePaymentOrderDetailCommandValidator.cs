using FluentValidation;

namespace Application.PaymentsOrdersDetails.Update;

public class UpdatePaymentOrderDetailCommandValidator : AbstractValidator<UpdatePaymentOrderDetailCommand>
{
    public UpdatePaymentOrderDetailCommandValidator()
    {
        RuleFor(r => r.PaymentOrderDetailStatus).NotNull()
             .WithName("Orden Pago Detalle");
    }
}
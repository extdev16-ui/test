using Application.Data;
using Application.PaymentsAudits.MassiveCreate;
using Application.Services;
using Domain.Common;
using Domain.PaymentsOrdersDetails;
using Domain.PaymentsOrdersDetails.Interfaces;
using Domain.Primitives;
using Domain.ValueObjects;
using ErrorOr;
using MediatR;

namespace Application.PaymentsOrdersDetails.Update;

internal sealed class UpdatePaymentOrderDetailCommandHandler : IRequestHandler<UpdatePaymentOrderDetailCommand, ErrorOr<Unit>>
{
	private readonly IPaymentOrderDetailWriteRepository _paymentOrderDetailEFRepository;
	private readonly IPaymentOrderDetailReadRepository _paymentOrderDetailDapperRepository;
	private readonly IMassivePaymentReadRepository _massivePaymentRepository;
	private readonly IUnitOfWork _unitOfWork;
	private readonly SomeApplication _someApplication;
	private readonly ISender _mediator;

	public UpdatePaymentOrderDetailCommandHandler(
		IPaymentOrderDetailWriteRepository paymentOrderDetailEFRepository,
		IPaymentOrderDetailReadRepository paymentOrderDetailDapperRepository,
		IMassivePaymentReadRepository massivePaymentRepository,
		IUnitOfWork unitOfWork,
		SomeApplication someApplication,
		ISender mediator)
	{
		_paymentOrderDetailEFRepository = paymentOrderDetailEFRepository ?? throw new ArgumentNullException(nameof(paymentOrderDetailEFRepository));
		_paymentOrderDetailDapperRepository = paymentOrderDetailDapperRepository ?? throw new ArgumentNullException(nameof(paymentOrderDetailDapperRepository));
		_massivePaymentRepository = massivePaymentRepository ?? throw new ArgumentNullException(nameof(massivePaymentRepository));
		_unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
		_someApplication = someApplication;
		_mediator = mediator;
	}

	public async Task<ErrorOr<Unit>> Handle(UpdatePaymentOrderDetailCommand command, CancellationToken cancellationToken)
	{
		//Update PaymentOrder
		List<PaymentAuditItem> createPaymentAuditCommands = [];

		foreach (var paymentFileResponse in command.PaymentFileResponses)
		{
			var paymentOrderDetail = new PaymentOrderDetail(
				paymentFileResponse.IdPaymentOrderDetail,
				command.PaymentOrderDetailStatus.Status,
				paymentFileResponse.TimePayment,
				paymentFileResponse.CodeAnswer,
				paymentFileResponse.DescriptionAnswer
				);

			var auditRecordUpdate = paymentFileResponse.AuditRecord;

			auditRecordUpdate!.UsuarioActualizador = command.UserAction;
			auditRecordUpdate.HostActualizador = _someApplication.GetRequestHost();
			auditRecordUpdate.AppActualizador = Constants.NAMEAPP;
			auditRecordUpdate.FechaActualizacion = DateTime.Now;

			_paymentOrderDetailEFRepository.Update(paymentOrderDetail, auditRecordUpdate);

			if (AuditRecord.Create(command.UserAction, _someApplication.GetRequestHost(), Constants.NAMEAPP) is not AuditRecord auditRecord)
				return Error.Validation("Auditoria", "Campos de Auditoria no tiene el formato correcto.");

			PaymentAuditItem commandAudit = new PaymentAuditItem(
				paymentOrderDetail.IdOrdenPago,
				paymentFileResponse.IdPaymentOrderDetail,
				$"ORDEN PAGO DETALLE {command.PaymentOrderDetailStatus.Name}",
				(!string.IsNullOrEmpty(paymentFileResponse.DescriptionError) ? paymentFileResponse.DescriptionError : $"Se actualizó el estado de la orden pago detalle {paymentFileResponse.IdPaymentOrderDetail}"),
				auditRecord.UsuarioCreador,
				auditRecord.HostCreador,
				auditRecord.AppCreador
				);

			createPaymentAuditCommands.Add(commandAudit);
		}

		await _unitOfWork.SaveChangesAsync(cancellationToken);

		var createPaymentAuditResult = await _mediator.Send(new MassiveCreatePaymentAuditCommand(createPaymentAuditCommands), cancellationToken);

		if (createPaymentAuditResult.IsError)
			return Error.Failure("Auditoria", "Error en registrar la auditoria para al actualizar una orden pago.");

		return Unit.Value;
	}
}

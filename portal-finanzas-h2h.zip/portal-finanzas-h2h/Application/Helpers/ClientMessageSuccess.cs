namespace Application.Helpers;

public record ClientMessageSuccess<T>(List<T> Data)
{
	public ClientMessageSuccess() : this(new List<T>()) { }
}


public record ResponsePaymentFile(string FileName, string Type, string Status = "ERROR", string? Observation = "");



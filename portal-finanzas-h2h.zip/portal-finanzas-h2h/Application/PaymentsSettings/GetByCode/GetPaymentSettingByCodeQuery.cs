﻿using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;
namespace Application.PaymentsSettings.GetByCode;

public record GetPaymentSettingByCodeQuery(string Code) : IRequest<ErrorOr<PaymentSetting?>>;
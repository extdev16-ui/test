using AutoMapper;
using ErrorOr;
using MediatR;
using Domain.PaymentsSettings;
using Domain.PaymentsSettings.Interfaces;

namespace Application.PaymentsSettings.GetByCode;

internal sealed class GetPaymentSettingByCodeQueryHandler : IRequestHandler<GetPaymentSettingByCodeQuery, ErrorOr<PaymentSetting?>>
{
    private readonly IPaymentSettingRepository _paymentSettingRepository;
    private readonly IMapper _mapper;

    public GetPaymentSettingByCodeQueryHandler(IPaymentSettingRepository paymentSettingRepository, IMapper mapper)
    {
        _paymentSettingRepository = paymentSettingRepository;
        _mapper = mapper;
    }
    public async Task<ErrorOr<PaymentSetting?>> Handle(GetPaymentSettingByCodeQuery query, CancellationToken cancellationToken)
    {
        PaymentSetting? paymentSetting = await _paymentSettingRepository.GetPaymentSettingByCode(query.Code);

        if (paymentSetting  is null)
            return Error.Forbidden("Configuraci�n Pago", "No se encontr� la configuraci�n de pago.");

        paymentSetting.DeserializeDetails();

        return paymentSetting!;
    }
}

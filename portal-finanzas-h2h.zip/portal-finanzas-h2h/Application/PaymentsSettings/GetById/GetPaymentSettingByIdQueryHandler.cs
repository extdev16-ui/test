using AutoMapper;
using Domain.PaymentsAudits;
using PaymentsAudits.Common;
using ErrorOr;
using MediatR;
using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using Domain.PaymentsSettings.Interfaces;

namespace Application.PaymentsSettings.GetById;

internal sealed class GetPaymentSettingByIdQueryHandler : IRequestHandler<GetPaymentSettingByIdQuery, ErrorOr<PaymentSetting?>>
{
    private readonly IPaymentSettingRepository _paymentSettingRepository;
    private readonly IMapper _mapper;


    public GetPaymentSettingByIdQueryHandler(IPaymentSettingRepository paymentSettingRepository, IMapper mapper)
    {
        _paymentSettingRepository = paymentSettingRepository;
        _mapper = mapper;
    }

    public async Task<ErrorOr<PaymentSetting?>> Handle(GetPaymentSettingByIdQuery query, CancellationToken cancellationToken)
    {
        PaymentSetting? paymentSetting = await _paymentSettingRepository.GetPaymentSettingById(query.Id);

        if (paymentSetting  is null)
            return Error.Forbidden("Configuraci�n Pago", "No se encontr� la configuraci�n de pago.");

        paymentSetting.DeserializeDetails();

        return paymentSetting!;
    }
}

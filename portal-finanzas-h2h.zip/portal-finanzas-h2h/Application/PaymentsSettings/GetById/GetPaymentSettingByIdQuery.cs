﻿using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;
namespace Application.PaymentsSettings.GetById;

public record GetPaymentSettingByIdQuery(int Id) : IRequest<ErrorOr<PaymentSetting?>>;
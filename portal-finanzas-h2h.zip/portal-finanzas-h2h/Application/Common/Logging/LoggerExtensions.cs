﻿using ErrorOr;
using Microsoft.Extensions.Logging;

namespace Application.Common.Logging;

public static class LoggerExtensions
{
	public static void LogException(this ILogger logger, Exception ex)
	{
		logger.LogError("Excepción en Tipo: {Tipo} | Mensaje: {Mensaje} | Inner: {Inner}",
			ex.GetType().Name,
			ex.Message,
			ex.InnerException?.Message ?? "No inner exception");
	}

	public static void LogWarning(this ILogger logger, Exception ex)
	{
		logger.LogWarning("Warning en Tipo: {Tipo} | Mensaje: {Mensaje} | Inner: {Inner}",
			ex.GetType().Name,
			ex.Message,
			ex.InnerException?.Message ?? "No inner exception");
	}
}
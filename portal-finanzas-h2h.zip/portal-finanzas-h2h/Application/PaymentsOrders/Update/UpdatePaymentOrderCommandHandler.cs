using Application.Data;
using Application.PaymentsAudits.Create;
using Application.Services;
using Domain.Common;
using Domain.PaymentsOrders;
using Domain.PaymentsOrders.Interfaces;
using Domain.Primitives;
using Domain.ValueObjects;
using ErrorOr;
using MediatR;

namespace Application.PaymentsOrders.Update;

internal sealed class UpdatePaymentOrderCommandHandler : IRequestHandler<UpdatePaymentOrderCommand, ErrorOr<Unit>>
{
    private readonly IPaymentOrderRepository _paymentOrderRepository;
    private readonly IMassivePaymentReadRepository _massivePaymentRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly SomeApplication _someApplication;
    private readonly ISender _mediator;

    public UpdatePaymentOrderCommandHandler(
        IPaymentOrderRepository paymentOrderRepository,
        IMassivePaymentReadRepository massivePaymentRepository,
        IUnitOfWork unitOfWork,
        SomeApplication someApplication,
        ISender mediator)
    {
        _paymentOrderRepository = paymentOrderRepository ?? throw new ArgumentNullException(nameof(paymentOrderRepository));
        _massivePaymentRepository = massivePaymentRepository ?? throw new ArgumentNullException(nameof(massivePaymentRepository));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        _someApplication = someApplication;
        _mediator = mediator;
    }

    public async Task<ErrorOr<Unit>> Handle(UpdatePaymentOrderCommand command, CancellationToken cancellationToken)
    {
        //Update PaymentOrder
        var auditRecord = await _paymentOrderRepository.GetAuditRecordById(command.IdPaymentOrder) ?? new AuditRecord();

        auditRecord!.UsuarioActualizador = command.UserAction;
        auditRecord.HostActualizador = _someApplication.GetRequestHost();
        auditRecord.AppActualizador = Constants.NAMEAPP;
        auditRecord.FechaActualizacion = DateTime.Now;

        var paymentOrder = new PaymentOrder(command.IdPaymentOrder, command.PaymentOrderStatus.Code, command.PaymentOrderStatus.Status, command.FechaEnvio, command.FechaRespuesta);

        _paymentOrderRepository.Update(paymentOrder, auditRecord);

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        var commandAudit = new CreatePaymentAuditCommand(
            command.IdPaymentOrder,
            0,
            $"ORDEN PAGO {command.PaymentOrderStatus.Name}",
            $"Se actualizó el estado de la orden pago {command.IdPaymentOrder}",
            auditRecord.UsuarioActualizador,
            _someApplication.GetRequestHost(),
            Constants.NAMEAPP
            );

        var createPaymentAuditResult = await _mediator.Send(commandAudit);

        if (createPaymentAuditResult.IsError)
            return Error.Failure("Auditoria", "Error en registrar la auditoria para al actualizar una orden pago.");

        return Unit.Value;
    }
}

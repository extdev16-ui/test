using Domain.Common;
using ErrorOr;
using MediatR;

namespace Application.PaymentsOrders.Update;

public class UpdatePaymentOrderCommand : IRequest<ErrorOr<Unit>>
{
    public int IdPaymentOrder;
    public int IdMassivePayment;
    public PaymentOrderStatus  PaymentOrderStatus;
    public string UserAction;

    public UpdatePaymentOrderCommand(int idPaymentOrder, int idMassivePayment, PaymentOrderStatus paymentOrderStatus, string userAction) 
    {
        IdPaymentOrder = idPaymentOrder;
        IdMassivePayment = idMassivePayment;
        PaymentOrderStatus = paymentOrderStatus;
        UserAction = userAction;
    }
    public string FechaEnvio => PaymentOrderStatus.Code switch
    {
        Constants.PaymentOrderStatus.CONFIRMED => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
        _ => ""
    };
    public string FechaRespuesta => PaymentOrderStatus.Code switch
    {

        Constants.PaymentOrderStatus.FULLYPAID => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
        Constants.PaymentOrderStatus.PARTIALLYPAID => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
        Constants.PaymentOrderStatus.ERROR => DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
        _ => ""
    };
}

public record PaymentOrderStatus(string Code, int Status, string Name)
{
    public int StatusOld => Code switch
    {
        Constants.PaymentOrderStatus.CONFIRMED => 8,
        Constants.PaymentOrderStatus.FULLYPAID => 9,
        Constants.PaymentOrderStatus.PARTIALLYPAID => 10,
        Constants.PaymentOrderStatus.ERROR => 11,
        _ => 1
    };
};

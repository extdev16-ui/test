using FluentValidation;

namespace Application.PaymentsOrders.Update;

public class UpdatePaymentOrderCommandValidator : AbstractValidator<UpdatePaymentOrderCommand>
{
    public UpdatePaymentOrderCommandValidator()
    {
        RuleFor(r => r.IdPaymentOrder).NotNull()
             .WithName("Id Orden Pago");
        RuleFor(r => r.PaymentOrderStatus).NotNull()
             .WithName("Estado Orden Pago");
        RuleFor(r => r.UserAction).NotNull().NotEmpty()
             .WithName("Usuario Acci�n");
    }
}
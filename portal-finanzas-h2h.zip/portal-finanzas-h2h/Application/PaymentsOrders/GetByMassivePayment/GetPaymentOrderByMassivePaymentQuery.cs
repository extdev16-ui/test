﻿using Domain.PaymentsOrders;
using ErrorOr;
using MediatR;
namespace Application.PaymentsOrders.GetByMassivePayment;

public record GetPaymentOrderByMassivePaymentQuery(int IdMassivePayment) : IRequest<ErrorOr<PaymentOrder?>>;
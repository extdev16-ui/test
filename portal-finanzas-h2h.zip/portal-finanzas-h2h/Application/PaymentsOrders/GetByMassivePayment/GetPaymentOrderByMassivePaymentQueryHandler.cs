using AutoMapper;
using Domain.PaymentsAudits;
using PaymentsAudits.Common;
using ErrorOr;
using MediatR;
using Domain.PaymentsOrders;
using Domain.PaymentsOrders.Interfaces;

namespace Application.PaymentsOrders.GetByMassivePayment;

internal sealed class GetPaymentOrderByMassivePaymentQueryHandler : IRequestHandler<GetPaymentOrderByMassivePaymentQuery, ErrorOr<PaymentOrder?>>
{
    private readonly IPaymentOrderRepository _paymentOrderRepository;
    private readonly IMapper _mapper;


    public GetPaymentOrderByMassivePaymentQueryHandler(IPaymentOrderRepository paymentOrderRepository, IMapper mapper)
    {
        _paymentOrderRepository = paymentOrderRepository;
        _mapper = mapper;
    }

    public async Task<ErrorOr<PaymentOrder?>> Handle(GetPaymentOrderByMassivePaymentQuery query, CancellationToken cancellationToken)
    {
        PaymentOrder? paymentOrder = await _paymentOrderRepository.GetByMassivePayment(query.IdMassivePayment);

        if (paymentOrder == null)
            return Error.Validation("Orden Pago", "No se encontr� la orden de pago.");
        
        return paymentOrder!;
    }
}

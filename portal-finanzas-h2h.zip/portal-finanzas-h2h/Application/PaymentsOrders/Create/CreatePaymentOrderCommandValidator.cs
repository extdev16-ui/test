using FluentValidation;

namespace Application.PaymentsOrders.Create;

public class CreatePaymentOrderCommandValidator : AbstractValidator<CreatePaymentOrderCommand>
{
    public CreatePaymentOrderCommandValidator()
    {

        RuleFor(r => r.MassivePaymentResponse).NotNull()
             .WithName("Orden Pago Masivo");
        RuleFor(r => r.PaymentSetting).NotNull()
             .WithName("Configuración Pago");
        RuleFor(r => r.UserCreated).NotEmpty().NotNull()
             .WithName("Usuario Creador");
    }
}
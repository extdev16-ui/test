using Application.Services;
using Domain.Primitives;
using Domain.ValueObjects;
using ErrorOr;
using MediatR;
using Domain.Common;
using Domain.PaymentsOrders;
using Domain.Catalogs;
using Application.PaymentsAudits.Create;
using Domain.PaymentsOrders.Interfaces;

namespace Application.PaymentsOrders.Create;

internal sealed class CreatePaymentOrderCommandHandler : IRequestHandler<CreatePaymentOrderCommand, ErrorOr<PaymentOrder>>
{
    private readonly IPaymentOrderRepository _paymentOrderRepository;
    private readonly ICatalogRepository _catalogRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ISender _mediator;
    private readonly SomeApplication _someApplication;

    public CreatePaymentOrderCommandHandler(
        IPaymentOrderRepository paymentOrderRepository,
        ICatalogRepository catalogRepository,
        IUnitOfWork unitOfWork,
        ISender mediator,
        SomeApplication someApplication)
    {
        _paymentOrderRepository = paymentOrderRepository ?? throw new ArgumentNullException(nameof(paymentOrderRepository));
        _catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
        _someApplication = someApplication;
    }

    public async Task<ErrorOr<PaymentOrder>> Handle(CreatePaymentOrderCommand command, CancellationToken cancellationToken)
    {
        if (AuditRecord.Create(command.UserCreated, _someApplication.GetRequestHost(), Constants.NAMEAPP) is not AuditRecord auditRecord)
            return Error.Validation("Auditoria", "Campos de Auditoria no tiene el formato correcto.");

        var paymentOrder = new PaymentOrder(
            command.MassivePaymentResponse.IdPagoMasivo,
            _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_ORDER_STATUS, Constants.PaymentOrderStatus.PENDING).Result!.Id,
            command.MassivePaymentResponse.ImporteTotal,
            _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_ORDER_MONEY, command.MassivePaymentResponse.CodigoMoneda).Result!.Id,
            "",
            command.PaymentSetting.Id,
            command.MassivePaymentResponse.FechaPago,
            "",
            "",
            auditRecord
            );

        _paymentOrderRepository.Add(paymentOrder);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        var commandAudit = new CreatePaymentAuditCommand(
            paymentOrder.Id, 
            0,
            "INSERTAR ORDEN PAGO",
            $"Se inserto la orden de pago {paymentOrder.Id}",
            command.UserCreated,
            _someApplication.GetRequestHost(),
            Constants.NAMEAPP
            );

        var createPaymentAuditResult = await _mediator.Send(commandAudit);

        if (createPaymentAuditResult.IsError)
            return Error.Failure("Auditoria", "Error en registrar la auditoria para al crear una orden pago.");
        
        return paymentOrder;
    }
}

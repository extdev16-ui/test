using Domain.MassivesPayments.Common;
using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;

namespace Application.PaymentsOrders.Create;

public record CreatePaymentOrderCommand(
    MassivePaymentResponse MassivePaymentResponse, 
    PaymentSetting PaymentSetting,
    string UserCreated
) : IRequest<ErrorOr<PaymentOrder>>;


using ApiKeys.Common;
using AutoMapper;
using Domain.ApiKeys;
using Domain.PaymentsAudits;
using PaymentsAudits.Common;

namespace Application.Mappings;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<PaymentAudit, PaymentAuditResponse>();
        CreateMap<ApiKey, ApiKeyResponse>();
    }
}

﻿using Application.Dependencies.Models;
using ErrorOr;
namespace Application.Dependencies;

public interface IVaultService
{
    Task<ErrorOr<DbSecret>> GetDatabaseCredentialsAsync(VaultRequest request);
}

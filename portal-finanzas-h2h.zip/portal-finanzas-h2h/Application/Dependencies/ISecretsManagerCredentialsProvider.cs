﻿using Application.Dependencies.Models;

namespace Application.Dependencies;

public interface ISecretsManagerCredentialsProvider
{
    Task<string> GetSecretAsync(string secretName);
	public string GetApiKeyByApp(string app = "001");
	PGPkey? GetPgpKeyByPaymentSetting(string paymentSettingCode);

    Task<DbSecret> GetDbSecretAsync();
}
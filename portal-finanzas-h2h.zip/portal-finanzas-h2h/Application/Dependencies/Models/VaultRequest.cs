﻿namespace Application.Dependencies.Models
{
    public class VaultRequest
    {
        public string Url { get; set; } = string.Empty;
        public string Token { get; set; } = string.Empty;
    }
}

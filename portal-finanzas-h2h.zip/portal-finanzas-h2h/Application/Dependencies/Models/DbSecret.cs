﻿using static Domain.Common.Constants;

namespace Application.Dependencies.Models;


public class DbSecret
{
    public List<ApiKey> ApiKeys { get; set; } = [];
    public DBCredentials DBCredentials { get; set; } = new();
    public List<PGPkey> PGPkeys { get; set; } = [];
    public List<SFTPCredentials> SFTPCredentials { get; set; } = [];
}


public class ApiKey
{
    public string App { get; set; } = string.Empty;
    public string Key { get; set; } = string.Empty;
}
public class DBCredentials
{
    public string Database { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Port { get; set; } = string.Empty;
    public string Server { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string GetConnectionString() => $"Server={Server},{Port};Database={Database};User Id={UserId};Password={Password};Encrypt=False;TrustServerCertificate=False;";
}
public class PGPkey
{
    public string PaymentSettingCode { get; set; } = string.Empty;
    public string Key { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
	public string Password { get; set; } = string.Empty;
	public string Source { get; set; } = string.Empty;
	public string ExecGPG { get; set; } = string.Empty;
}

public class SFTPCredentials
{
    public string PaymentSettingCode { get; set; } = string.Empty;
    public SFTPSettings SFTPSettings { get; set; } = new SFTPSettings();
    public SFTPSettings SFTPSettingsHistorical { get; set; } = new SFTPSettings();

}

public class SFTPSettings
{
    public string Host { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public int Port { get; set; }
    public string User { get; set; } = string.Empty;
    public string Key { get; set; } = string.Empty;
    public int Type { get; set; } = SftpConnectionType.Password;
}
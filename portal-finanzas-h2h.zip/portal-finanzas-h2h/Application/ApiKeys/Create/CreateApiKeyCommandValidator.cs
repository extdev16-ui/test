using FluentValidation;

namespace Application.ApiKeys.Create;

public class CreateApiKeyCommandValidator : AbstractValidator<CreateApiKeyCommand>
{
    public CreateApiKeyCommandValidator()
    {
        RuleFor(r => r.AplicacionId).NotEqual(0)
        .WithName("Aplicación");
    }
}
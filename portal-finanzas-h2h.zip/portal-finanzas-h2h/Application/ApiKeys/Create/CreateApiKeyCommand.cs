using ErrorOr;
using MediatR;

namespace Application.ApiKeys.Create;

public record CreateApiKeyCommand(
    int AplicacionId,
    string UsuarioCreador,
    string HostCreador,
    string AppCreador
) : IRequest<ErrorOr<Unit>>;
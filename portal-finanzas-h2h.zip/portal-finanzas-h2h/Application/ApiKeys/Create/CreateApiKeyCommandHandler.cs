using Domain.ApiKeys;
using Domain.Primitives;
using Domain.ValueObjects;
using ErrorOr;
using MediatR;

namespace Application.ApiKeys.Create;

internal sealed class CreateApiKeyCommandHandler : IRequestHandler<CreateApiKeyCommand, ErrorOr<Unit>>
{
    private readonly IApiKeyRepository _apiKeyRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreateApiKeyCommandHandler(IApiKeyRepository apiKeyRepository, IUnitOfWork unitOfWork)
    {
        _apiKeyRepository = apiKeyRepository ?? throw new ArgumentNullException(nameof(apiKeyRepository));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
    }

    public async Task<ErrorOr<Unit>> Handle(CreateApiKeyCommand command, CancellationToken cancellationToken)
    {
        if (AuditRecord.Create(command.UsuarioCreador, command.HostCreador, command.AppCreador) is not AuditRecord auditRecord)
        {          
          return Error.Validation("PaymentAudit.AuditRecord", "Campos de Auditoria no tiene el formato correcto.");
        }
        
        var apiKey = new ApiKey(
            ApiKey.GenerateKey(),
            command.AplicacionId,
            DateTime.Now.AddMonths(3),
            auditRecord
        );

        _apiKeyRepository.Add(apiKey);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

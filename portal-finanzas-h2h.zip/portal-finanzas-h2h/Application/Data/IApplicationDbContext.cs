using Domain.ApiKeys;
using Domain.Catalogs;
using Domain.PaymentsAudits;
using Domain.PaymentsCalendar;
using Domain.PaymentsFiles.Models;
using Domain.PaymentsOrders;
using Domain.PaymentsOrdersDetails;
using Domain.PaymentsSettings;
using Microsoft.EntityFrameworkCore;

namespace Application.Data;

public interface IApplicationDbContext
{
    DbSet<PaymentAudit> paymentAudit { get; set; }
    DbSet<ApiKey> apiKey { get; set; }
    DbSet<PaymentFile> paymentFile { get; set; }
    DbSet<PaymentOrder> paymentOrder { get; set; }
    DbSet<PaymentOrderDetail> paymentOrderDetail { get; set; }
    DbSet<PaymentSetting> paymentSetting { get; set; }
    DbSet<Catalog> catalog { get; set; }
	DbSet<PaymentCalendar> paymentCalendar { get; set; }

	Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
using Domain.MassivesPayments.Common;

namespace Application.Data;

public interface IMassivePaymentReadRepository{
    Task<IEnumerable<MassivePaymentResponse>> GetById(int id);
    Task<List<MassivePaymentDetailResponse>> GetDetailByIdMassivePayment(int id);
    void UpdateStatusMassivePayment(int idMassivePayment, int status, int userModifier);
    void UpdateStatusMassivePaymentDetail(string uniqueCode, int idMassivePayment, int status, int userModifier);
}
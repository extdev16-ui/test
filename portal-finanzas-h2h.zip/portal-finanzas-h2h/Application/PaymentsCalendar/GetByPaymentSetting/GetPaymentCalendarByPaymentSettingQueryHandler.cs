using Domain.PaymentsCalendar;
using Domain.PaymentsCalendar.Interfaces;
using ErrorOr;
using MediatR;
using Serilog.Context;

namespace Application.PaymentsCalendar.GetByPaymentSetting;

internal sealed class GetPaymentCalendarByPaymentSettingQueryHandler : IRequestHandler<GetPaymentCalendarByPaymentSettingQuery, ErrorOr<List<PaymentCalendar>?>>
{
    private readonly IPaymentCalendarRepository _paymentCalendarRepository;


    public GetPaymentCalendarByPaymentSettingQueryHandler(IPaymentCalendarRepository paymentCalendarRepository)
    {
		_paymentCalendarRepository = paymentCalendarRepository;
    }

    public async Task<ErrorOr<List<PaymentCalendar>?>> Handle(GetPaymentCalendarByPaymentSettingQuery query, CancellationToken cancellationToken)
    {
        using (LogContext.PushProperty("Identifier", string.Concat("Configuracion de pago: " + query.Code)))
        {
            List<PaymentCalendar>? paymentCalendars = await _paymentCalendarRepository.GetByPaymentSetting(query.Code); 

            return paymentCalendars;
        }
    }
}
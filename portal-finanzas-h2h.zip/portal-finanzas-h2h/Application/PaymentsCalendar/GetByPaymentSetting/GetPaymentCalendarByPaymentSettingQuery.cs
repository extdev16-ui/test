﻿using Domain.PaymentsCalendar;
using ErrorOr;
using MediatR;
namespace Application.PaymentsCalendar.GetByPaymentSetting;

public record GetPaymentCalendarByPaymentSettingQuery(string Code) : IRequest<ErrorOr<List<PaymentCalendar>?>>;
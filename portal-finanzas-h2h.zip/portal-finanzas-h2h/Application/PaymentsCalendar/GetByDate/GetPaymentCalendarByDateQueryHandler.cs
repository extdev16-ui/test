using Domain.PaymentsCalendar;
using Domain.PaymentsCalendar.Interfaces;
using ErrorOr;
using MediatR;
using Serilog.Context;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Application.PaymentsCalendar.GetByDate;

internal sealed class GetPaymentCalendarByDateQueryHandler : IRequestHandler<GetPaymentCalendarByDateQuery, ErrorOr<PaymentCalendar?>>
{
    private readonly IPaymentCalendarRepository _paymentCalendarRepository;


    public GetPaymentCalendarByDateQueryHandler(IPaymentCalendarRepository paymentCalendarRepository)
    {
		_paymentCalendarRepository = paymentCalendarRepository;
    }

    public async Task<ErrorOr<PaymentCalendar?>> Handle(GetPaymentCalendarByDateQuery query, CancellationToken cancellationToken)
	{
        using (LogContext.PushProperty("Identifier", string.Concat("Configuracion de pago: " + query.Code)))
        {
            PaymentCalendar? paymentCalendar;

            if (DateTime.TryParse(query.Date, out var date))
            {
                paymentCalendar = await _paymentCalendarRepository.GetByDate(query.Code, date, query.Type);
            }
            else
            {
                return Error.Failure("Calendario Pago", $"Error en convertir la fecha  {query.Date} para la configuracion de pago {query.Code}.");
            }

            return paymentCalendar;
        }
    }
}
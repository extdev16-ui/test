﻿using Domain.PaymentsCalendar;
using ErrorOr;
using MediatR;
namespace Application.PaymentsCalendar.GetByDate;

public record GetPaymentCalendarByDateQuery(string Code, string Date, string Type) : IRequest<ErrorOr<PaymentCalendar?>>;
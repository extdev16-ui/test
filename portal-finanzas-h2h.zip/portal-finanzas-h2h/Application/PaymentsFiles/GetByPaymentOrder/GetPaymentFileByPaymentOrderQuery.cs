﻿using Domain.PaymentsFiles.Models;
using ErrorOr;
using MediatR;
namespace Application.PaymentsFiles.GetByPaymentOrder;

public record GetPaymentFileByPaymentOrderQuery(int IdPaymentOrder, string Type) : IRequest<ErrorOr<List<PaymentFile>?>>;
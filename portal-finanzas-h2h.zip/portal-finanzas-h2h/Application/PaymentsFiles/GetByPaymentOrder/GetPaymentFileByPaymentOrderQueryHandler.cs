using Domain.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Models;
using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.GetByPaymentOrder;

internal sealed class GetPaymentFileByPaymentOrderQueryHandler : IRequestHandler<GetPaymentFileByPaymentOrderQuery, ErrorOr<List<PaymentFile>?>>
{
    private readonly IPaymentFileWriteRepository _paymentFileRepository;


    public GetPaymentFileByPaymentOrderQueryHandler(IPaymentFileWriteRepository paymentFileRepository)
    {
        _paymentFileRepository = paymentFileRepository;
    }

    public async Task<ErrorOr<List<PaymentFile>?>> Handle(GetPaymentFileByPaymentOrderQuery query, CancellationToken cancellationToken)
    {
        List<PaymentFile>? paymentFiles = await _paymentFileRepository.GetByPaymentOrder(query.IdPaymentOrder, query.Type);

        if (paymentFiles is null || paymentFiles.Count == 0)
            return Error.Validation("Archivo Pago", "No existe un archivo de pago relacionada por archivo pago.");

        return paymentFiles;
    }
}
﻿namespace Application.PaymentsFiles.ReleasePayment.Results
{
    public sealed class ReleasePaymentResult
    {
        public int IdPagoMasivo { get; init; }
        public int CantidadRetiros { get; init; }
        public IReadOnlyList<long> IdsRetiro { get; init; } = Array.Empty<long>();
    }
}

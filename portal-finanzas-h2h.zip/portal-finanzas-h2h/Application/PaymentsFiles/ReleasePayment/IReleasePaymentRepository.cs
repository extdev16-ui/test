﻿
using Application.PaymentsFiles.ReleasePayment.Requests;
using Application.PaymentsFiles.ReleasePayment.Results;

namespace Application.PaymentsFiles.ReleasePayment;

public interface IReleasePaymentRepository
{
    Task<ReleasePaymentResult> ReleasePaymentAsync(ReleasePaymentRequest request, CancellationToken cancellationToken = default);
    Task<int> ReleasePaymentOrderAsync(ReleasePaymentRequest request, CancellationToken cancellationToken = default);
}
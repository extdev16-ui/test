﻿using System.ComponentModel.DataAnnotations;

namespace Application.PaymentsFiles.ReleasePayment.Requests
{

    public sealed class ReleasePaymentRequest
    {
        [Required]
        public required int IdPagoMasivo { get; set; }
        [Required]
        public required int UserId { get; set; }
    }
}

using FluentValidation;

namespace Application.PaymentsFiles.CreateResponse;

public class CreatePaymentResponseFileCommandValidator : AbstractValidator<CreatePaymentResponseFileCommand>
{
    public CreatePaymentResponseFileCommandValidator()
    {

        RuleFor(r => r.PaymentSetting).NotNull()
             .WithName("Configuración Pago");
        RuleFor(r => r.IdPaymentOrder).NotNull()
             .WithName("Id Orden Pago");
        RuleFor(r => r.UserCreated).NotEmpty().NotNull()
             .WithName("Usuario Creador");
    }
}
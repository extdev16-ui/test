using Domain.PaymentsFiles.Models;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.CreateResponse;

public record CreatePaymentResponseFileCommand(
    PaymentSetting PaymentSetting, 
    int IdPaymentOrder,
    string FileName,
    string FileType,
	int FileOrder,
	string UserCreated
) : IRequest<ErrorOr<PaymentFile>>;


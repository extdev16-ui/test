using Application.Services;
using Domain.Primitives;
using Domain.ValueObjects;
using ErrorOr;
using MediatR;
using Domain.Catalogs;
using Application.Common;
using Application.PaymentsAudits.Create;
using Domain.PaymentsFiles.Interfaces;
using Domain.Common;
using Domain.PaymentsFiles.Models;

namespace Application.PaymentsFiles.CreateResponse;

internal sealed class CreatePaymentResponseFileCommandHandler : IRequestHandler<CreatePaymentResponseFileCommand, ErrorOr<PaymentFile>>
{
    private readonly IPaymentFileWriteRepository _paymentFileRepository;
    private readonly ICatalogRepository _catalogRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly SomeApplication _someApplication;
    private readonly ISender _mediator;

    public CreatePaymentResponseFileCommandHandler(
        IPaymentFileWriteRepository paymentFileRepository,
        ICatalogRepository catalogRepository,
        IUnitOfWork unitOfWork,
        SomeApplication someApplication,
        ISender mediator)
    {
        _paymentFileRepository = paymentFileRepository ?? throw new ArgumentNullException(nameof(paymentFileRepository));
        _catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        _someApplication = someApplication;
        _mediator = mediator;
    }

    public async Task<ErrorOr<PaymentFile>> Handle(CreatePaymentResponseFileCommand command, CancellationToken cancellationToken)
    {
        //Insert PaymentFile Response
        string rutaFTPHistoricoRespuesta = command.PaymentSetting.DetalleConfiguraciones!.Find(c => c.Nombre == "rutaFTPRespuesta")?.Valor!;
        
        if (AuditRecord.Create(command.UserCreated, _someApplication.GetRequestHost(), Constants.NAMEAPP) is not AuditRecord auditRecord)
            return Error.Validation("Auditoria", "Campos de Auditoria no tiene el formato correcto.");

        var paymentFile = new PaymentFile(
            command.FileName,
            DateTime.Now,
            _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_FILE_STATUS, Constants.PaymentFileStatus.RECEIVED).Result!.Id,
            _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_FILE_TYPE, command.FileType).Result!,
            $"{rutaFTPHistoricoRespuesta}{command.FileName}", 
            command.PaymentSetting.Id,
            command.IdPaymentOrder,
			command.FileOrder,
            auditRecord
        );

        _paymentFileRepository.Add(paymentFile);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        var commandAudit = new CreatePaymentAuditCommand(
            paymentFile.IdOrdenPago,
            0,
            "ARCHIVO PAGO RECIBIDO",
            $"Se creo nuevo archivo de pago respuesta de la orden de pago {paymentFile.IdOrdenPago}",
            auditRecord.UsuarioCreador,
            _someApplication.GetRequestHost(),
            Constants.NAMEAPP
            );

        var createPaymentAuditResult = await _mediator.Send(commandAudit, cancellationToken);

        if (createPaymentAuditResult.IsError)
            return Error.Failure("Auditoria", "Error en registrar la auditoria para al crear un archivo pago de respuesta.");

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return paymentFile;
    }
}
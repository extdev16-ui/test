using FluentValidation;

namespace Application.PaymentsFiles.DeleteFile;

public class DeleteFilePaymentFileCommandValidator : AbstractValidator<DeleteFilePaymentFileCommand>
{
    public DeleteFilePaymentFileCommandValidator()
    {
        RuleFor(r => r.RemoteFilePath).NotNull().NotEmpty()
             .WithName("Ruta de archivo");
    }
}
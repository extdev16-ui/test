using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.DeleteFile;

public record DeleteFilePaymentFileCommand(
    string RemoteFilePath,
    bool HistoricalFtps,
    string PaymentSettingCode
) : IRequest<ErrorOr<Unit>>;
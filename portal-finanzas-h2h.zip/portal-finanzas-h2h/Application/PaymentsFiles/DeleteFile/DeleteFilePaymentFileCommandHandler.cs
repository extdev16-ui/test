using Application.PaymentsFiles.Interfaces;
using Application.PaymentsFiles.Request;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Application.PaymentsFiles.DeleteFile;

internal sealed class DeleteFilePaymentFileCommandHandler : IRequestHandler<DeleteFilePaymentFileCommand, ErrorOr<Unit>>
{
    private readonly IPaymentFileSFTP _paymentFileService;

    public DeleteFilePaymentFileCommandHandler(
        IPaymentFileSFTP paymentFileService)
    {
        _paymentFileService = paymentFileService ?? throw new ArgumentNullException(nameof(paymentFileService));
    }


    public async Task<ErrorOr<Unit>> Handle(DeleteFilePaymentFileCommand command, CancellationToken cancellationToken)
    {
        //Send to Ftps
        bool sendFtpResult = await _paymentFileService.DeleteFileFromFtp(new FileToFtpsRequest(command.RemoteFilePath, command.HistoricalFtps, command.PaymentSettingCode));

        if (!sendFtpResult)
            return Error.Failure("Archivo Pago", "No se pudó eliminar el archivo.");

        return Unit.Value;
    }

}
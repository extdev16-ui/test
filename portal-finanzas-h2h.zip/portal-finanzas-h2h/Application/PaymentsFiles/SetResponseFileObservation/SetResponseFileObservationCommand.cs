using Application.Helpers;
using Domain.PaymentsFiles.Models;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.SetResponseFileObservation;

public record SetResponseFileObservationCommand(
    List<PaymentFileResponse> PaymentsFilesResponsesUnifieds, 
    PaymentSetting PaymentSetting, 
    string UserAction
) : IRequest<ErrorOr<ClientMessageSuccess<object>>>;
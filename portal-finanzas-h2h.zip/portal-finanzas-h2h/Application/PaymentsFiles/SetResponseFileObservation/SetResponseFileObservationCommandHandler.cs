using Application.Services.PaymentResponseFileProcessor;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Application.Helpers;
using Application.PaymentsOrders.Update;
using Application.Services.SetStatusPaymentFile;
using Domain.Catalogs;
using Application.PaymentsOrdersDetails.Update;
using Domain.Common;
using Application.PaymentsAudits.Create;
using Application.Services;
using Domain.PaymentsFiles.Models;
using Domain.ValueObjects;
using Domain.PaymentsOrdersDetails.Common;
using Domain.PaymentsOrdersDetails.Interfaces;
using Application.PaymentsFiles.GetResponse;
using NPOI.HPSF;
using NPOI.SS.Formula.Functions;
//using static Domain.Common.Constants;

namespace Application.PaymentsFiles.SetResponseFileObservation;

internal sealed class SetResponseFileObservationCommandHandler : IRequestHandler<SetResponseFileObservationCommand, ErrorOr<ClientMessageSuccess<object>>>
{
	private readonly ILogger<PaymentResponseFileProcessorCommandHandler> _logger;
    private readonly IPaymentOrderDetailReadRepository _paymentOrderDetailReadRepository;
    private readonly ICatalogRepository _catalogRepository;
	private readonly SomeApplication _someApplication;
	private readonly ISender _mediator;

	public SetResponseFileObservationCommandHandler(
		ILogger<PaymentResponseFileProcessorCommandHandler> logger,
		ICatalogRepository catalogRepository,
		SomeApplication someApplication,
        IPaymentOrderDetailReadRepository paymentOrderDetailReadRepository,
        ISender mediator)
	{
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
		_someApplication = someApplication;
        _paymentOrderDetailReadRepository = paymentOrderDetailReadRepository ?? throw new ArgumentNullException(nameof(paymentOrderDetailReadRepository));
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
	}

	public async Task<ErrorOr<ClientMessageSuccess<object>>> Handle(SetResponseFileObservationCommand command, CancellationToken cancellationToken)
	{
		ClientMessageSuccess<object> clientMessageSuccess = new();

        //Step 1: Get the shipping payment file in status received by BD
        List<PaymentOrderDetailDto> paymentOrderDetailRecevied = await _paymentOrderDetailReadRepository.GetByStatusPaymentResponseFile(Constants.PaymentFileStatus.RECEIVED);

        IEnumerable<IGrouping<int, PaymentFileResponseUnified>> unifiedsFilesGroupRecords = GetPaymentsResponsesFilesMatchByRecords(paymentOrderDetailRecevied, command);

        if (unifiedsFilesGroupRecords is null || unifiedsFilesGroupRecords.Count() == 0)
        {
            return Error.Failure("Respuesta de Archivos", "No se encontraron archivos.");
        }


        //Step 1: Get files with nomenglature OBS:
        var suffix = "_"+(Constants.NomenclatureReadNameFile.File_Observation).Trim();
        var fileswithObsXml = unifiedsFilesGroupRecords
        .SelectMany(group => group) // Flatten the elements
        .Where(x => x.FileName != null &&
                    x.FileName.EndsWith(string.Concat(suffix, ".xml"), StringComparison.OrdinalIgnoreCase))
        .ToList();

        foreach (PaymentFileResponseUnified paymentFileResponseUnified in fileswithObsXml)
        {
            //Level Payment Order:
            string fileName = paymentFileResponseUnified.FileName;

            var updateStatusPaymentFileCommandResult = await _mediator.Send(new SetStatusPaymentFileCommand(fileName, Constants.PaymentFileStatus.READ, command.PaymentSetting.Codigo, paymentFileResponseUnified.FileType, command.UserAction), cancellationToken);
            if (updateStatusPaymentFileCommandResult.IsError)
            {
                _logger.LogError(updateStatusPaymentFileCommandResult.FirstError.Description);
                return updateStatusPaymentFileCommandResult.FirstError;
            }


            var paymentFileResponses = new List<PaymentFileSetResponse>();
            foreach (var item in paymentFileResponseUnified.Details)
            {
                var auditRecord = new AuditRecord();
                var respuesta_item = new PaymentFileSetResponse(item.Id,
                                                                paymentFileResponseUnified.IdPaymentOrder,
                                                                item.CodigoUnico,
                                                                paymentFileResponseUnified.IdMassivePayment,
                                                                0,
                                                                Constants.PaymentOrderDetailStatus.ERROR,
                                                                "monto no procesado por el banco",
                                                                DateTime.Now.ToString("HH:mm:ss"),
                                                                auditRecord);
                paymentFileResponses.Add(respuesta_item);

            }

            var paymentFileContentResponse = Constants.PaymentOrderStatus.ERROR;

            // Step 1: Update Payments Order Details:
            var updateStatusPaymentOrderDetailFailureResult = await UpdateStatusPaymentOrderDetail(paymentFileResponses, Constants.PaymentOrderDetailStatus.ERROR, command.UserAction);

            if (updateStatusPaymentOrderDetailFailureResult.IsError)
            {
                _logger.LogError(updateStatusPaymentOrderDetailFailureResult.FirstError.Description);
                return updateStatusPaymentOrderDetailFailureResult.FirstError;
            }

            //Step 2: Update Status Payment Order
            Catalog? statusPaymentOrder = await _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_ORDER_STATUS, paymentFileContentResponse);
            PaymentOrderStatus paymentOrderStatus = new(statusPaymentOrder!.Codigo, statusPaymentOrder!.Id, statusPaymentOrder.Nombre);

            var updatePaymentOrderCommandResult = await _mediator.Send(new UpdatePaymentOrderCommand(paymentFileResponseUnified.IdPaymentOrder, paymentFileResponseUnified.IdMassivePayment, paymentOrderStatus, command.UserAction), cancellationToken);

            if (updatePaymentOrderCommandResult.IsError)
            {
                _logger.LogError(updatePaymentOrderCommandResult.FirstError.Description);
                return updatePaymentOrderCommandResult.FirstError;
            }
            string message = $"El archivo de respuesta {fileName} se mover� al historico.";

            _logger.LogInformation(message);

            var commandAudit = new CreatePaymentAuditCommand(
                paymentFileResponseUnified.IdPaymentOrder,
                0,
                $"ARCHIVO PAGO RESPUESTA",
                message,
                command.UserAction,
                _someApplication.GetRequestHost(),
                Constants.NAMEAPP
                );

            var createPaymentAuditResult = await _mediator.Send(commandAudit, cancellationToken);

            if (createPaymentAuditResult.IsError)
                return Error.Failure("Auditoria", "Error en registrar la auditoria para al actualizar un archivo pago.");

        }

        return clientMessageSuccess;
	}

	private async Task<ErrorOr<Unit>> UpdateStatusPaymentOrderDetail(List<PaymentFileSetResponse> paymentFileResponses, string status, string userAction)
	{

        if (paymentFileResponses.Count > 0)
		{
			var statusPaymentOrderDetail = await _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_ORDER_DETAIL_STATUS, status);
			PaymentOrderDetailStatus paymentOrderDetailStatus = new(statusPaymentOrderDetail!.Codigo, statusPaymentOrderDetail!.Id, statusPaymentOrderDetail.Nombre);

			// Step 1.2: Set param paymentFileResponse
			var updatePaymentOrderDetailCommand = await _mediator.Send(new UpdatePaymentOrderDetailCommand(paymentFileResponses, paymentOrderDetailStatus, userAction));

			if (updatePaymentOrderDetailCommand.IsError)
			{
				_logger.LogError(updatePaymentOrderDetailCommand.FirstError.Description);
				return updatePaymentOrderDetailCommand.FirstError;
			}
		}

		return Unit.Value;
	}
    private IEnumerable<IGrouping<int, PaymentFileResponseUnified>> GetPaymentsResponsesFilesMatchByRecords(List<PaymentOrderDetailDto> paymentOrderDetailRecevied, SetResponseFileObservationCommand command)
    {
        //Step 2: Get only the file name from the variable named paymentOrderDetailByStatusPaymentFile
        IEnumerable<IGrouping<int, PaymentFileResponseUnified>> unifiedsFilesGroup = [];

        var unifiedsFiles = command.PaymentsFilesResponsesUnifieds
            .GroupJoin(
                paymentOrderDetailRecevied,
                sftp => sftp.FileName,
                bd => bd.NombreArchivo,
                (sftp, detalles) => new PaymentFileResponseUnified
                {
                    FileName = sftp.FileName,
                    FileContent = sftp.FileContent,
                    Details = detalles.ToList(),
                    IdPaymentOrder = detalles.FirstOrDefault()?.IdOrdenPago ?? 0,
                    IdMassivePayment = detalles.FirstOrDefault()?.IdPagoMasivo ?? 0,
                    IdFileType = detalles.FirstOrDefault()?.IdCatalogoTipo ?? 0,
                    FileType = detalles.FirstOrDefault()?.CatalogoTipo ?? "",
                    FileOrder = detalles.FirstOrDefault()?.OrdenArchivo ?? 0
                })
            .OrderBy(x => x.FileName) // si quieres ordenar cronol�gicamente
            .ToList();

        unifiedsFilesGroup = unifiedsFiles.GroupBy(b => b.IdPaymentOrder);

        return unifiedsFilesGroup;
    }

}
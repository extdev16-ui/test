using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.Send;

public record SendPaymentFileCommand(
    string SourceRoute,
    string DestinationRoute,
    bool Delete,
    bool Historical,
    string PaymentSettingCode
) : IRequest<ErrorOr<Unit>>;
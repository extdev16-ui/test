using Application.PaymentsFiles.Interfaces;
using Application.PaymentsFiles.Request;
using ErrorOr;
using MediatR; 

namespace Application.PaymentsFiles.Send;

internal sealed class SendPaymentFileCommandHandler : IRequestHandler<SendPaymentFileCommand, ErrorOr<Unit>>
{
    private readonly IPaymentFileSFTP _paymentFileService;

    public SendPaymentFileCommandHandler(
        IPaymentFileSFTP paymentFileService)
    {
        _paymentFileService = paymentFileService ?? throw new ArgumentNullException(nameof(paymentFileService));
    }

    public async Task<ErrorOr<Unit>> Handle(SendPaymentFileCommand command, CancellationToken cancellationToken)
    {
        bool sendFtpResult;

        if (command.Historical)
            sendFtpResult = await _paymentFileService.SendToFtpsHistorical(new SendToFtpsRequest(command.SourceRoute, command.DestinationRoute, command.Delete, command.PaymentSettingCode));
        else
            sendFtpResult = await _paymentFileService.SendToFtps(new SendToFtpsRequest(command.SourceRoute, command.DestinationRoute, command.Delete, command.PaymentSettingCode));

        if (!sendFtpResult)
            return Error.Failure("Archivo Pago", "No se envió correctamente el archivo.");

        return Unit.Value;
    }

}
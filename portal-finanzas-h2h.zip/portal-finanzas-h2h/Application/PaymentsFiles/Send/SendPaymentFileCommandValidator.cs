using FluentValidation;

namespace Application.PaymentsFiles.Send;

public class SendPaymentFileCommandValidator : AbstractValidator<SendPaymentFileCommand>
{
    public SendPaymentFileCommandValidator()
    {
        RuleFor(r => r.SourceRoute).NotNull().NotEmpty()
             .WithName("Ruta Origen");
        RuleFor(r => r.DestinationRoute).NotNull().NotEmpty()
             .WithName("Ruta Destino");
    }
}
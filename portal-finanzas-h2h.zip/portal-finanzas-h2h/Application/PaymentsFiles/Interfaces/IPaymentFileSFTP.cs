using Application.PaymentsFiles.Request;
using Domain.PaymentsFiles.Models;

namespace Application.PaymentsFiles.Interfaces;

public interface IPaymentFileSFTP{
    Task<byte[]> Generate(string concatenatedContent);
    Task<bool> UploadToFtps(UploadToFtpsRequest uploadToFtpsRequest); 
    Task<bool> SendToFtps(SendToFtpsRequest sendToFtpsRequest);
    Task<bool> SendToFtpsHistorical(SendToFtpsRequest sendToFtpsRequest);
    Task<List<PaymentFileResponse>> GetFilesByRemoteDirectory(FileToFtpsRequest fileToFtpsRequest);
    Task<bool> DeleteFileFromFtp(FileToFtpsRequest fileToFtpsRequest);
    Task<byte[]?> GetFileToFtps(FileToFtpsRequest fileToFtpsRequest);
    Task<string?> GetContentToFtps(FileToFtpsRequest fileToFtpsRequest);
}
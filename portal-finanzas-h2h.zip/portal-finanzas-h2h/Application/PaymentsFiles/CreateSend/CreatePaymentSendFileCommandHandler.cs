using Application.Services;
using Application.PaymentsFiles.Interfaces;
using Application.PaymentsAudits.Create;
using Application.PaymentsFiles.Generate;
using MediatR;
using Domain.ValueObjects.PaymentsFiles;
using Domain.PaymentsFiles.Interfaces;
using Domain.Primitives;
using Domain.ValueObjects;
using Domain.Catalogs;
using Microsoft.Extensions.Logging;
using ErrorOr;
using Application.PaymentsFiles.Request;
using Domain.Common;
using Domain.PaymentsCalendar.Interfaces;
using Application.PaymentsCalendar.GetByPaymentSetting;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using Application.Services.GetDateByPaymentCalendar;
using Domain.PaymentsFiles.Models;

namespace Application.PaymentsFiles.CreateSend;

internal sealed class CreatePaymentSendFileCommandHandler : IRequestHandler<CreatePaymentSendFileCommand, ErrorOr<PaymentFile>>
{
	private readonly IPaymentFileWriteRepository _paymentFileRepository;
	private readonly ICatalogRepository _catalogRepository;
	private readonly IPaymentFileSFTP _paymentFileService;
	private readonly IPaymentCalendarRepository _paymentCalendarRepository;

	private readonly IUnitOfWork _unitOfWork;
	private readonly SomeApplication _someApplication;
	private readonly ISender _mediator;
	private readonly ILogger<GeneratePaymentFileCommandHandler> _logger;

	public CreatePaymentSendFileCommandHandler(
		IPaymentFileWriteRepository paymentFileRepository,
		ICatalogRepository catalogRepository,
		IPaymentFileSFTP paymentFileService,
		IPaymentCalendarRepository paymentCalendarRepository,
		IUnitOfWork unitOfWork,
		SomeApplication someApplication,
		ILogger<GeneratePaymentFileCommandHandler> logger,
		ISender mediator)
	{
		_paymentFileRepository = paymentFileRepository ?? throw new ArgumentNullException(nameof(paymentFileRepository));
		_catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
		_paymentFileService = paymentFileService ?? throw new ArgumentNullException(nameof(paymentFileService));
		_paymentCalendarRepository = paymentCalendarRepository ?? throw new ArgumentNullException(nameof(paymentCalendarRepository));
		_unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
		_someApplication = someApplication;
		_mediator = mediator;
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
	}

	public async Task<ErrorOr<PaymentFile>> Handle(CreatePaymentSendFileCommand command, CancellationToken cancellationToken)
	{
		//Get Setting Payment File
		PaymentFileName paymentFileName = new(command.PaymentSetting.DetalleConfiguraciones!);

		var getDateByPaymentCalendarQuery = await _mediator.Send(new GetDateByPaymentCalendarQuery(paymentFileName.FechaPago.ToString("yyyy-MM-dd"), command.PaymentSetting.Codigo), cancellationToken);
		if (getDateByPaymentCalendarQuery.IsError)
		{
			string message = getDateByPaymentCalendarQuery.FirstError.Description;
			_logger.LogError(message);
			return Error.Failure("Fecha Calendario Pago", message);
		}

		paymentFileName.FechaPago = getDateByPaymentCalendarQuery.Value;

		int correlative = await _paymentFileRepository.GetHigherCode(paymentFileName.FechaPago, command.PaymentSetting.Id, Constants.PaymentFileType.SEND);

		string cod_money = int.Parse(command.PaymentOrder.CatalogoMoneda.Codigo).ToString("D2");

		//Get Name By Nomenclature
		string nameFilePath = paymentFileName.GetPathFileNameNomenclature(correlative, cod_money, command.PaymentOrder.IdPagoMasivo);

		byte[]? getFileName;
		do
		{
			getFileName = await _paymentFileService.GetFileToFtps(new FileToFtpsRequest(nameFilePath, Constants.HISTORICAL_SFTP, command.PaymentSetting.Codigo));
			if (getFileName is not null)
			{
				correlative++;

				nameFilePath = paymentFileName.GetPathFileNameNomenclature(correlative, cod_money, command.PaymentOrder.IdPagoMasivo);
			}
		} while (getFileName is not null);

		if (AuditRecord.Create(command.UserCreated, _someApplication.GetRequestHost(), Constants.NAMEAPP) is not AuditRecord auditRecord)
			return Error.Validation("Auditoria", "Campos de Auditoria no tiene el formato correcto.");

		var paymentFile = new PaymentFile(
			paymentFileName.NombreArchivo,
			paymentFileName.FechaPago,
			_catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_FILE_STATUS, Constants.PaymentFileStatus.GENERATED).Result!.Id,
			_catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_FILE_TYPE, Constants.PaymentFileType.SEND).Result!,
			$"{nameFilePath}",
			command.PaymentSetting.Id,
			command.PaymentOrder.Id,
			auditRecord
		);

		_paymentFileRepository.Add(paymentFile);
		await _unitOfWork.SaveChangesAsync(cancellationToken);

		var commandAudit = new CreatePaymentAuditCommand(
			paymentFile.IdOrdenPago,
			0,
			"ARCHIVO PAGO GENERADO",
			$"Se creo nuevo archivo pago de la orden de pago {paymentFile.IdOrdenPago}",
			auditRecord.UsuarioCreador,
			_someApplication.GetRequestHost(),
			Constants.NAMEAPP
			);

		var createPaymentAuditResult = await _mediator.Send(commandAudit);

		if (createPaymentAuditResult.IsError)
			return Error.Failure("Auditoria", "Error en registrar la auditoria para al crear un archivo pago.");


		return paymentFile;

	}
}

using Domain.PaymentsFiles.Models;
using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.CreateSend;

public record CreatePaymentSendFileCommand(
    PaymentSetting PaymentSetting, 
    PaymentOrder PaymentOrder,
    string UserCreated
) : IRequest<ErrorOr<PaymentFile>>;
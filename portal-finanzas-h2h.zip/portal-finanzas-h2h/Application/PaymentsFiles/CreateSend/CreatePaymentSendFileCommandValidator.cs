using FluentValidation;

namespace Application.PaymentsFiles.CreateSend;

public class CreatePaymentSendFileCommandValidator : AbstractValidator<CreatePaymentSendFileCommand>
{
    public CreatePaymentSendFileCommandValidator()
    {

        RuleFor(r => r.PaymentSetting).NotNull()
             .WithName("Configuración Pago");
        RuleFor(r => r.PaymentOrder).NotNull()
             .WithName("Orden Pago");
        RuleFor(r => r.UserCreated).NotEmpty().NotNull()
             .WithName("Usuario Creador");
    }
}
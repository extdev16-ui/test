﻿using Domain.PaymentsFiles.Models;
using ErrorOr;
using MediatR;
namespace Application.PaymentsFiles.Download;

public record DownloadPaymentFileQuery(int IdPaymentFile) : IRequest<ErrorOr<PaymentFile>>;
using Application.PaymentsFiles.GetByPaymentOrder;
using Application.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Interfaces;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using Application.PaymentsFiles.Request;
using Domain.PaymentsFiles.Models;

namespace Application.PaymentsFiles.Download;

internal sealed class DownloadPaymentFileQueryHandler : IRequestHandler<DownloadPaymentFileQuery, ErrorOr<PaymentFile>>
{
    private readonly IPaymentFileWriteRepository _paymentFileRepository;
    private readonly IPaymentFileSFTP _paymentFileService;
    private readonly ISender _mediator;
    private readonly ILogger<DownloadPaymentFileQueryHandler> _logger;

    public DownloadPaymentFileQueryHandler(IPaymentFileWriteRepository paymentFileRepository,
                                     IPaymentFileSFTP paymentFileService,
                                    ISender mediator,
                                    ILogger<DownloadPaymentFileQueryHandler> logger)
    {
        _paymentFileRepository = paymentFileRepository;
        _paymentFileService = paymentFileService;
        _mediator = mediator;
        _logger = logger;
    }

    public async Task<ErrorOr<PaymentFile>> Handle(DownloadPaymentFileQuery query, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Inicio de la descarga de archivo de pago.");
        using (LogContext.PushProperty("Identifier", string.Concat("Id Archivo Pago: ", query.IdPaymentFile)))
        {
            _logger.LogInformation("Obtener los datos del archivo por id archivo pago.");

            PaymentFile? paymentFile = await _paymentFileRepository.GetById(query.IdPaymentFile);

            if (paymentFile is null)
            {
                _logger.LogError($"Archivo Pago: No se encontr� el archivo en la base de datos.");
                return Error.Failure("Archivo Pago", $"Archivo Pago: No se encontr� el archivo en la base de datos.");
			}

			_logger.LogInformation("Obtener la ruta del archivo para consultar en el sftp.");

            //Step 2: Get rout path DownloadRoute
            string routePath = paymentFile.GetDownloadRoute(paymentFile.CatalogoTipo.Codigo);

            _logger.LogInformation("Obtener el archivo f�sico del pago en el sftp.");
            var byteFile = await _paymentFileService.GetFileToFtps(new FileToFtpsRequest(routePath, Domain.Common.Constants.HISTORICAL_SFTP, paymentFile.ConfiguracionPago.Codigo));

            if (byteFile is null)
            {
                _logger.LogError($"Archivo Pago: No se encontr� el archivo {paymentFile.Nombre} en el sftp.");
                return Error.Failure("Archivo Pago", $"Archivo Pago: No se encontr� el archivo {paymentFile.Nombre} en el sftp.");
            }
            paymentFile.ArchivoByte = byteFile;

            paymentFile.Nombre = paymentFile.GetFileName(paymentFile.Nombre, paymentFile.ConfiguracionPago.Codigo, paymentFile.CatalogoTipo.Codigo);

            _logger.LogInformation("Archivo encontrado y listo para descargar.");

            return paymentFile;
        }
    }
}
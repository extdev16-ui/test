﻿using Domain.ValueObjects.PaymentsFiles;
using Microsoft.Extensions.Logging;
using Application.Dependencies;
using Domain.PaymentsFiles.ResponseGet;
using Domain.PaymentsOrdersDetails.Common;
using Domain.PaymentsSettings;
using Application.Common.Logging;
using Domain.PaymentsFiles.Models;

namespace Application.PaymentsFiles.Common;

public class PaymentFileResponseGetterFactory : IPaymentFileResponseGetterFactory
{
	private readonly IPaymentFileResponseGetter<PaymentFileFormatTxt> _txtGetter;
	private readonly IPaymentFileResponseGetter<PaymentFileFormatXml> _xmlGetter;
	private readonly ILogger<PaymentFileResponseGetterFactory> _logger;

	public PaymentFileResponseGetterFactory(
		IPaymentFileResponseGetter<PaymentFileFormatTxt> txtGetter,
		IPaymentFileResponseGetter<PaymentFileFormatXml> xmlGetter,
	ILogger<PaymentFileResponseGetterFactory> logger)
	{
		_txtGetter = txtGetter;
		_xmlGetter = xmlGetter;
		_logger = logger;
	}

	public PaymentFileResponseUnified? GetResponse(PaymentFileResponseUnified paymentResponseFile, PaymentSetting paymentSetting)
	{
		PaymentFileResponseUnified? paymentResponse = null;

		try
		{

			string? fileFormat = paymentSetting.DetalleConfiguraciones!.Find(c => c.Nombre == "formatoArchivo")?.Valor!;

			paymentSetting.DeserializeFormatByFileType();

			switch (fileFormat.ToLower())
			{
				case "xml":
					paymentResponse = _xmlGetter.GetResponse(paymentResponseFile, paymentSetting);
					break;
				case "txt":
					paymentResponse = _txtGetter.GetResponse(paymentResponseFile, paymentSetting);
					break;
				default:
					{
						string message = $"Tipo de archivo '{fileFormat}' no soportado.";
						_logger.LogError(message);
						throw new NotSupportedException(message);
					};
			};

			return paymentResponse;
		}
		catch(Exception ex)
		{
			_logger.LogWarning(ex);
			return paymentResponse;
		}
	}
}

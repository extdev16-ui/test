﻿using Domain.MassivesPayments.Common;
using Domain.PaymentsFiles.Generators;
using Domain.ValueObjects.PaymentsFiles;
using Domain.PaymentsSettings;
using Application.PaymentsFiles.Interfaces;
using System.Text;
using Microsoft.Extensions.Logging;
using Domain.PaymentsFiles.Processors;
using Application.PaymentsFiles.Request;
using Application.Dependencies;
using Application.Dependencies.Models;
using NPOI.HPSF;
using Domain.PaymentsOrders;

namespace Application.PaymentsFiles.Common;

public class PaymentFileGeneratorFactory : IPaymentFileGeneratorFactory
{
	private readonly IPaymentFileGenerator<PaymentFileFormatTxt> _txtGenerator;
	private readonly IPaymentFileGenerator<PaymentFileFormatXml> _xmlGenerator;
	private readonly IValidatorPaymentFileXml _validatorPaymentFormatXml;
	private readonly ISignaturePaymentFile _signaturePaymentFile;
	private readonly IPaymentFileSFTP _paymentFileSFTP;
	private readonly ISecretsManagerCredentialsProvider _vaultCredentialsProvider;
	private readonly ILogger<PaymentFileGeneratorFactory> _logger;

	public PaymentFileGeneratorFactory(
		IPaymentFileGenerator<PaymentFileFormatTxt> txtGenerator,
		IPaymentFileGenerator<PaymentFileFormatXml> xmlGenerator,
		IPaymentFileSFTP paymentFileSFTP,
		ISignaturePaymentFile signaturePaymentFile,
		IValidatorPaymentFileXml validatorPaymentFormatXml,
		ISecretsManagerCredentialsProvider vaultCredentialsProvider,
	ILogger<PaymentFileGeneratorFactory> logger)
	{
		_txtGenerator = txtGenerator;
		_xmlGenerator = xmlGenerator;
		_paymentFileSFTP = paymentFileSFTP;
		_signaturePaymentFile = signaturePaymentFile;
		_validatorPaymentFormatXml = validatorPaymentFormatXml;
		_vaultCredentialsProvider = vaultCredentialsProvider;
		_logger = logger;
    }

	public async Task<string> GenerateContent(MassivePaymentResponse massivePaymentResponse, PaymentSetting paymentSettings, string fileName, DateTime datePayment ,PaymentOrder paymentOrder)
	{
		string contentFile = string.Empty;
		string? fileFormat = paymentSettings.DetalleConfiguraciones!.Find(c => c.Nombre == "formatoArchivo")?.Valor;

		paymentSettings.DeserializeFormatByFileType();

		switch (fileFormat!.ToLower())
		{
			case "txt":
				contentFile = _txtGenerator.GenerateContent(massivePaymentResponse, paymentSettings, fileName, datePayment, paymentOrder);
				break;
			case "xml":
				contentFile = await GenerateXml(massivePaymentResponse, paymentSettings, fileName, datePayment, paymentOrder);
				break;
			default:
				{
					string message = $"Tipo de archivo '{fileFormat}' no soportado.";
					_logger.LogError(message);
					throw new NotSupportedException(message);

				};
		};

		return contentFile;
	}

	private async Task<string> GenerateXml(MassivePaymentResponse massivePaymentResponse, PaymentSetting paymentSettings, string fileName, DateTime datePayment, PaymentOrder paymentOrder)
	{
		//Step 1: Generate content
		string contentFileXML = _xmlGenerator.GenerateContent(massivePaymentResponse, paymentSettings, fileName, datePayment, paymentOrder);

		//Step 2: Validator XSD
		string? xsdPath = paymentSettings.DetalleConfiguraciones!.Find(c => c.Nombre == "rutaArchivoXSD")?.Valor;

		if (!string.IsNullOrEmpty(xsdPath))
		{
			string xmlContent = contentFileXML;
			string? xsdSource = paymentSettings.DetalleConfiguraciones!.Find(c => c.Nombre == "rutaArchivoXSD")?.Origen;

			byte[]? xsdContentByte = await DownloadXsdFromFtps(xsdPath, xsdSource!, paymentSettings.Codigo);

			if (xsdContentByte is null)
			{
				string message = $"No se encontró el Validador XSD de la configuracion de pago {paymentSettings.Codigo}.";
				_logger.LogError(message);
				throw new NotSupportedException(message);
			}

			string xsdContentString = Encoding.UTF8.GetString(xsdContentByte!);
			if (!string.IsNullOrEmpty(xsdContentString))
			{
				List<string> listErrorValidationXxd = _validatorPaymentFormatXml.ValidateXmlWithXsd(xmlContent, xsdContentString);
				if (listErrorValidationXxd.Count > 0)
				{
					listErrorValidationXxd.ForEach(error =>
					{
						_logger.LogError("Error de validación XSD: {Error}", error);
					});

					contentFileXML = string.Empty;
				}
			}
		}
		else
		{
			string message = $"No se encontró el archivo xSD para la validación de XML.";
			_logger.LogError(message);
			throw new NotSupportedException(message);
		}

		//Step 3: Signature XSD
		PGPkey? pGPkey = _vaultCredentialsProvider.GetPgpKeyByPaymentSetting(paymentSettings.Codigo);

		if (pGPkey is not null)
		{
			string contentfileSign = contentFileXML;

			byte[]? signContentByte = await DownloadXsdFromFtps(pGPkey.Path, pGPkey.Source, paymentSettings.Codigo);
				
			if(signContentByte is null)
			{
				string message = $"No se encontró la llave PGP de la configuracion de pago {paymentSettings.Codigo}.";
				_logger.LogError(message);
				throw new NotSupportedException(message);
			}
			string signature = _signaturePaymentFile.SignFileHash(signContentByte, pGPkey.Password, contentfileSign, pGPkey.ExecGPG);

			if (string.IsNullOrEmpty(signature))
			{
				string message = $"No se firmo correctamente el archivo de pago {massivePaymentResponse.IdPagoMasivo}.";
				_logger.LogError(message);
				throw new NotSupportedException(message);
			}

			massivePaymentResponse.FirmaDigital = signature;

			contentfileSign = contentfileSign.Replace("<Prtry></Prtry>", $"<Prtry>{massivePaymentResponse.FirmaDigital}</Prtry>");

			if (string.IsNullOrEmpty(contentfileSign))
			{
				string message = $"Hubo error al generar el archivo de pago {massivePaymentResponse.IdPagoMasivo} con la firma digital.";
				_logger.LogError(message);
				throw new NotSupportedException(message);
			}
			contentFileXML = contentfileSign;
		}

		return contentFileXML;
	}
	private async Task<byte[]?> DownloadXsdFromFtps(string xsdPath, string xsdSource, string paymentSettingCode)
	{
		byte[]? xsdBytes = null;
		switch (xsdSource)
		{
			case "SFTP":
				{
					xsdBytes = await _paymentFileSFTP.GetFileToFtps(new FileToFtpsRequest(xsdPath, Domain.Common.Constants.HISTORICAL_SFTP, paymentSettingCode));
				}
				break;
			default: throw new NotSupportedException($"Tipo de origen de archivo no soportado.");
		}

		return xsdBytes;
	}

}

﻿
namespace Application.PaymentsFiles.Request	
{
	public class SendToFtpsRequest(string ftpsSourceRoute, string ftpsDestinationRoute, bool delete, string paymentSettingCode)
	{
		public string FtpsSourceRoute { get; set; } = ftpsSourceRoute;
		public string FtpsDestinationRoute { get; set; } = ftpsDestinationRoute;
		public bool Delete { get; set; } = delete;
		public string PaymentSettingCode { get; set; } = paymentSettingCode;
	}
}

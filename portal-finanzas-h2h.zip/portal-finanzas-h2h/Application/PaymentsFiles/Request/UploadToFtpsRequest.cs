﻿
namespace Application.PaymentsFiles.Request	
{
	public class UploadToFtpsRequest
	{
		public UploadToFtpsRequest(byte[] fileBuffer, string pathFtps, bool historicalFtps, string paymentSettingCode)
		{
			FileBuffer = fileBuffer;
			PathFtps = pathFtps;
			HistoricalFtps = historicalFtps;
			PaymentSettingCode = paymentSettingCode;
		}

		public byte[] FileBuffer {  get; set; }
		public string PathFtps { get; set; } = string.Empty;
		public bool HistoricalFtps { get; set; }
		public string PaymentSettingCode { get; set; } = string.Empty;
	}
}

﻿
namespace Application.PaymentsFiles.Request	
{
	public class FileToFtpsRequest
	{
		public FileToFtpsRequest(string pathFtps, bool historicalSFtp, string paymentSettingCode)
		{
			PathFtps = pathFtps;
			HistoricalSFtp = historicalSFtp;
			PaymentSettingCode = paymentSettingCode;
		}
		 
		public string PathFtps { get; set; } = string.Empty;
		public bool HistoricalSFtp { get; set; }
		public string PaymentSettingCode { get; set; } = string.Empty;
	}
}

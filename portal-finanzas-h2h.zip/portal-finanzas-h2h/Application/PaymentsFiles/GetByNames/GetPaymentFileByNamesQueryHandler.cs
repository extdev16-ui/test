using ErrorOr;
using MediatR;
using Domain.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Models;

namespace Application.PaymentsFiles.GetByNames;

internal sealed class GetPaymentFileByNamesQueryHandler : IRequestHandler<GetPaymentFileByNamesQuery, ErrorOr<List<PaymentFile>>>
{
    private readonly IPaymentFileReadRepository _paymentFileDapperRepository;


    public GetPaymentFileByNamesQueryHandler(IPaymentFileReadRepository paymentFileDapperRepository)
    {
        _paymentFileDapperRepository = paymentFileDapperRepository;
    }

    public async Task<ErrorOr<List<PaymentFile>>> Handle(GetPaymentFileByNamesQuery query, CancellationToken cancellationToken)
    {
        List<PaymentFile> paymentFiles = await _paymentFileDapperRepository.GetByFileNames(query.FileNames);

        if (paymentFiles.Count == 0)
            return Error.Validation("Archivo Pago", "No existe un archivo de pago relacionada.");

        return paymentFiles;
    }
}
﻿using Domain.PaymentsFiles.Models;
using ErrorOr;
using MediatR;
namespace Application.PaymentsFiles.GetByNames;

public record GetPaymentFileByNamesQuery(string FileNames) : IRequest<ErrorOr<List<PaymentFile>>>;
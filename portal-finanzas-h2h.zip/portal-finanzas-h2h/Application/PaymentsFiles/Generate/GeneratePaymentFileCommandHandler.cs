using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Domain.Common;
using Domain.PaymentsFiles.Generators;
using Application.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Interfaces;
using Application.PaymentsFiles.Request;

namespace Application.PaymentsFiles.Generate;

internal sealed class GeneratePaymentFileCommandHandler : IRequestHandler<GeneratePaymentFileCommand, ErrorOr<Unit>>
{
    private readonly IPaymentFileSFTP _paymentFileService;
    private readonly IPaymentFileWriteRepository _paymentFileRepository;
    private readonly ILogger<GeneratePaymentFileCommandHandler> _logger;
    private readonly IPaymentFileGeneratorFactory _paymentFileGeneratorFactory;
    private readonly ISender _mediator;

    public GeneratePaymentFileCommandHandler(
        IPaymentFileSFTP paymentFileService,
        IPaymentFileWriteRepository paymentFileRepository,
        ILogger<GeneratePaymentFileCommandHandler> logger,
        IPaymentFileGeneratorFactory paymentFileGeneratorFactory,
        ISender mediator)
    {
        _paymentFileService = paymentFileService ?? throw new ArgumentNullException(nameof(paymentFileService));
        _paymentFileRepository = paymentFileRepository ?? throw new ArgumentNullException(nameof(paymentFileRepository));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _paymentFileGeneratorFactory = paymentFileGeneratorFactory ?? throw new ArgumentNullException(nameof(paymentFileGeneratorFactory));
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
    }

    public async Task<ErrorOr<Unit>> Handle(GeneratePaymentFileCommand command, CancellationToken cancellationToken)
    {
        var massivePaymentResponse = command.MassivePaymentResponse!;
        var paymentSetting = command.PaymentSetting!;

        // Step 1: Generate content file
        string contentFile = await _paymentFileGeneratorFactory.GenerateContent(massivePaymentResponse, paymentSetting, command.FileName,command.DatePayment,command.PaymentOrder);

        if (contentFile is null || contentFile.Length == 0)
        {
            return Error.Failure("Archivo Pago", "El contenido del archivo no se gener� correctamente.");
        }

        // Step 2: Generate payment file
        var fileBytes = await _paymentFileService.Generate(contentFile);
        if (fileBytes is null)
            return Error.Failure("Archivo Pago", "No se gener� correctamente el archivo.");

        // Step 3: Upload to Ftps Send Historical
        string routeSFTPHistoricalSend = paymentSetting.DetalleConfiguraciones!.Find(c => c.Nombre == "rutaFTPHistoricoEnvio")?.Valor!;

        bool ftpUploadResult = await _paymentFileService.UploadToFtps(new UploadToFtpsRequest(fileBytes, $"{routeSFTPHistoricalSend}{command.FileName}", Constants.HISTORICAL_SFTP, paymentSetting.Codigo));

        if (!ftpUploadResult)
            return Error.Failure("Archivo Pago", "No se gener� correctamente el archivo.");

        return Unit.Value;
    }
}
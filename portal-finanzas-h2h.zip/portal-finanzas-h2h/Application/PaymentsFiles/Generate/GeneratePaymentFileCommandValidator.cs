using FluentValidation;

namespace Application.PaymentsFiles.Generate;

public class GeneratePaymentFileCommandValidator : AbstractValidator<GeneratePaymentFileCommand>
{
    public GeneratePaymentFileCommandValidator()
    {
        RuleFor(r => r.MassivePaymentResponse).NotNull()
             .WithName("Pago Masivo");
        RuleFor(r => r.PaymentSetting).NotNull()
             .WithName("Configuraci�n Pago");
    }
}
using Domain.Helpers;
using Domain.MassivesPayments.Common;
using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.Generate;

public record ValidateGeneratePaymentFileCommand(
    MassivePaymentResponse MassivePaymentResponse
) : IRequest<ErrorOr<ValidationResponseMessage>>;
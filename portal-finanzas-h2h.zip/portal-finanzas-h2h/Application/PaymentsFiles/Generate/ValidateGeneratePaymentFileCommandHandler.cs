using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Application.PaymentsOrders.GetByMassivePayment;
using Application.PaymentsOrdersDetails.DuplicateExistsForUniqueCode;
using Domain.PaymentsSettings;
using Domain.Helpers; 
using Domain.MassivesPayments.Common;
using Application.PaymentsSettings.GetByCode;
using Domain.PaymentsSettings.Validators;

namespace Application.PaymentsFiles.Generate;
internal sealed class ValidateGeneratePaymentFileCommandHandler : IRequestHandler<ValidateGeneratePaymentFileCommand, ErrorOr<ValidationResponseMessage>>
{
	private readonly IValidatePaymentSetting _validatePaymentSetting;
	private readonly ILogger<ValidateGeneratePaymentFileCommandHandler> _logger;
	private readonly ISender _mediator;

	public ValidateGeneratePaymentFileCommandHandler(
												IValidatePaymentSetting validatePaymentSetting,
												ILogger<ValidateGeneratePaymentFileCommandHandler> logger,
												ISender mediator
												)
	{
		_validatePaymentSetting = validatePaymentSetting ?? throw new ArgumentNullException(nameof(validatePaymentSetting));
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
	}

	public async Task<ErrorOr<ValidationResponseMessage>> Handle(ValidateGeneratePaymentFileCommand command, CancellationToken cancellationToken)
	{
		var validationResponseMessage = new ValidationResponseMessage();

		var getPaymentOrderByMassivePayment = await _mediator.Send(new GetPaymentOrderByMassivePaymentQuery(command.MassivePaymentResponse.IdPagoMasivo), cancellationToken);

		if (getPaymentOrderByMassivePayment.Value is not null)
			return Error.Validation("Orden Pago", "Ya existe una orden de pago relacionada al pago masivo.");

		List<string>? uniquesCodes = command.MassivePaymentResponse.Detalle.Where(c => c.CodigoUnico.Length > 0).Select(x => x.CodigoUnico).ToList();

		if (uniquesCodes.Count == 0)
			return Error.Validation("Orden Pago Detalle", "No existe codigo unico en orden pago detalle.");

		var duplicateExistsPaymentOrderDetail = await _mediator.Send(new DuplicateExistsForUniqueCodeQuery(uniquesCodes), cancellationToken);

		if (duplicateExistsPaymentOrderDetail.Value)
			return Error.Validation("Orden Pago Detalle", "Se encontr� un registro duplicado en orden pago detalle.");


		//Get Payments Settings
		var resultPaymentSetting = await ValidatePaymentSetting(command.MassivePaymentResponse);

		if (resultPaymentSetting.IsError)
			return resultPaymentSetting.FirstError;

		PaymentSetting? paymentSetting = resultPaymentSetting.Value!;

		validationResponseMessage.massivePaymentResponse = command.MassivePaymentResponse;
		validationResponseMessage.paymentSetting = paymentSetting;

		return validationResponseMessage;
	}

	public async Task<ErrorOr<PaymentSetting?>> ValidatePaymentSetting(MassivePaymentResponse massivePaymentResponse)
	{
		//Step 1: Get payment setting by code
		var getPaymentSettingByCodeQuery = await _mediator.Send(new GetPaymentSettingByCodeQuery(massivePaymentResponse.ConfiguracionPago));

		if (getPaymentSettingByCodeQuery.IsError)
		{
			_logger.LogError(getPaymentSettingByCodeQuery.FirstError.Description);
			return getPaymentSettingByCodeQuery.FirstError;
		}

		var paymentSetting = getPaymentSettingByCodeQuery.Value;

		//Validation Payment Setting
		var validationResponseMessage = _validatePaymentSetting.ValidatePaymentSettingDetail(paymentSetting);

		if (!validationResponseMessage.Validated)
			return Error.Failure(validationResponseMessage.Title!, validationResponseMessage.Message!);


		var ruleResponseMessage = _validatePaymentSetting.ValidatePaymentRule(paymentSetting, massivePaymentResponse);
		//Rules Validation
		if (!ruleResponseMessage.Validated)
			return Error.Validation(ruleResponseMessage.Title!, ruleResponseMessage.Message!);

		return paymentSetting;
	}

}
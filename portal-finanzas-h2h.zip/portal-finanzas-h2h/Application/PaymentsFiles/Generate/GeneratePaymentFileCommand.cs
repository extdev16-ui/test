using Domain.MassivesPayments.Common;
using Domain.PaymentsOrders;
using Domain.PaymentsSettings;
using Domain.ValueObjects.PaymentsFiles;
using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.Generate;

public record GeneratePaymentFileCommand(
    MassivePaymentResponse MassivePaymentResponse,
    PaymentSetting PaymentSetting,
    string FileName,
    DateTime DatePayment,
    PaymentOrder PaymentOrder
) : IRequest<ErrorOr<Unit>>;
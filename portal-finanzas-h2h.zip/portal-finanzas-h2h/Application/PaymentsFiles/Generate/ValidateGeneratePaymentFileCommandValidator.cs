using FluentValidation;

namespace Application.PaymentsFiles.Generate;

public class ValidateGeneratePaymentFile : AbstractValidator<ValidateGeneratePaymentFileCommand>
{
    public ValidateGeneratePaymentFile()
    {
        RuleFor(r => r.MassivePaymentResponse).NotNull()
             .WithName("Pago Masivo");
    }
}
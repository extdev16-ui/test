using ErrorOr;
using MediatR;
using Domain.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Models;

namespace Application.PaymentsFiles.GetByMassivePayment;

internal sealed class GetPaymentFileByMassivePaymentQueryHandler : IRequestHandler<GetPaymentFileByMassivePaymentQuery, ErrorOr<PaymentFile?>>
{
    private readonly IPaymentFileWriteRepository _paymentFileRepository;


    public GetPaymentFileByMassivePaymentQueryHandler(IPaymentFileWriteRepository paymentFileRepository)
    {
        _paymentFileRepository = paymentFileRepository;
    }

    public async Task<ErrorOr<PaymentFile?>> Handle(GetPaymentFileByMassivePaymentQuery query, CancellationToken cancellationToken)
    {
        PaymentFile? paymentFile = await _paymentFileRepository.GetByMassivePayment(query.IdMassivePayment, query.Type);

        if (paymentFile is null)
            return Error.Validation("Archivo Pago", "No existe un archivo de pago relacionada.");        

        return paymentFile!;
    }
}
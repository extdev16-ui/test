﻿using Domain.PaymentsFiles.Models;
using ErrorOr;
using MediatR;
namespace Application.PaymentsFiles.GetByMassivePayment;

public record GetPaymentFileByMassivePaymentQuery(int IdMassivePayment, string Type) : IRequest<ErrorOr<PaymentFile?>>;
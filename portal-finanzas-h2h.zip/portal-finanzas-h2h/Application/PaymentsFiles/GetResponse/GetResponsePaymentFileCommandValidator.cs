using FluentValidation;

namespace Application.PaymentsFiles.GetResponse;

public class GetResponsePaymentFileCommandValidator : AbstractValidator<GetResponsePaymentFileCommand>
{
    public GetResponsePaymentFileCommandValidator()
    {
        RuleFor(r => r.ResponsesPaymentFiles).NotNull().NotEmpty()
             .WithName("Archivos de respuesta");
        RuleFor(r => r.PaymentSetting).NotNull().NotEmpty()
             .WithName("Configuracion de pago");
    }
}
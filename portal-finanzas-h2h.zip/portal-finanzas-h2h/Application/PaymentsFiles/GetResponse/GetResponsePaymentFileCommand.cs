using Domain.PaymentsFiles.Models;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.GetResponse;

public record GetResponsePaymentFileCommand(
	List<PaymentFileResponse> ResponsesPaymentFiles,
	PaymentSetting PaymentSetting
) : IRequest<ErrorOr<List<PaymentFileResponseUnified>>>;
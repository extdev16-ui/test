using Application.Services.PaymentResponseFileProcessor;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Domain.PaymentsOrdersDetails.Interfaces;
using Domain.PaymentsFiles.ResponseGet;
using Domain.PaymentsOrdersDetails.Common;
using Domain.Common;
using Domain.PaymentsFiles.Models;
using Application.Helpers;

namespace Application.PaymentsFiles.GetResponse;

internal sealed class GetResponsePaymentFileCommandHandler : IRequestHandler<GetResponsePaymentFileCommand, ErrorOr<List<PaymentFileResponseUnified>>>
{
	private readonly ILogger<PaymentResponseFileProcessorCommandHandler> _logger;
	private readonly IPaymentOrderDetailReadRepository _paymentOrderDetailReadRepository;
	private readonly IPaymentFileResponseGetterFactory _paymentFileResponseGetterFactory;

	public GetResponsePaymentFileCommandHandler(
		ILogger<PaymentResponseFileProcessorCommandHandler> logger,
		IPaymentOrderDetailReadRepository paymentOrderDetailReadRepository,
		IPaymentFileResponseGetterFactory paymentFileResponseGetterFactory)
	{
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_paymentOrderDetailReadRepository = paymentOrderDetailReadRepository ?? throw new ArgumentNullException(nameof(paymentOrderDetailReadRepository));
		_paymentFileResponseGetterFactory = paymentFileResponseGetterFactory ?? throw new ArgumentNullException(nameof(paymentFileResponseGetterFactory));
	}

	public async Task<ErrorOr<List<PaymentFileResponseUnified>>> Handle(GetResponsePaymentFileCommand command, CancellationToken cancellationToken)
	{
		//Step 1: Get the shipping payment file in status received by BD
		List<PaymentOrderDetailDto> paymentOrderDetailRecevied = await _paymentOrderDetailReadRepository.GetByStatusPaymentResponseFile(Constants.PaymentFileStatus.RECEIVED);

		var responsesPaymentFiles = command.ResponsesPaymentFiles;

		IEnumerable<IGrouping<int, PaymentFileResponseUnified>> unifiedsFilesGroupRecords = GetPaymentsResponsesFilesMatchByRecords(paymentOrderDetailRecevied, responsesPaymentFiles);

		if (unifiedsFilesGroupRecords is null || unifiedsFilesGroupRecords.Count() == 0)
		{
			return Error.Failure("Respuesta de Archivos", "No se encontraron archivos.");
		}

		List<PaymentFileResponseUnified> paymentResponseFiles = [];

		foreach (IGrouping<int, PaymentFileResponseUnified> unifiedsFilesRecords in unifiedsFilesGroupRecords)
		{
			Console.WriteLine($"Payment Order: {unifiedsFilesRecords.Key}");

			var unifiedsFilesRecordsList = unifiedsFilesRecords.OrderBy(c => c.FileOrder).ToList();

			int indexUnifiedFileRecord = 1;

			foreach (var unifiedFileRecord in unifiedsFilesRecordsList)
			{
				unifiedFileRecord.Index = indexUnifiedFileRecord;
				PaymentFileResponseUnified? paymentResponseFile = new();

				if(unifiedFileRecord.IdPaymentOrder == 0)
				{
					unifiedFileRecord.SetNotFound();
					paymentResponseFiles.Add(unifiedFileRecord);
					continue;
				}

				switch (unifiedFileRecord.FileType)
				{
					case Constants.PaymentFileType.RESPONSE:
						{
							paymentResponseFile = _paymentFileResponseGetterFactory.GetResponse(unifiedFileRecord, command.PaymentSetting);
						}
						break;
					case Constants.PaymentFileType.VOUCHER:
						{
							paymentResponseFile = unifiedFileRecord;
						}
						break;
					default:
						{
							unifiedFileRecord.SetFileTypeNotImplement();
							unifiedFileRecord.SetNotFound();
							paymentResponseFiles.Add(unifiedFileRecord);
						}
						break;
				}
				
				if(paymentResponseFile is not null)
					paymentResponseFiles.Add(paymentResponseFile);				 

				indexUnifiedFileRecord++;
			}
		}

		bool notExists = paymentResponseFiles.Where(c => c.PaymentFileContentResponse.NotExistResponse && c.IsRead && c.FileType == Constants.PaymentFileType.RESPONSE).Any();

		if (notExists)
		{
			return Error.Failure("Respuesta de Lectura de Archivos", "No se encontró el detalle de los pagos.");
		}

		return paymentResponseFiles;
	}
	private IEnumerable<IGrouping<int, PaymentFileResponseUnified>> GetPaymentsResponsesFilesMatchByRecords(List<PaymentOrderDetailDto> paymentOrderDetailRecevied, List<PaymentFileResponse> responsesPaymentFiles)
	{
		//Step 2: Get only the file name from the variable named paymentOrderDetailByStatusPaymentFile
		IEnumerable<IGrouping<int, PaymentFileResponseUnified>> unifiedsFilesGroup = [];

		var unifiedsFiles = responsesPaymentFiles
			.GroupJoin(
				paymentOrderDetailRecevied,
				sftp => sftp.FileName,
				bd => bd.NombreArchivo,
				(sftp, detalles) => new PaymentFileResponseUnified
				{
					FileName = sftp.FileName,
					FileContent = sftp.FileContent,
					Details = detalles.ToList(),
					IdPaymentOrder = detalles.FirstOrDefault()?.IdOrdenPago ?? 0,
					IdMassivePayment = detalles.FirstOrDefault()?.IdPagoMasivo ?? 0,
					IdFileType = detalles.FirstOrDefault()?.IdCatalogoTipo ?? 0,
					FileType = detalles.FirstOrDefault()?.CatalogoTipo ?? "INDEFINIDO",
					FileOrder = detalles.FirstOrDefault()?.OrdenArchivo ?? 0
				})
			.OrderBy(x => x.FileName) // si quieres ordenar cronológicamente
			.ToList();

		unifiedsFilesGroup = unifiedsFiles.GroupBy(b => b.IdPaymentOrder);

		return unifiedsFilesGroup;
	}
}
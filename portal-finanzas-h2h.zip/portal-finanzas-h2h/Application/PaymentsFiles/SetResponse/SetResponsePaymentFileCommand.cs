using Application.Helpers;
using Domain.PaymentsFiles.Models;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;

namespace Application.PaymentsFiles.SetResponse;

public record SetResponsePaymentFileCommand( 
	List<PaymentFileResponseUnified> PaymentsFilesResponsesUnifieds, PaymentSetting PaymentSetting, string UserAction
) : IRequest<ErrorOr<ClientMessageSuccess<ResponsePaymentFile>>>;
using FluentValidation;

namespace Application.PaymentsFiles.SetResponse;

public class SetResponsePaymentFileCommandValidator : AbstractValidator<SetResponsePaymentFileCommand>
{
    public SetResponsePaymentFileCommandValidator()
    {
        RuleFor(r => r.PaymentsFilesResponsesUnifieds).NotNull().NotEmpty()
             .WithName("Archivos de respuesta");
        RuleFor(r => r.PaymentSetting).NotNull().NotEmpty()
             .WithName("Configuracion de pago");
		RuleFor(r => r.UserAction).NotNull().NotEmpty()
			 .WithName("Usuario Accion");
	}
}
using Application.Services.PaymentResponseFileProcessor;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Application.Helpers;
using Application.PaymentsOrders.Update;
using Application.Services.SetStatusPaymentFile;
using Domain.Catalogs;
using Application.PaymentsOrdersDetails.Update;
using Domain.Common;
using Application.PaymentsAudits.Create;
using Application.Services;
using Domain.PaymentsFiles.Models;
using Domain.ValueObjects;
//using static Domain.Common.Constants;

namespace Application.PaymentsFiles.SetResponse;

internal sealed class SetResponsePaymentFileCommandHandler : IRequestHandler<SetResponsePaymentFileCommand, ErrorOr<ClientMessageSuccess<ResponsePaymentFile>>>
{
	private readonly ILogger<PaymentResponseFileProcessorCommandHandler> _logger;
	private readonly ICatalogRepository _catalogRepository;
	private readonly SomeApplication _someApplication;
	private readonly ISender _mediator;

	public SetResponsePaymentFileCommandHandler(
		ILogger<PaymentResponseFileProcessorCommandHandler> logger,
		ICatalogRepository catalogRepository,
		SomeApplication someApplication,
		ISender mediator)
	{
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
		_someApplication = someApplication;
		_mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
	}

	public async Task<ErrorOr<ClientMessageSuccess<ResponsePaymentFile>>> Handle(SetResponsePaymentFileCommand command, CancellationToken cancellationToken)
	{
		ClientMessageSuccess<ResponsePaymentFile> clientMessageSuccess = new();

        foreach (PaymentFileResponseUnified paymentFileResponseUnified in command.PaymentsFilesResponsesUnifieds)
		{
			//Level Payment Order:
			string fileName = paymentFileResponseUnified.FileName;

			if (paymentFileResponseUnified.NotFound) {

				string message = $"No se encontr� archivo {fileName}, no se puede actualizar el estado a LEIDO.";
				_logger.LogInformation(message);
				clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "ERROR", message));
				continue;
			}
		
			//Step 1: Update Payment File Response
			var updateStatusPaymentFileCommandResult = await _mediator.Send(new SetStatusPaymentFileCommand(fileName, Constants.PaymentFileStatus.READ, command.PaymentSetting.Codigo, paymentFileResponseUnified.FileType, command.UserAction), cancellationToken);
			if (updateStatusPaymentFileCommandResult.IsError)
			{
				_logger.LogError(updateStatusPaymentFileCommandResult.FirstError.Description);
				clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "ERROR", updateStatusPaymentFileCommandResult.FirstError.Description));
				continue;
			}

            if (paymentFileResponseUnified.IsRead && paymentFileResponseUnified.FileType == Constants.PaymentFileType.RESPONSE)
			{
				//Step 2: Go Level Payment Order Detail
				var paymentFileContentResponse = paymentFileResponseUnified.PaymentFileContentResponse;

				// Step 2.1: paymentFileResponseSuccess
				var updateStatusPaymentOrderDetailSuccessResult = await UpdateStatusPaymentOrderDetail(paymentFileResponseUnified, Constants.PaymentOrderDetailStatus.PAID, command.UserAction);

				if (updateStatusPaymentOrderDetailSuccessResult.IsError)
				{
					_logger.LogError(updateStatusPaymentOrderDetailSuccessResult.FirstError.Description);
					clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "ERROR", updateStatusPaymentOrderDetailSuccessResult.FirstError.Description));
					continue;
				}

				// Step 2.2: Failures
				var updateStatusPaymentOrderDetailFailureResult = await UpdateStatusPaymentOrderDetail(paymentFileResponseUnified, Constants.PaymentOrderDetailStatus.ERROR, command.UserAction);

				if (updateStatusPaymentOrderDetailFailureResult.IsError)
				{
					_logger.LogError(updateStatusPaymentOrderDetailFailureResult.FirstError.Description);
					clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "ERROR", updateStatusPaymentOrderDetailFailureResult.FirstError.Description));
					continue;
				}

				// Step 2.3: Error
				var updateStatusPaymentOrderDetailErrorResult = await UpdateStatusErrorPaymentOrderDetail(paymentFileResponseUnified.PaymentFileContentResponse.ResponseErrors, command.UserAction);

				if (updateStatusPaymentOrderDetailErrorResult.IsError)
				{
					_logger.LogError(updateStatusPaymentOrderDetailErrorResult.FirstError.Description);
					clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "ERROR", updateStatusPaymentOrderDetailErrorResult.FirstError.Description));
					continue;
				}

				//Step 3: Update Status Payment Order
				Catalog? statusPaymentOrder = await _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_ORDER_STATUS, paymentFileContentResponse.StatusPaymentOrder);
				PaymentOrderStatus paymentOrderStatus = new(statusPaymentOrder!.Codigo, statusPaymentOrder!.Id, statusPaymentOrder.Nombre);

				var updatePaymentOrderCommandResult = await _mediator.Send(new UpdatePaymentOrderCommand(paymentFileResponseUnified.IdPaymentOrder, paymentFileResponseUnified.IdMassivePayment, paymentOrderStatus, command.UserAction), cancellationToken);

				if (updatePaymentOrderCommandResult.IsError)
				{
					_logger.LogError(updatePaymentOrderCommandResult.FirstError.Description);
					clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "ERROR", updatePaymentOrderCommandResult.FirstError.Description));
					continue;
				}

				_logger.LogInformation($"El archivo de respuesta {fileName} se actualiz� al estado LE�DO.");
				clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "SUCCESS"));
			}
			else
			{
				string messageAudit = $"El archivo de respuesta {fileName} solo se mover� al historico.";

				var commandAudit = new CreatePaymentAuditCommand(
					paymentFileResponseUnified.IdPaymentOrder,
					0,
					$"ARCHIVO PAGO RESPUESTA",
					messageAudit,
					command.UserAction,
					_someApplication.GetRequestHost(),
					Constants.NAMEAPP
					);

				var createPaymentAuditResult = await _mediator.Send(commandAudit, cancellationToken);

				if (createPaymentAuditResult.IsError)
				{
					string messageAuditError = "Auditoria: Error en registrar la auditoria para al actualizar un archivo pago.";
					_logger.LogError(messageAuditError);
					clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "ERROR", messageAuditError));
					continue;
				}

				_logger.LogInformation(messageAudit);
				clientMessageSuccess.Data.Add(new ResponsePaymentFile(fileName, paymentFileResponseUnified.FileType, "SUCCESS"));
			}
		}

		return clientMessageSuccess;
	}

	private async Task<ErrorOr<Unit>> UpdateStatusPaymentOrderDetail(PaymentFileResponseUnified paymentResponseFile, string status, string userAction)
	{
		List<PaymentFileSetResponse> paymentFileResponses = [];

		// Step 1.1: Get param paymentFileResponseSuccess
		switch (status)
		{
			case Constants.PaymentOrderDetailStatus.PAID:
				paymentFileResponses = paymentResponseFile.PaymentFileContentResponse.ResponseSuccesses;
				break;
			case Constants.PaymentOrderDetailStatus.ERROR:
				paymentFileResponses = paymentResponseFile.PaymentFileContentResponse.ResponseFailures;
				break;
		}

		if (paymentFileResponses.Count > 0)
		{
			var statusPaymentOrderDetail = await _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_ORDER_DETAIL_STATUS, status);
			PaymentOrderDetailStatus paymentOrderDetailStatus = new(statusPaymentOrderDetail!.Codigo, statusPaymentOrderDetail!.Id, statusPaymentOrderDetail.Nombre);

			// Step 1.2: Set param paymentFileResponse
			var updatePaymentOrderDetailCommand = await _mediator.Send(new UpdatePaymentOrderDetailCommand(paymentFileResponses, paymentOrderDetailStatus, userAction));

			if (updatePaymentOrderDetailCommand.IsError)
			{
				_logger.LogError(updatePaymentOrderDetailCommand.FirstError.Description);
				return updatePaymentOrderDetailCommand.FirstError;
			}
		}

		return Unit.Value;
	}
	private async Task<ErrorOr<Unit>> UpdateStatusErrorPaymentOrderDetail(List<PaymentFileSetResponse> paymentFileResponses, string userAction)
	{
		if (paymentFileResponses.Count > 0)
		{
			var statusPaymentOrderDetail = await _catalogRepository.GetIdByCode(Constants.CatalogType.PAYMENT_ORDER_DETAIL_STATUS, Constants.PaymentOrderDetailStatus.ERROR);
			PaymentOrderDetailStatus paymentOrderDetailStatus = new(statusPaymentOrderDetail!.Codigo, statusPaymentOrderDetail!.Id, statusPaymentOrderDetail.Nombre);

			// Step 1.2: Set param paymentFileResponse
			var updatePaymentOrderDetailCommand = await _mediator.Send(new UpdatePaymentOrderDetailCommand(paymentFileResponses, paymentOrderDetailStatus, userAction));

			if (updatePaymentOrderDetailCommand.IsError)
			{
				_logger.LogError(updatePaymentOrderDetailCommand.FirstError.Description);
				return updatePaymentOrderDetailCommand.FirstError;
			}
		}

		return Unit.Value;
	}
}
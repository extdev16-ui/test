using Domain.PaymentsFiles.Models;
using Domain.PaymentsSettings;
using ErrorOr;
using MediatR;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Application.PaymentsFiles.Update;

public record UpdatePaymentFileCommand(
    PaymentFile PaymentFile,
	PaymentSetting PaymentSetting,
	string FileName,
	string Status,
	string Type,
	string UserAction
) : IRequest<ErrorOr<PaymentFile>>;
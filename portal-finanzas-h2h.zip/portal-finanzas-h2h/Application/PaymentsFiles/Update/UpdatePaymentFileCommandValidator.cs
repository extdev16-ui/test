using Application.PaymentsFiles.Update;
using FluentValidation;

namespace Application.PaymentsFiles.Update;

public class UpdatePaymentFileCommandValidator : AbstractValidator<UpdatePaymentFileCommand>
{
    public UpdatePaymentFileCommandValidator()
    {
        RuleFor(r => r.PaymentFile).NotNull()
             .WithName("Archivo Pago");
    }
}
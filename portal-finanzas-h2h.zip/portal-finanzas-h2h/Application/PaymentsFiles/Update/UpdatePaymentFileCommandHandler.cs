using Application.PaymentsAudits.Create;
using Application.PaymentsFiles.Interfaces;
using Application.PaymentsFiles.Request;
using Application.PaymentsFiles.Send;
using Application.Services;
using Domain.Catalogs;
using Domain.PaymentsFiles.Interfaces;
using Domain.PaymentsFiles.Models;
using Domain.Primitives;
using Domain.ValueObjects;
using Domain.ValueObjects.PaymentsFiles;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using static Domain.Common.Constants;

namespace Application.PaymentsFiles.Update;

internal sealed class UpdatePaymentFileCommandHandler : IRequestHandler<UpdatePaymentFileCommand, ErrorOr<PaymentFile>>
{
    private readonly IPaymentFileWriteRepository _paymentFileRepository;
	private readonly ICatalogRepository _catalogRepository;
	private readonly IPaymentFileSFTP _paymentFileService;
	private readonly IUnitOfWork _unitOfWork;
    private readonly SomeApplication _someApplication;
	private readonly ILogger<UpdatePaymentFileCommandHandler> _logger;
	private readonly ISender _mediator;

    public UpdatePaymentFileCommandHandler(
        IPaymentFileWriteRepository paymentFileRepository,
		ICatalogRepository catalogRepository,
		IPaymentFileSFTP paymentFileService,
		IUnitOfWork unitOfWork,
        SomeApplication someApplication,
		ILogger<UpdatePaymentFileCommandHandler> logger,
		ISender mediator)
    {
        _paymentFileRepository = paymentFileRepository ?? throw new ArgumentNullException(nameof(paymentFileRepository));
		_catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
		_unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
		_paymentFileService = paymentFileService ?? throw new ArgumentNullException(nameof(paymentFileService));

		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_someApplication = someApplication;
        _mediator = mediator;
    }

    public async Task<ErrorOr<PaymentFile>> Handle(UpdatePaymentFileCommand command, CancellationToken cancellationToken)
    {
		PaymentFile paymentFile = command.PaymentFile;
		List<PaymentFileSetting> paymentSettingDetail = command.PaymentSetting.DetalleConfiguraciones!;

		var statusCatalog = await _catalogRepository.GetIdByCode(CatalogType.PAYMENT_FILE_STATUS, command.Status);
		var typeCatalog = await _catalogRepository.GetIdByCode(CatalogType.PAYMENT_FILE_TYPE, command.Type);

		paymentFile.RegistroAuditoria.UsuarioActualizador = command.UserAction;
		
		paymentFile.IdCatalogoEstado = statusCatalog!.Id;
		paymentFile.CatalogoEstado = statusCatalog;
		paymentFile.IdCatalogoTipo = typeCatalog!.Id;
		paymentFile.CatalogoTipo = typeCatalog;

		//Step 4: Validated file and Send PaymentFile by Status
		switch (command.Status)
		{
			case PaymentFileStatus.UPLOADED:
				{
					string rutaFTPEnvio = paymentSettingDetail.Find(c => c.Nombre == "rutaFTPEnvio")?.Valor!;

					if (string.IsNullOrEmpty(rutaFTPEnvio))
					{
						_logger.LogError("No se encontró la ruta ftp de envió");
						return Error.Validation("Archivo Pago", "No se encontró la ruta ftp de envió.");
					}

					//Step 3: Verified file in directory sftp
					var byteFile = await _paymentFileService.GetFileToFtps(new FileToFtpsRequest(paymentFile.RutaEnvioHistorico,HISTORICAL_SFTP, command.PaymentSetting.Codigo));

					if (byteFile is null)
					{
						_logger.LogError($"No se encontró el archivo {paymentFile.Nombre} en la ruta sftp de envío.");
						return Error.Validation("Archivo Pago", $"No se encontró el archivo {paymentFile.Nombre} en la ruta sftp de envío.");
					}

					_logger.LogInformation("Validación de archivo existosa de archivo de pago.");

					paymentFile.RutaEnvio = $"{rutaFTPEnvio}{paymentFile.Nombre}";
					//var typeFileSend = await _catalogRepository.GetIdByCode(CatalogType.PAYMENT_FILE_TYPE,PaymentFileType.SEND);
					//paymentFile.IdCatalogoTipo = typeFileSend!.Id;
					break;
				}
			case PaymentFileStatus.RECEIVED:
				{
					string rutaFTPRespuesta = paymentSettingDetail.Find(c => c.Nombre == "rutaFTPRespuesta")?.Valor!;

					if (string.IsNullOrEmpty(rutaFTPRespuesta))
					{
						_logger.LogError("No se encontró la ruta ftp de respuesta");
						return Error.Validation("Archivo Pago", "No se encontró la ruta ftp de respuesta.");
					}
					//Set fileName RECEIVED
					paymentFile.RutaRespuesta = string.Empty;
					string responseRoute = $"{rutaFTPRespuesta}{command.FileName}";

					var byteFile = await _paymentFileService.GetFileToFtps(new FileToFtpsRequest(responseRoute, TRANSACCTION_SFTP, command.PaymentSetting.Codigo));

					if (byteFile is null)
					{
						_logger.LogError($"No se encontró el archivo {command.FileName} en la ruta sftp de respuesta.");
						return Error.Validation("Archivo Pago", $"No se encontró el archivo {command.FileName} en la ruta sftp de respuesta.");
					}

					//var typeFileResponse = await _catalogRepository.GetIdByCode(CatalogType.PAYMENT_FILE_TYPE, PaymentFileType.RESPONSE);
					//paymentFile.IdCatalogoTipo = typeFileResponse!.Id;
					break;
				}
			case PaymentFileStatus.READ:
				{
					string rutaFTPHistoricoRespuesta = paymentSettingDetail.Find(c => c.Nombre == "rutaFTPHistoricoRespuesta")?.Valor!;
					if (string.IsNullOrEmpty(rutaFTPHistoricoRespuesta))
					{
						_logger.LogError("No se encontró la ruta ftp de respuesta historica");
						return Error.Validation("Archivo Pago", "No se encontró la ruta ftp de respuesta historica.");
					}
					//Set fileName READ
					paymentFile.RutaRespuestaHistorica = $"{rutaFTPHistoricoRespuesta}";

					//Get Path Historical Response
					paymentFile.RutaRespuestaHistorica = paymentFile.CreatePathHistoricalResponse(command.FileName);

					// Step 5: Send file to sftp IN
					_logger.LogInformation("Enviando el archivo de pago al directorio de historico respuesta.");
					var sendPaymentFile = await _mediator.Send(new SendPaymentFileCommand(paymentFile.RutaRespuesta, paymentFile.RutaRespuestaHistorica, DELETE_FILE, HISTORICAL_SFTP, command.PaymentSetting.Codigo), cancellationToken);

					if (sendPaymentFile.IsError)
					{
						_logger.LogError(sendPaymentFile.FirstError.Description);
						await _unitOfWork.RollbackTransactionAsync(cancellationToken);
						return sendPaymentFile.FirstError;
					}
					_logger.LogInformation("Envió de archivo de la cola de respuesta hacia el historico de respuesta.");
					break;
				}
		}

		//Update PaymentFile
		if (AuditRecord.Update(command.PaymentFile.RegistroAuditoria.UsuarioActualizador, _someApplication.GetRequestHost(), NAMEAPP, DateTime.Now) is not AuditRecord auditRecord)
            return Error.Validation("Auditoria", "Campos de Auditoria no tiene el formato correcto.");

        command.PaymentFile.RegistroAuditoria.UsuarioActualizador = auditRecord.UsuarioActualizador;
        command.PaymentFile.RegistroAuditoria.HostActualizador = _someApplication.GetRequestHost();
        command.PaymentFile.RegistroAuditoria.AppActualizador = NAMEAPP;
		command.PaymentFile.RegistroAuditoria.FechaActualizacion = DateTime.Now;

        _paymentFileRepository.Update(command.PaymentFile);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        var commandAudit = new CreatePaymentAuditCommand(
            command.PaymentFile.IdOrdenPago,
            0,
            $"ARCHIVO PAGO {statusCatalog.Nombre}",
            $"Se actualizó el estado de archivo pago de la orden de pago {command.PaymentFile.IdOrdenPago}",
            auditRecord.UsuarioActualizador,
            _someApplication.GetRequestHost(),
            NAMEAPP
            );

        var createPaymentAuditResult = await _mediator.Send(commandAudit, cancellationToken);

        if (createPaymentAuditResult.IsError)
            return Error.Failure("Auditoria", "Error en registrar la auditoria para al actualizar un archivo pago.");

        return command.PaymentFile;
    }
}

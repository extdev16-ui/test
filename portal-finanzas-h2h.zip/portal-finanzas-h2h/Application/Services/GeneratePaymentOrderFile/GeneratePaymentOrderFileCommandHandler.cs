using Application.Common.Logging;
using Application.Data;
using Application.Helpers;
using Application.PaymentsFiles.CreateSend;
using Application.PaymentsFiles.Generate;
using Application.PaymentsOrders.Create;
using Application.PaymentsOrdersDetails.Create;
using Domain.Primitives;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;

namespace Application.Services.GeneratePaymentOrderFile;

internal sealed class GeneratePaymentOrderFileCommandHandler : IRequestHandler<GeneratePaymentOrderFileCommand, ErrorOr<ClientMessageSuccess<object>>>
{
    private readonly IMassivePaymentReadRepository _massivePaymentRepository;
    private readonly ILogger<GeneratePaymentOrderFileCommandHandler> _logger;
    private readonly ISender _mediator;
    private readonly IUnitOfWork _unitOfWork;

    public GeneratePaymentOrderFileCommandHandler(IMassivePaymentReadRepository massivePaymentRepository,
                                                ILogger<GeneratePaymentOrderFileCommandHandler> logger,
                                                ISender mediator,
                                                IUnitOfWork unitOfWork
                                                )
    {
        _massivePaymentRepository = massivePaymentRepository ?? throw new ArgumentNullException(nameof(massivePaymentRepository));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
    }

    public async Task<ErrorOr<ClientMessageSuccess<object>>> Handle(GeneratePaymentOrderFileCommand command, CancellationToken cancellationToken)
    {
        ClientMessageSuccess<object> clientMessage = new();

        // Iniciar la transacci�n
        await _unitOfWork.BeginTransactionAsync(cancellationToken);
        try
        {
            using (LogContext.PushProperty("Identifier", string.Concat("Id Referencia Pago: " + command.IdMassivePayment)))
            {
                _logger.LogInformation("Inicio del proceso de generaci�n y envi� de archivo.");

                //Step 0: Get Massive Payment
                _logger.LogInformation("Validar los datos de pagos masivos.");
                var massivesPaymentsResponses = await _massivePaymentRepository.GetById(command.IdMassivePayment);

                if (massivesPaymentsResponses is null || !massivesPaymentsResponses.Any())
                    return Error.Validation("Pago Masivo", "No se encontr� el pago masivo.");

                var massivePaymentResponse = massivesPaymentsResponses.FirstOrDefault()!;

                massivePaymentResponse.Detalle = await _massivePaymentRepository.GetDetailByIdMassivePayment(command.IdMassivePayment);
                if (massivePaymentResponse.Detalle.Count == 0)
                    return Error.Validation("Pago Masivo Detalle", "No se encontr� el pago masivo detalle.");


                // Step 1: General Validations
                _logger.LogInformation("Validando datos de pagos, configuraciones y duplicidad.");
                var validateGeneratePaymentFile = await _mediator.Send(new ValidateGeneratePaymentFileCommand(massivePaymentResponse));

                if (validateGeneratePaymentFile.IsError)
                {
                    _logger.LogError(validateGeneratePaymentFile.FirstError.Description);
                    return validateGeneratePaymentFile.FirstError;
                }

                var paymentSetting = validateGeneratePaymentFile.Value.paymentSetting!;

                _logger.LogInformation("Validaci�n existosa de datos de pagos, configuraciones y duplicidad.");
                
                // Step 2: Insert Payment Order
                _logger.LogInformation("Insertando Orden Pago en base de datos.");
                var responseCreatePaymentOrder = await _mediator.Send(new CreatePaymentOrderCommand(massivePaymentResponse, paymentSetting, command.UserCreated), cancellationToken);
                if (responseCreatePaymentOrder.IsError)
                {
                    _logger.LogError(responseCreatePaymentOrder.FirstError.Description);
                    await _unitOfWork.RollbackTransactionAsync(cancellationToken);
                    return responseCreatePaymentOrder.FirstError;
                }

                var paymentOrder = responseCreatePaymentOrder.Value;

                //Step 3: Insert Payment Order Detail
                _logger.LogInformation("Insertando Orden Pago Detalle en base de datos.");
                var responseCreatePaymentOrderDetail = await _mediator.Send(new CreatePaymentOrderDetailCommand(paymentOrder, massivePaymentResponse.Detalle, command.UserCreated));
                if (responseCreatePaymentOrderDetail.IsError)
                {
                    _logger.LogError(responseCreatePaymentOrderDetail.FirstError.Description);
                    await _unitOfWork.RollbackTransactionAsync(cancellationToken);
                    return responseCreatePaymentOrderDetail.FirstError;
                }

                //Step 4: Insert PaymentFile
                _logger.LogInformation("Insertando de Archivo Pago en base de datos.");
                var responseCreatePaymentFileCommand = await _mediator.Send(new CreatePaymentSendFileCommand(paymentSetting, paymentOrder, command.UserCreated));
                if (responseCreatePaymentFileCommand.IsError)
                {
                    _logger.LogError(responseCreatePaymentFileCommand.FirstError.Description);
                    await _unitOfWork.RollbackTransactionAsync(cancellationToken);
                    return responseCreatePaymentFileCommand.FirstError;
                }
                var paymentFile = responseCreatePaymentFileCommand.Value;

                // Step 5: Generate file and upload to ftp historical
                _logger.LogInformation("Generando archivo de pago.");
                var generatePaymentFile = await _mediator.Send(new GeneratePaymentFileCommand(massivePaymentResponse, paymentSetting, paymentFile.Nombre,paymentFile.Fecha, paymentOrder));

                if (generatePaymentFile.IsError)
                {
                    _logger.LogError(generatePaymentFile.FirstError.Description);
                    await _unitOfWork.RollbackTransactionAsync(cancellationToken);
                    return generatePaymentFile.FirstError;
                }
                _logger.LogInformation("Generaci�n y subida existosa de archivo de pago.");


                // Confirmar la transacci�n
                await _unitOfWork.CommitTransactionAsync(cancellationToken);
                _logger.LogInformation("Inserci�n de registros exitosa de Orden Pago en base de datos.");

                clientMessage.Data.Add(paymentOrder.Id);
                _logger.LogInformation("Fin del proceso de generaci�n y envi� de archivo.");

                return clientMessage;
            }
        }
        catch (Exception ex)
		{
			_logger.LogException(ex);
			await _unitOfWork.RollbackTransactionAsync(cancellationToken);
            return Error.Failure("Error Interno", ex.Message!);
        }
    }
}
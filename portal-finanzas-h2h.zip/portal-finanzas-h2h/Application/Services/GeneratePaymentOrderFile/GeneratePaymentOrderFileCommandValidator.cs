using FluentValidation;

namespace Application.Services.GeneratePaymentOrderFile;

public class GeneratePaymentOrderFileCommandValidator : AbstractValidator<GeneratePaymentOrderFileCommand>
{
    public GeneratePaymentOrderFileCommandValidator()
    {
        RuleFor(r => r.IdMassivePayment).NotEqual(0)
             .WithName("Pago Masivo");
        RuleFor(r => r.UserCreated).NotEmpty().NotNull()
             .WithName("Usuario Creador");
    }
}
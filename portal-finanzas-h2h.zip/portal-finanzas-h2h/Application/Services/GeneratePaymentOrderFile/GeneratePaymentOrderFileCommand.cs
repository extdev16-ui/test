using Application.Helpers;
using ErrorOr;
using MediatR;

namespace Application.Services.GeneratePaymentOrderFile;

public record GeneratePaymentOrderFileCommand(
    int IdMassivePayment,
    string UserCreated
) : IRequest<ErrorOr<ClientMessageSuccess<object>>>;
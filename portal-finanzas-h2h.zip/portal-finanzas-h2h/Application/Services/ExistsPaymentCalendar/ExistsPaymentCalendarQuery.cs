﻿using ErrorOr;
using MediatR;
namespace Application.Services.ExistsPaymentCalendar;

public record ExistsPaymentCalendarQuery(string Code, string Date) : IRequest<ErrorOr<bool>>;
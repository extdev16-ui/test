using Application.PaymentsCalendar.GetByDate;
using Application.PaymentsOrdersDetails.Create;
using Domain.PaymentsCalendar.Interfaces;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;

namespace Application.Services.ExistsPaymentCalendar;

internal sealed class ExistsPaymentCalendarQueryHandler : IRequestHandler<ExistsPaymentCalendarQuery, ErrorOr<bool>>
{
	private readonly IPaymentCalendarRepository _paymentCalendarRepository;
	private readonly ISender _mediator;
	private readonly ILogger<ExistsPaymentCalendarQueryHandler> _logger;

	public ExistsPaymentCalendarQueryHandler(
		IPaymentCalendarRepository paymentCalendarRepository,
		ISender mediator,
		ILogger<ExistsPaymentCalendarQueryHandler> logger)
	{
		_paymentCalendarRepository = paymentCalendarRepository;
		_mediator = mediator;
		_logger = logger;
	}

	public async Task<ErrorOr<bool>> Handle(ExistsPaymentCalendarQuery query, CancellationToken cancellationToken)
	{
		using (LogContext.PushProperty("Identifier", string.Concat("Calendario Pago: ", query.Code, "Fecha: ", query.Date)))
		{
			string type = Domain.Common.Constants.CatalogPaymentCalendarType.IDLE;
			var getPaymentCalendarByDateQuery = await _mediator.Send(new GetPaymentCalendarByDateQuery(query.Code, query.Date, type), cancellationToken);
			if (getPaymentCalendarByDateQuery.IsError)
			{
				_logger.LogError(getPaymentCalendarByDateQuery.FirstError.Description);
				return false;
			}
			
			if (getPaymentCalendarByDateQuery.Value is null)
			{
				_logger.LogInformation($"No se encontr� fecha de calendario para la configuracio de pago {query.Code}");
				return false;
			}

			return true;
		}
	}
}
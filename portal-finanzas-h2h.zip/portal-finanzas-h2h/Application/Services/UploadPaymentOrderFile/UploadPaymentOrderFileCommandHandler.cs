﻿using Application.Helpers;
using Application.PaymentsFiles.GetByMassivePayment;
using Application.PaymentsFiles.Send;
using Application.PaymentsFiles.Interfaces;
using Application.PaymentsFiles.Update;
using Application.PaymentsOrders.Update;
using Application.PaymentsSettings.GetById;
using Domain.Catalogs;
using Domain.Primitives;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using Application.Services.ExistsPaymentCalendar;
using Application.Common.Logging;
using Domain.PaymentsFiles.Models;

namespace Application.Services.UploadPaymentOrderFile;

internal sealed class UploadPaymentOrderFileCommandHandler : IRequestHandler<UploadPaymentOrderFileCommand, ErrorOr<ClientMessageSuccess<object>>>
{
    private readonly ICatalogRepository _catalogRepository;
    private readonly IPaymentFileSFTP _paymentFileService;
    private readonly ILogger<UploadPaymentOrderFileCommandHandler> _logger;
    private readonly ISender _mediator;
    private readonly IUnitOfWork _unitOfWork;

    public UploadPaymentOrderFileCommandHandler(ICatalogRepository catalogRepository,
                                                IPaymentFileSFTP paymentFileService,
                                                ILogger<UploadPaymentOrderFileCommandHandler> logger,
                                                ISender mediator,
                                                IUnitOfWork unitOfWork
                                                )
    {
        _paymentFileService = paymentFileService ?? throw new ArgumentNullException(nameof(paymentFileService));
        _catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
    }

    public async Task<ErrorOr<ClientMessageSuccess<object>>> Handle(UploadPaymentOrderFileCommand command, CancellationToken cancellationToken)
    {
        ClientMessageSuccess<object> clientMessage = new();

        await _unitOfWork.BeginTransactionAsync(cancellationToken);

        try
        {
            using (LogContext.PushProperty("Identifier", string.Concat("Id Referencia Pago: ", command.IdMassivePayment)))
            {
                _logger.LogInformation("Inicio del proceso de envió a cola de sftp.");
                //Step 1: Get payment file
                var getPaymentFileByMassivePayment = await _mediator.Send(new GetPaymentFileByMassivePaymentQuery(command.IdMassivePayment, Domain.Common.Constants.PaymentFileType.SEND), cancellationToken);

                if (getPaymentFileByMassivePayment.IsError)
                {
                    _logger.LogError(getPaymentFileByMassivePayment.FirstError.Description);
                    return getPaymentFileByMassivePayment.FirstError;
                }

                PaymentFile paymentFile = getPaymentFileByMassivePayment.Value!;

                if (!paymentFile.CanUpdateState(Domain.Common.Constants.PaymentFileStatus.UPLOADED, out string? errorMessage))
                {
                    _logger.LogError(errorMessage!);
                    return Error.Validation("Archivo Pago", errorMessage!);
                }

                //Step 2: Get Payments Settings
                var getPaymentSetting = await _mediator.Send(new GetPaymentSettingByIdQuery(paymentFile.IdConfiguracionPago));

                if (getPaymentSetting.IsError)
                {
                    _logger.LogError(getPaymentSetting.FirstError.Description);
                    return getPaymentSetting.FirstError;
                }

                var paymentSetting = getPaymentSetting.Value;

				//Step 3: Exist Payment Calendar
				var existsPaymentCalendarQuery = await _mediator.Send(new ExistsPaymentCalendarQuery(paymentSetting.Codigo, DateTime.Now.ToString("yyyy-MM-dd")), cancellationToken);

				if (existsPaymentCalendarQuery.IsError)
				{
					_logger.LogError(existsPaymentCalendarQuery.FirstError.Description);
					return existsPaymentCalendarQuery.FirstError;
				}

                if (existsPaymentCalendarQuery.Value)
                {
                    string message = "No se puede enviar el archivo ya que hoy esta inactivo el servicio H2H";
					_logger.LogError(message);
                    return Error.Validation("Archivo_Enviado", message);
				}

				//Step 4: Update Status PaymentFile
				var updatePaymentFileCommand = await _mediator.Send(new UpdatePaymentFileCommand(paymentFile,
																					 paymentSetting,
																					 paymentFile.Nombre,
																					 Domain.Common.Constants.PaymentFileStatus.UPLOADED,
																					 Domain.Common.Constants.PaymentFileType.SEND,
																					 command.UserCreated), cancellationToken);
                if (updatePaymentFileCommand.IsError)
                {
                    _logger.LogError(updatePaymentFileCommand.FirstError.Description);
                    await _unitOfWork.RollbackTransactionAsync(cancellationToken);
                    return updatePaymentFileCommand.FirstError;
                }

                //Step 5: Update Status PaymentOrder
                _logger.LogInformation("Actualizar estado de confirmado en Orden Pago en base de datos.");
                var statusPaymentOrder = await _catalogRepository.GetIdByCode(Domain.Common.Constants.CatalogType.PAYMENT_ORDER_STATUS, Domain.Common.Constants.PaymentOrderStatus.CONFIRMED);
                PaymentOrderStatus paymentOrderStatus = new(statusPaymentOrder!.Codigo, statusPaymentOrder!.Id, statusPaymentOrder.Nombre);

                var responseUpdatePaymentOrderCommand = await _mediator.Send(new UpdatePaymentOrderCommand(paymentFile.IdOrdenPago, command.IdMassivePayment, paymentOrderStatus, command.UserCreated));
                if (responseUpdatePaymentOrderCommand.IsError)
                {
                    _logger.LogError(responseUpdatePaymentOrderCommand.FirstError.Description);
                    await _unitOfWork.RollbackTransactionAsync(cancellationToken);
                    return responseUpdatePaymentOrderCommand.FirstError;
                }

                // Step 6: Send file to sftp IN
                _logger.LogInformation("Enviando el archivo de pago a la cola.");
                var sendPaymentFile = await _mediator.Send(new SendPaymentFileCommand(paymentFile.RutaEnvioHistorico, paymentFile.RutaEnvio, Domain.Common.Constants.NOT_DELETE_FILE, Domain.Common.Constants.TRANSACCTION_SFTP, paymentSetting.Codigo));

                if (sendPaymentFile.IsError)
                {
                    _logger.LogError(sendPaymentFile.FirstError.Description);
                    await _unitOfWork.RollbackTransactionAsync(cancellationToken);
                    return sendPaymentFile.FirstError;
                }

                _logger.LogInformation("Envío existoso de archivo de pago.");

                // Confirmar la transacción
                await _unitOfWork.CommitTransactionAsync(cancellationToken);
                _logger.LogInformation("Actualización de registros existosa de Orden Pago en base de datos.");


                clientMessage.Data.Add(paymentFile.Id);

                _logger.LogInformation("Fin del proceso de envío de archivo.");

                return clientMessage;
            }
        }
        catch (Exception ex)
        {
            _logger.LogException(ex);
            await _unitOfWork.RollbackTransactionAsync(cancellationToken);
            return Error.Failure("Error Interno", ex.Message!);
        }
    }
}
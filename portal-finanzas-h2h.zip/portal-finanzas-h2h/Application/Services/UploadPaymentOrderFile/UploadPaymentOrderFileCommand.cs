using Application.Helpers;
using ErrorOr;
using MediatR;

namespace Application.Services.UploadPaymentOrderFile;

public record UploadPaymentOrderFileCommand(
    int IdMassivePayment,
    string UserCreated
) : IRequest<ErrorOr<ClientMessageSuccess<object>>>;
using FluentValidation;

namespace Application.Services.UploadPaymentOrderFile;

public class UploadPaymentOrderFileCommandValidator : AbstractValidator<UploadPaymentOrderFileCommand>
{
    public UploadPaymentOrderFileCommandValidator()
    {
        RuleFor(r => r.IdMassivePayment).NotEqual(0)
             .WithName("Pago Masivo");
        RuleFor(r => r.UserCreated).NotEmpty().NotNull()
             .WithName("Usuario Creador");
    }
}
using Application.PaymentsCalendar.GetByDate;
using Application.PaymentsCalendar.GetByPaymentSetting;
using Application.PaymentsOrdersDetails.Create;
using Domain.PaymentsCalendar.Interfaces;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using Domain.PaymentsCalendar;
using Domain.Common;
using Domain.PaymentsCalendar.Common;

namespace Application.Services.GetDateByPaymentCalendar;

internal sealed class GetDateByPaymentCalendarQueryHandler : IRequestHandler<GetDateByPaymentCalendarQuery, ErrorOr<DateTime>>
{
	private readonly IPaymentCalendarRepository _paymentCalendarRepository;
	private readonly ISender _mediator;
	private readonly ILogger<GetDateByPaymentCalendarQueryHandler> _logger;

	public GetDateByPaymentCalendarQueryHandler(
		IPaymentCalendarRepository paymentCalendarRepository,
		ISender mediator,
		ILogger<GetDateByPaymentCalendarQueryHandler> logger)
	{
		_paymentCalendarRepository = paymentCalendarRepository;
		_mediator = mediator;
		_logger = logger;
	}

	public async Task<ErrorOr<DateTime>> Handle(GetDateByPaymentCalendarQuery query, CancellationToken cancellationToken)
	{
		using (LogContext.PushProperty("Identifier", string.Concat("Calendario Pago: ", query.PaymentSettingCode, "Fecha: ", query.InitialDate)))
		{
			string[] paymentSetting = Constants.ValidationDayCalendar.PaymentConfiguration; 

			if (!DateTime.TryParse(query.InitialDate, out var date))
			{
				return Error.Failure("Calendario Pago", $"Error en convertir la fecha  {query.InitialDate}.");
			}

			var getPaymentCalendarByPaymentSettingQuery = await _mediator.Send(new GetPaymentCalendarByPaymentSettingQuery(query.PaymentSettingCode), cancellationToken);
			if (getPaymentCalendarByPaymentSettingQuery.IsError)
			{
				string message = getPaymentCalendarByPaymentSettingQuery.FirstError.Description;
				_logger.LogError(message);
				return Error.Failure("Fecha Calendario Pago", message);
			}

			List<PaymentCalendar>? paymentsCalendar = getPaymentCalendarByPaymentSettingQuery.Value;

			if (paymentsCalendar is null || paymentsCalendar.Count == 0)
			{
				string message = "No se encontr� los registros de calendarios de pago";
				_logger.LogWarning(message);
				paymentsCalendar = [];
			}

			//Set only Date
			var paymentCalendarDate = Helper.SearchDayActive(query.InitialDate, paymentsCalendar);
			return paymentCalendarDate;
		}
	}
}
﻿using ErrorOr;
using MediatR;
namespace Application.Services.GetDateByPaymentCalendar;

public record GetDateByPaymentCalendarQuery(string InitialDate, string PaymentSettingCode) : IRequest<ErrorOr<DateTime>>;
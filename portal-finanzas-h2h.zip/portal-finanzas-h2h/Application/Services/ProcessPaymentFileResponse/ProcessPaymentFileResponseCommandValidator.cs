using FluentValidation;

namespace Application.Services.InsertPaymentFileResponse;

public class ProcessPaymentFileResponseCommandValidator : AbstractValidator<ProcessPaymentFileResponseCommand>
{
    public ProcessPaymentFileResponseCommandValidator()
    {
        RuleFor(r => r.FileName).NotEmpty()
             .WithName("Nombre de archivo");
        RuleFor(r => r.CodePaymentSetting).NotEmpty()
             .WithName("Configuraci�n pago");
        RuleFor(r => r.UserAction).NotEmpty()
             .WithName("Usuario Acci�n");
    }
}
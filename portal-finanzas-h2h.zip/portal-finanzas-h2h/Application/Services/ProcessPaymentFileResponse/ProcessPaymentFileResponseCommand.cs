using Application.Helpers;
using ErrorOr;
using MediatR;

namespace Application.Services.InsertPaymentFileResponse;

public record ProcessPaymentFileResponseCommand : IRequest<ErrorOr<ClientMessageSuccess<object>>>
{
    public string FileName { get; set; }
	public string? Status { get; set; }
	public string CodePaymentSetting { get; set; }
    public string UserAction { get; set; }

    public ProcessPaymentFileResponseCommand(string fileName, string status, string codePaymentSetting, string userAction)
    {
        FileName = fileName;
        Status = status;
        CodePaymentSetting = codePaymentSetting;
        UserAction = userAction;
	}
};
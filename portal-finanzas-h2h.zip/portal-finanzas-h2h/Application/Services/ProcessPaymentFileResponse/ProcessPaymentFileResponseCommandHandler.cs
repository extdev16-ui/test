﻿using Application.Helpers;
using Application.PaymentsFiles.GetByNames;
using Application.PaymentsFiles.Interfaces;
using Application.PaymentsSettings.GetByCode;
using Domain.Primitives;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using Domain.PaymentsSettings;
using Domain.PaymentsFiles.Helpers;
using Application.PaymentsFiles.CreateResponse;
using Application.PaymentsFiles.GetByPaymentOrder;
using Application.PaymentsFiles.Request;
using Application.Common.Logging;
using Domain.PaymentsFiles.Models;
using Domain.PaymentsFiles.Adapter;
using static Domain.Common.Constants;
using NPOI.HSSF.Model;
using System.Reflection.Metadata;

namespace Application.Services.InsertPaymentFileResponse;

internal sealed class ProcessPaymentFileResponseCommandHandler : IRequestHandler<ProcessPaymentFileResponseCommand, ErrorOr<ClientMessageSuccess<object>>>
{
	private readonly IPaymentFileAdapter _paymentFileAdapter;
	private readonly IPaymentFileSFTP _paymentFileService;
	private readonly ILogger<ProcessPaymentFileResponseCommandHandler> _logger;
	private readonly ISender _mediator;
	private readonly IUnitOfWork _unitOfWork;

	public ProcessPaymentFileResponseCommandHandler(IPaymentFileAdapter paymentFileAdapter,
												IPaymentFileSFTP paymentFileService,
												ILogger<ProcessPaymentFileResponseCommandHandler> logger,
												ISender mediator,
												IUnitOfWork unitOfWork
												)
	{
		_paymentFileAdapter = paymentFileAdapter ?? throw new ArgumentNullException(nameof(paymentFileAdapter));
		_paymentFileService = paymentFileService ?? throw new ArgumentNullException(nameof(paymentFileService));
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
		_unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
	}

	public async Task<ErrorOr<ClientMessageSuccess<object>>> Handle(ProcessPaymentFileResponseCommand command, CancellationToken cancellationToken)
	{
		ClientMessageSuccess<object> clientMessage = new();

		await _unitOfWork.BeginTransactionAsync(cancellationToken);

		try
		{
			_logger.LogInformation("Inicio del proceso de registrar archivo de respuesta.");
			using (LogContext.PushProperty("Identifier", string.Concat("Nombre de archivo: ", command.FileName)))
			{
				//Step 1: Get payment setting by code
				var getPaymentSettingByCodeQuery = await _mediator.Send(new GetPaymentSettingByCodeQuery(command.CodePaymentSetting), cancellationToken);

				if (getPaymentSettingByCodeQuery.IsError)
				{
					_logger.LogError(getPaymentSettingByCodeQuery.FirstError.Description);
					return getPaymentSettingByCodeQuery.FirstError;
				}

				PaymentSetting paymentSetting = getPaymentSettingByCodeQuery.Value;

				//Step 2: Validate if exists file in SFTP
				string? contentFile = await ExistsFileResponse(command.FileName, paymentSetting);

				if (string.IsNullOrEmpty(contentFile))
				{
					return Error.Failure("Archivo Pago Respuesta", $"No se encontró el archivo {command.FileName} en la ruta sftp de respuesta.");
				}

				string typeFile = string.Empty;
				string fileNameGetPaymentsFiles = PaymentFileHelper.SetFileNameByPaymentSettingCode(paymentSetting.Codigo, command.FileName, command.Status!, out typeFile);

				//Step 3: Get payment file origin by name
				var getPaymentFileByNames = await _mediator.Send(new GetPaymentFileByNamesQuery(fileNameGetPaymentsFiles), cancellationToken);

				if (getPaymentFileByNames.IsError)
				{
					_logger.LogError(getPaymentFileByNames.FirstError.Description);
					return getPaymentFileByNames.FirstError;
				}

				//Step 4: Get Payment File Send
				PaymentFile? paymentFileOrigin = getPaymentFileByNames.Value.Where(c => c.CatalogoTipo.Codigo == PaymentFileType.SEND).FirstOrDefault();

				if (paymentFileOrigin is null)
				{
					_logger.LogError("No se encontró la ruta SFTP de envió");
					return Error.Validation("Archivo Pago", "No se encontró la ruta SFTP de envió.");
				}

				//Step 5: Get payment file by name
				var getPaymentFileByPaymentOrder = await _mediator.Send(new GetPaymentFileByPaymentOrderQuery(paymentFileOrigin.IdOrdenPago, PaymentFileType.RESPONSE), cancellationToken);

				if (getPaymentFileByNames.IsError)
				{
					_logger.LogError(getPaymentFileByNames.FirstError.Description);
					return getPaymentFileByNames.FirstError;
				}

				//Step 6: Get Payments Files Responses
				List<PaymentFile> paymentFilesResponse = getPaymentFileByPaymentOrder.Value ?? [];

				if (paymentFilesResponse.Exists(c => c.Nombre.Equals(command.FileName)))
				{
					string messageExistResponse = $"Ya se tiene registrado el archivo de respuesta {command.FileName}.";
					_logger.LogError(messageExistResponse);
					return Error.Validation("Archivo Pago Respuesta", messageExistResponse);
				}

				//Step 7: ValidateResponseLimitsByPaymentSetting
				if (!PaymentFileHelper.ValidateResponseLimitsByPaymentSetting(paymentSetting, paymentFilesResponse.Count, typeFile, out string? messageValidateLimit))
				{
					_logger.LogError(messageValidateLimit);
					return Error.Validation("Archivo Pago Respuesta", messageValidateLimit);
				}

				//Step 7.5: GetResponseFileOrder
				int fileOrder = GetResponseFileOrder(command.FileName, contentFile, paymentSetting, typeFile, paymentFilesResponse);
				_logger.LogInformation($"El orden del archivo de respuesta {command.FileName} es el {fileOrder.ToString()}.");

				//Step 8: Insert Payment Response File
				_logger.LogInformation("Insertando de Archivo Pago de Respuesta en base de datos.");
				var createPaymentResponseFileCommand = await _mediator.Send(new CreatePaymentResponseFileCommand(paymentSetting,
					paymentFileOrigin.IdOrdenPago,
					command.FileName,
					typeFile,
					fileOrder,
					command.UserAction
					), cancellationToken);

				if (createPaymentResponseFileCommand.IsError)
				{
					_logger.LogError(createPaymentResponseFileCommand.FirstError.Description);
					await _unitOfWork.RollbackTransactionAsync(cancellationToken);
					return createPaymentResponseFileCommand.FirstError;
				}

				var paymentFileResponse = createPaymentResponseFileCommand.Value;

				// Confirmar la transacción
				await _unitOfWork.CommitTransactionAsync(cancellationToken);
				_logger.LogInformation($"Actualización de estado a {paymentFileOrigin.CatalogoEstado.Nombre} de registros exitosa de Orden Pago en base de datos.");

				clientMessage.Data.Add(paymentFileOrigin.Id);

				_logger.LogInformation("Fin del proceso de envío de archivo.");

				return clientMessage;
			}
		}
		catch (Exception ex)
		{
			using (LogContext.PushProperty("Identifier", string.Concat("Nombre de archivo: ", command.FileName)))
			{
				_logger.LogException(ex);
			}
			await _unitOfWork.RollbackTransactionAsync(cancellationToken);
			return Error.Failure("Error Interno", ex.Message!);
		}
	}

	private async Task<string?> ExistsFileResponse(string fileName, PaymentSetting paymentSetting)
	{
		string? contentFile = null;
		string rutaFTPRespuesta = paymentSetting.DetalleConfiguraciones!.Find(c => c.Nombre == "rutaFTPRespuesta")?.Valor!;

		if (string.IsNullOrEmpty(rutaFTPRespuesta))
		{
			_logger.LogError($"No se encontró la configuración de la ruta de envió");
			return contentFile;
		}

		string responseRoute = $"{rutaFTPRespuesta}{fileName}";

		contentFile = await _paymentFileService.GetContentToFtps(new FileToFtpsRequest(responseRoute, TRANSACCTION_SFTP, paymentSetting.Codigo));

		if (contentFile is null)
		{
			_logger.LogError($"No se encontró el archivo {fileName} en la ruta sftp de respuesta.");
			return contentFile;
		}

		return contentFile;
	}

	private int GetResponseFileOrder(string fileName, string contentFile, PaymentSetting paymentSetting, string typeFile, List<PaymentFile> paymentFilesResponse)
	{
		int fileOrder = 1;
		_logger.LogInformation("Iniciar proceso de obtener el order del archivo de respuesta.");
		if (typeFile != PaymentFileType.RESPONSE)
		{
			return fileOrder;
		}

		_logger.LogInformation("Obtener el orden del archivo de respuesta por banco, tipo y contenido del archivo.");
		switch (paymentSetting.Codigo)
		{
			case PaymentSettings.H2H_BBVA_PP:
				{
					PaymentFileXmlBBVA? paymentFileXmlBBVA = _paymentFileAdapter.AdaptStringToBBVAXml(contentFile);

					if (paymentFileXmlBBVA is null)
					{
						string message = $"No se pudo adaptar el contenido del archivo {fileName} a una clase.";
						_logger.LogError(message);
						throw new ArgumentNullException(nameof(message));
					}

					int nonGlobalResponsesCount = paymentFilesResponse.Where(c => c.Orden != TypePaymentFileResponseBBVA.GLOBAL).ToList().Count;

					if (StatusResponseGlobalBBVA.STATUS.Contains(paymentFileXmlBBVA.CstmrPmtStsRpt.OrgnlGrpInfAndSts.GrpSts) 
						&& paymentFileXmlBBVA.CstmrPmtStsRpt.OrgnlPmtInfAndSts is null)
					{
						return TypePaymentFileResponseBBVA.GLOBAL;
					}
					else
					{
						fileOrder = TypePaymentFileResponseBBVA.STRUCTURE;

						if (paymentFileXmlBBVA.CstmrPmtStsRpt.OrgnlGrpInfAndSts.GrpSts == StatusResponseStructureBBVA.SUCCESS_STRUCTURE)
						{
							return TypePaymentFileResponseBBVA.STRUCTURE;
						}

						if (paymentFileXmlBBVA.CstmrPmtStsRpt.OrgnlGrpInfAndSts.GrpSts == StatusResponseTransactionBBVA.PAYMENT_ACCEPTED)
						{
							return TypePaymentFileResponseBBVA.TRANSACTION;
						}

						return fileOrder + nonGlobalResponsesCount;
					}
				}
			case PaymentSettings.H2H_SCOTIABANK_PV:
				{
					return fileOrder;
				}
			default:
				{
					return fileOrder;
				}
		}
	}
}
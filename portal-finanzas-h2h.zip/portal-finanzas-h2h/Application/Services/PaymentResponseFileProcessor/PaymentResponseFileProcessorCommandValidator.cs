using FluentValidation;

namespace Application.Services.PaymentResponseFileProcessor;

public class PaymentResponseFileProcessorCommandValidator : AbstractValidator<PaymentResponseFileProcessorCommand>
{
    public PaymentResponseFileProcessorCommandValidator()
    {
        RuleFor(r => r.RemoteDirectory).NotEmpty()
             .WithName("Directorio Remoto");
    }
}
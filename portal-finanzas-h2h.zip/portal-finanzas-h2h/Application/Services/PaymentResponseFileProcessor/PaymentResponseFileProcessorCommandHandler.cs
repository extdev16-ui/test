﻿using Application.Helpers;
using Application.PaymentsSettings.GetByCode;
using Application.PaymentsFiles.Interfaces;
using Domain.Common;
using Domain.PaymentsSettings;
using Domain.Primitives;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using Application.PaymentsFiles.Request;
using Application.PaymentsFiles.GetResponse;
using Application.PaymentsFiles.SetResponse;
using Application.Common.Logging;
using Domain.PaymentsFiles.Models;
using Application.PaymentsFiles.SetResponseFileObservation;

namespace Application.Services.PaymentResponseFileProcessor;

internal sealed class PaymentResponseFileProcessorCommandHandler : IRequestHandler<PaymentResponseFileProcessorCommand, ErrorOr<ClientMessageSuccess<ResponsePaymentFile>>>
{
	private readonly IPaymentFileSFTP _paymentFileService;
	private readonly ILogger<PaymentResponseFileProcessorCommandHandler> _logger;
	private readonly ISender _mediator;
	private readonly IUnitOfWork _unitOfWork;

	public PaymentResponseFileProcessorCommandHandler(IPaymentFileSFTP paymentFileService,
		ILogger<PaymentResponseFileProcessorCommandHandler> logger,
												ISender mediator,
												IUnitOfWork unitOfWork
												)
	{
		_paymentFileService = paymentFileService ?? throw new ArgumentNullException(nameof(paymentFileService));
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
		_unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
	}

	public async Task<ErrorOr<ClientMessageSuccess<ResponsePaymentFile>>> Handle(PaymentResponseFileProcessorCommand command, CancellationToken cancellationToken)
	{
		await _unitOfWork.BeginTransactionAsync(cancellationToken);
		try
		{
			_logger.LogInformation("Inicio del proceso de lectura de archivos pagos de respuesta.");
			using (LogContext.PushProperty("Identifier", string.Concat("Directorio remoto: ", command.RemoteDirectory)))
			{
				//Step 1: Get Content to files
				_logger.LogInformation("Obtener los archivos de pago de la cola de respuestas.");
				List<PaymentFileResponse> fileResponsePaymentFiles = await _paymentFileService.GetFilesByRemoteDirectory(new FileToFtpsRequest(command.RemoteDirectory, Constants.TRANSACCTION_SFTP, command.CodePaymentSetting));

				if (fileResponsePaymentFiles.Count == 0)
				{
					_logger.LogError("No se encontró archivos.");
					return Error.Validation("Directorio Remoto", "No se encontró archivos..");
				}

				//Step 2: Get payment setting
				_logger.LogInformation("Obtener la configuración de pagos.");
				var getPaymentSettingByCodeQuery = await _mediator.Send(new GetPaymentSettingByCodeQuery(command.CodePaymentSetting), cancellationToken);

				if (getPaymentSettingByCodeQuery.IsError)
				{
					_logger.LogError(getPaymentSettingByCodeQuery.FirstError.Description);
					return getPaymentSettingByCodeQuery.FirstError;
				}

				PaymentSetting paymentSetting = getPaymentSettingByCodeQuery.Value;

				//Step 3: Get response file
				_logger.LogInformation("Obtener el contenido de los archivos de pagos.");
				var getResponseFile = await _mediator.Send(new GetResponsePaymentFileCommand(fileResponsePaymentFiles, paymentSetting), cancellationToken);

				if (getResponseFile.IsError)
				{
					_logger.LogError(getResponseFile.FirstError.Description);
					return getResponseFile.FirstError;
				}

				List<PaymentFileResponseUnified> responsesFiles = getResponseFile.Value;

				if (responsesFiles is null || responsesFiles.Count == 0)
				{
					_logger.LogError("Error interno, no se encontró información de respuesta.");
					return Error.Validation("Error Interno", "Error interno, no se encontró información de respuesta.");
				}

                

                //Step 4: Set payment file response
                _logger.LogInformation("Setear segun los valores del contenido de los archivos de pagos a las tablas.");
				var setResponseFile = await _mediator.Send(new SetResponsePaymentFileCommand(responsesFiles, paymentSetting, command.UserAction), cancellationToken);

				if (setResponseFile.IsError)
				{
					_logger.LogError(setResponseFile.FirstError.Description);
					await _unitOfWork.RollbackTransactionAsync(cancellationToken);
					return setResponseFile.FirstError;
				}

				// Confirmar la transacción
				await _unitOfWork.CommitTransactionAsync(cancellationToken);
				_logger.LogInformation("Fin del proceso de obtener archivos por directorio.");

				return setResponseFile.Value;
			}
		}
		catch (Exception ex)
		{
			using (LogContext.PushProperty("Identifier", string.Concat("Directorio remoto: ", command.RemoteDirectory)))
			{
				_logger.LogException(ex);
			}
			await _unitOfWork.RollbackTransactionAsync(cancellationToken);
			return Error.Failure("Error Interno", ex.Message!);
		}
	}
}
using Application.Helpers;
using ErrorOr;
using MediatR;

namespace Application.Services.PaymentResponseFileProcessor;

public record PaymentResponseFileProcessorCommand(
    string RemoteDirectory,
    string CodePaymentSetting,
    string UserAction
) : IRequest<ErrorOr<ClientMessageSuccess<ResponsePaymentFile>>>;
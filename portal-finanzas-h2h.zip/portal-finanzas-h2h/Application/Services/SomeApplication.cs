﻿using Microsoft.AspNetCore.Http;

namespace Application.Services;

public class SomeApplication
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    public SomeApplication(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public string GetRequestHost()
    {
        var httpContext = _httpContextAccessor.HttpContext;
        if (httpContext != null)
        {
            return httpContext.Request.Host.Value;
        }

        return "Host no disponible";
    }
}

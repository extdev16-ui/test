using Application.Helpers;
using ErrorOr;
using MediatR;
using Domain.PendingPayments;

namespace Application.Services.ValidateRulePendingPayment;

public record ValidateRulePendingPaymentCommand(
    List<PendingPaymentResponse> PendingPaymentResponses
) : IRequest<ErrorOr<ClientMessageSuccess<object>>>;
using FluentValidation;

namespace Application.Services.ValidateRulePendingPayment;

public class ValidateRulePendingPaymentCommandValidator : AbstractValidator<ValidateRulePendingPaymentCommand>
{
    public ValidateRulePendingPaymentCommandValidator()
    {
        RuleFor(r => r.PendingPaymentResponses).NotNull().NotEqual([])
             .WithName("Pagos pendientes");
    }
}
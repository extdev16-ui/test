﻿using Application.Common.Logging;
using Application.Helpers;
using Application.PaymentsSettings.GetByCode;
using Application.Services.ValidateRulePendingPayment;
using Domain.Catalogs;
using Domain.PaymentsSettings.Validators;
using Domain.Primitives;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;

namespace Application.Services.UploadPaymentOrderFile;

internal sealed class ValidateRulePendingPaymentCommandHandler : IRequestHandler<ValidateRulePendingPaymentCommand, ErrorOr<ClientMessageSuccess<object>>>
{
	private readonly ICatalogRepository _catalogRepository;
	private readonly IValidatePaymentSetting _validatePaymentSetting;
	private readonly ILogger<ValidateRulePendingPaymentCommandHandler> _logger;
	private readonly ISender _mediator;
	private readonly IUnitOfWork _unitOfWork;

	public ValidateRulePendingPaymentCommandHandler(ICatalogRepository catalogRepository,
												IValidatePaymentSetting validatePaymentSetting,
												ILogger<ValidateRulePendingPaymentCommandHandler> logger,
												ISender mediator,
												IUnitOfWork unitOfWork
												)
	{
		_catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
		_validatePaymentSetting = validatePaymentSetting ?? throw new ArgumentNullException(nameof(validatePaymentSetting));
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
		_unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
	}

	public async Task<ErrorOr<ClientMessageSuccess<object>>> Handle(ValidateRulePendingPaymentCommand command, CancellationToken cancellationToken)
	{
		ClientMessageSuccess<object> clientMessage = new();

		try
		{
			var configuracionPago = command.PendingPaymentResponses.FirstOrDefault()!.ConfiguracionPago;
			using (LogContext.PushProperty("Identifier", string.Concat("Id Configuracion Pago: ", configuracionPago)))
			{
				_logger.LogInformation("Inicio del proceso de validación de reglas.");
				//Step 1: Get payment rule
				var getPaymentSettingByIdQueryResult = await _mediator.Send(new GetPaymentSettingByCodeQuery(configuracionPago));

				if (getPaymentSettingByIdQueryResult.IsError)
				{
					_logger.LogError(getPaymentSettingByIdQueryResult.FirstError.Description);
					return getPaymentSettingByIdQueryResult.FirstError;
				}

				var paymentFile = getPaymentSettingByIdQueryResult.Value!;
				var paymentRules = paymentFile.DetalleReglas;
				var paymentBancos = paymentFile.DetalleBancos;

				if (paymentRules is null)
				{
					_logger.LogError("No cuenta con reglas la configuración de pago.");
					//return Error.Validation("Configuración Pago", "No cuenta con reglas la configuración de pago.");
				}

				//Step 2: Validate rules
				clientMessage.Data.AddRange(_validatePaymentSetting.ValidateRulePendingPayment(command.PendingPaymentResponses, paymentRules!, paymentBancos!));

				_logger.LogInformation("Fin del proceso de validación de reglas.");

				return clientMessage;
			}
		}
		catch (Exception ex)
		{
			_logger.LogException(ex);
			return Error.Failure("Error Interno", ex.Message!);
		}
	}
}
using FluentValidation;

namespace Application.Services.SetStatusPaymentFile;

public class SetStatusPaymentFileCommandValidator : AbstractValidator<SetStatusPaymentFileCommand>
{
    public SetStatusPaymentFileCommandValidator()
    {
        RuleFor(r => r.FileName).NotEmpty()
             .WithName("Nombre de archivo");
        RuleFor(r => r.CodePaymentSetting).NotEmpty()
             .WithName("Configuraci�n pago");
		RuleFor(r => r.UserAction).NotEmpty()
             .WithName("Usuario Acci�n");
    }
}
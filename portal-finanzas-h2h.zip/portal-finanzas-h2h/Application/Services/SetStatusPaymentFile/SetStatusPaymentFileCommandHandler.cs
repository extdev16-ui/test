﻿using Application.Helpers;
using Application.PaymentsFiles.GetByNames;
using Application.PaymentsFiles.Update;
using Application.PaymentsSettings.GetByCode;
using Domain.Primitives;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using Domain.PaymentsSettings;
using Domain.ValueObjects.PaymentsFiles;
using Domain.PaymentsFiles.Helpers;
using Domain.Catalogs;
using static Domain.Common.Constants;
using Application.Common.Logging;
using Domain.PaymentsFiles.Models;

namespace Application.Services.SetStatusPaymentFile;

internal sealed class SetStatusPaymentFileCommandHandler : IRequestHandler<SetStatusPaymentFileCommand, ErrorOr<ClientMessageSuccess<object>>>
{
	private readonly ICatalogRepository _catalogRepository;
	private readonly ILogger<SetStatusPaymentFileCommandHandler> _logger;
	private readonly ISender _mediator;
	private readonly IUnitOfWork _unitOfWork;

	public SetStatusPaymentFileCommandHandler(ICatalogRepository catalogRepository,
		ILogger<SetStatusPaymentFileCommandHandler> logger,
												ISender mediator,
												IUnitOfWork unitOfWork
												)
	{
		_catalogRepository = catalogRepository ?? throw new ArgumentNullException(nameof(catalogRepository));
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
		_mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
		_unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
	}

	public async Task<ErrorOr<ClientMessageSuccess<object>>> Handle(SetStatusPaymentFileCommand command, CancellationToken cancellationToken)
	{
		ClientMessageSuccess<object> clientMessage = new();

		await _unitOfWork.BeginTransactionAsync(cancellationToken);

		try
		{
			_logger.LogInformation("Inicio del proceso de actualización de estado de archivo pago.");
			using (LogContext.PushProperty("Identifier", string.Concat("Nombre de archivo: ", command.FileName)))
			{
				//Step 1: Get payment setting by code
				var getPaymentSettingByCodeQuery = await _mediator.Send(new GetPaymentSettingByCodeQuery(command.CodePaymentSetting), cancellationToken);

				if (getPaymentSettingByCodeQuery.IsError)
				{
					_logger.LogError(getPaymentSettingByCodeQuery.FirstError.Description);
					return getPaymentSettingByCodeQuery.FirstError;
				}

				PaymentSetting paymentSetting = getPaymentSettingByCodeQuery.Value;
				List<PaymentFileSetting>? paymentSettingDetail = paymentSetting.DetalleConfiguraciones;

				//Step 2: Get payment file by name
				//string fileNameGetPaymentFiles = PaymentFileHelper.SetFileNameByPaymentSettingCode(paymentSetting.Codigo, command.FileName, command.Status!);
				var getPaymentFileByNames = await _mediator.Send(new GetPaymentFileByNamesQuery(command.FileName), cancellationToken);

				if (getPaymentFileByNames.IsError)
				{
					_logger.LogError(getPaymentFileByNames.FirstError.Description);
					return getPaymentFileByNames.FirstError;
				}
				PaymentFile? paymentFile = null;

				paymentFile = getPaymentFileByNames.Value.Find(c=> c.CatalogoTipo.Codigo == command.FileType);

				if (!paymentFile!.CanUpdateState(command.Status!, out string? errorMessage))
				{
					_logger.LogError(errorMessage!);
					return Error.Validation("Archivo Pago", errorMessage!);
				}

				//Step 3: Update Status PaymentFile
				_logger.LogInformation("Actualizar estado de Archivo Pago en base de datos.");
				var updatePaymentFileCommand = await _mediator.Send(new UpdatePaymentFileCommand(paymentFile, paymentSetting, command.FileName, command.Status!, command.FileType!, command.UserAction), cancellationToken);
				if (updatePaymentFileCommand.IsError)
				{
					_logger.LogError(updatePaymentFileCommand.FirstError.Description);
					await _unitOfWork.RollbackTransactionAsync(cancellationToken);
					return updatePaymentFileCommand.FirstError;
				}

				// Confirmar la transacción
				await _unitOfWork.CommitTransactionAsync(cancellationToken);
				_logger.LogInformation($"Actualización de estado a {paymentFile.CatalogoEstado.Nombre} de registros exitosa de Orden Pago en base de datos.");

				clientMessage.Data.Add(paymentFile.Id);

				_logger.LogInformation("Fin del proceso de envío de archivo.");

				return clientMessage;
			}
		}
		catch (Exception ex)
		{
			using (LogContext.PushProperty("Identifier", string.Concat("Nombre de archivo: ", command.FileName)))
			{
				_logger.LogException(ex);

				await _unitOfWork.RollbackTransactionAsync(cancellationToken);
				return Error.Failure("Error Interno", ex.Message!);
			}
		}
	}
}
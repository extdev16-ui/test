using Application.Helpers;
using ErrorOr;
using MediatR;

namespace Application.Services.SetStatusPaymentFile;

public record SetStatusPaymentFileCommand : IRequest<ErrorOr<ClientMessageSuccess<object>>>
{
    public string FileName { get; set; }
    public string? Status { get; set; }
    public string CodePaymentSetting { get; set; }
    public string UserAction { get; set; }
	public string? FileType { get; set; }

	public SetStatusPaymentFileCommand(string fileName, string? status, string codePaymentSetting, string fileType, string userAction)
    {
        FileName = fileName;
        Status = status;
        CodePaymentSetting = codePaymentSetting;
        FileType = fileType;
        UserAction = userAction;
    }
};
﻿using Application.Helpers;
using Application.PaymentsFiles.ReleasePayment;
using Application.PaymentsFiles.ReleasePayment.Requests;
using Application.PaymentsFiles.ReleasePayment.Results;
using Domain.PaymentsAudits;
using Domain.PaymentsAudits.Interfaces;
using Domain.Primitives;
using ErrorOr;
using MediatR;
using Microsoft.Extensions.Logging;
using Serilog.Context;

namespace Application.Services.ReleasePaymentProcess;

internal sealed class ReleasePaymenProcessCommandHandler(
    IReleasePaymentRepository repositoryReleasePayment,
    IPaymentAuditRepository paymentAuditRepository,
    IUnitOfWork unitOfWork,
    ILogger<ReleasePaymenProcessCommandHandler> logger)
        : IRequestHandler<ReleasePaymentFileProcessCommand, ErrorOr<ClientMessageSuccess<ReleasePaymentResult>>>
{
    private readonly IReleasePaymentRepository _repositoryReleasePayment = repositoryReleasePayment;
    private readonly IPaymentAuditRepository _paymentAuditRepository = paymentAuditRepository; 
    private readonly IUnitOfWork _unitOfWork = unitOfWork;
    private readonly ILogger<ReleasePaymenProcessCommandHandler> _logger = logger;

    public async Task<ErrorOr<ClientMessageSuccess<ReleasePaymentResult>>> Handle(ReleasePaymentFileProcessCommand request, CancellationToken cancellationToken)
    {
        await _unitOfWork.BeginTransactionAsync(cancellationToken);

        try
        {
            using (LogContext.PushProperty("Identifier", $"ReleaseProcess:{request.IdPagoMasivo}"))
            {
                _logger.LogInformation("Inicio del proceso de liberación de pago masivo.");

                var result = await _repositoryReleasePayment.ReleasePaymentAsync(
                    new ReleasePaymentRequest { IdPagoMasivo = request.IdPagoMasivo, UserId = request.UserId }, cancellationToken);

                var orderPagoAffectedRows = await _repositoryReleasePayment.ReleasePaymentOrderAsync(
                    new ReleasePaymentRequest { IdPagoMasivo = request.IdPagoMasivo, UserId = request.UserId }, cancellationToken);


                if (result.CantidadRetiros > 0 && orderPagoAffectedRows > 0)
                {
                    _paymentAuditRepository.Add(new PaymentAudit
                    {
                        IdPagoMasivo = request.IdPagoMasivo,
                        Accion = "Liberación de Pago Masivo EXITOSA",
                        Detalle = $"Se liberaron {result.CantidadRetiros} retiros y se actualizó {orderPagoAffectedRows} orden de pago. Id: {request.IdPagoMasivo}",
                        RegistroAuditoria = new Domain.ValueObjects.AuditRecord
                        {
                            UsuarioCreador = (request.UserId).ToString(),
                            AppCreador = "PORTAL FINANZAS",
                            FechaCreacion = DateTime.UtcNow,
                        }
                    });

                    await _unitOfWork.SaveChangesAsync(cancellationToken);
                    await _unitOfWork.CommitTransactionAsync(cancellationToken);

                    _logger.LogInformation("Liberación y Commit exitoso. Retiros liberados: {Count}", result.CantidadRetiros);

                    var client = new ClientMessageSuccess<ReleasePaymentResult>();
                    client.Data.Add(result);
                    return client;
                }
                else
                {
                    _paymentAuditRepository.Add(new PaymentAudit
                    {
                        IdPagoMasivo = request.IdPagoMasivo,
                        Accion = "Liberación de Pago Masivo CERO/ERROR",
                        Detalle = $"No se liberaron retiros ({result.CantidadRetiros}) o no se actualizó la orden de pago ({orderPagoAffectedRows}). Id: {request.IdPagoMasivo}",
                        RegistroAuditoria = new Domain.ValueObjects.AuditRecord
                        {
                            UsuarioCreador = (request.UserId).ToString(),
                            AppCreador = "PORTAL FINANZAS",
                            FechaCreacion = DateTime.UtcNow,
                        }
                    });

                    await _unitOfWork.SaveChangesAsync(cancellationToken);
                    await _unitOfWork.CommitTransactionAsync(cancellationToken);

                    _logger.LogWarning("Liberación finalizó con 0 retiros o error en la orden de pago. Rollback no necesario, solo se registra auditoría.");

                    return Error.NotFound(
                        code: "ReleasePayment.Empty",
                        description: $"No se encontraron retiros o no se pudo actualizar la Orden de Pago para el pago masivo {request.IdPagoMasivo}.");
                }
            }
        }
        catch (Exception ex)
        {
            await _unitOfWork.RollbackTransactionAsync(cancellationToken);
            _logger.LogError(ex, "ReleasePaymentFileProcess error crítico para IdPagoMasivo: {Id}", request.IdPagoMasivo);

            return Error.Failure("ReleasePaymentFile.Error", ex.Message);
        }
    }
}
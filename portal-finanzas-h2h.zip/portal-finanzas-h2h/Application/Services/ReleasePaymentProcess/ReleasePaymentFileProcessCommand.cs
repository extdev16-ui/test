﻿using Application.Helpers;
using Application.PaymentsFiles.ReleasePayment.Results;
using ErrorOr;
using MediatR;

namespace Application.Services.ReleasePaymentProcess;

public sealed record ReleasePaymentFileProcessCommand(
    int IdPagoMasivo,
    int UserId
) : IRequest<ErrorOr<ClientMessageSuccess<ReleasePaymentResult>>>;
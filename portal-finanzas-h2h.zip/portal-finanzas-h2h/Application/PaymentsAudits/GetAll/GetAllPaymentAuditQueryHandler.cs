using AutoMapper;
using Domain.PaymentsAudits;
using PaymentsAudits.Common;
using ErrorOr;
using MediatR;
using Domain.PaymentsAudits.Interfaces;

namespace Application.PaymentsAudits.GetAll;

internal sealed class GetAllPaymentAuditQueryHandler : IRequestHandler<GetAllPaymentAuditQuery, ErrorOr<IReadOnlyList<PaymentAuditResponse>>>
{
    private readonly IPaymentAuditRepository _paymentAuditRepository;
    private readonly IMapper _mapper;


    public GetAllPaymentAuditQueryHandler(IPaymentAuditRepository paymentAuditRepository, IMapper mapper)
    {
        _paymentAuditRepository = paymentAuditRepository;
        _mapper = mapper;
    }

    public async Task<ErrorOr<IReadOnlyList<PaymentAuditResponse>>> Handle(GetAllPaymentAuditQuery query, CancellationToken cancellationToken)
    {
        IReadOnlyList<PaymentAudit> paymentAudits = await _paymentAuditRepository.GetAll();

        var paymentAuditResponses = _mapper.Map<List<PaymentAuditResponse>>(paymentAudits);

        return paymentAuditResponses;
    }
}

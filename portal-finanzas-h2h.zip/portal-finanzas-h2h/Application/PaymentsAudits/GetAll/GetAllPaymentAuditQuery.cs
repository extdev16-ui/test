﻿using PaymentsAudits.Common;
using ErrorOr;
using MediatR;
namespace Application.PaymentsAudits.GetAll;

public record GetAllPaymentAuditQuery() : IRequest<ErrorOr<IReadOnlyList<PaymentAuditResponse>>>;
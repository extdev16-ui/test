using Domain.PaymentsAudits;
using Domain.PaymentsAudits.Interfaces;
using Domain.Primitives;
using Domain.ValueObjects;
using ErrorOr;
using MediatR;
using System;

namespace Application.PaymentsAudits.MassiveCreate;

internal sealed class MassiveCreatePaymentAuditCommandHandler : IRequestHandler<MassiveCreatePaymentAuditCommand, ErrorOr<Unit>>
{
    private readonly IPaymentAuditRepository _paymentAuditRepository;
    private readonly IUnitOfWork _unitOfWork;

    public MassiveCreatePaymentAuditCommandHandler(IPaymentAuditRepository paymentAuditRepository, IUnitOfWork unitOfWork)
    {
        _paymentAuditRepository = paymentAuditRepository ?? throw new ArgumentNullException(nameof(paymentAuditRepository));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
    }

    public async Task<ErrorOr<Unit>> Handle(MassiveCreatePaymentAuditCommand command, CancellationToken cancellationToken)
    {
        List<PaymentAudit> paymentAudits = [];
        foreach (var paymentAuditItem in command.PaymentAuditItems)
        {

            if (AuditRecord.Create(paymentAuditItem.UsuarioCreador, paymentAuditItem.HostCreador, paymentAuditItem.AppCreador) is not AuditRecord auditRecord)
            {
                return Error.Validation("PaymentAudit.AuditRecord", "Campos de Auditoria no tiene el formato correcto.");
            }

            var paymentAudit = new PaymentAudit(
                paymentAuditItem.IdOrdenPago,
                paymentAuditItem.IdOrdenPagoDetalle,
                paymentAuditItem.Accion,
                paymentAuditItem.Detalle,
                auditRecord
            );
            paymentAudits.Add(paymentAudit);
        }
        _paymentAuditRepository.MassiveAdd(paymentAudits);

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

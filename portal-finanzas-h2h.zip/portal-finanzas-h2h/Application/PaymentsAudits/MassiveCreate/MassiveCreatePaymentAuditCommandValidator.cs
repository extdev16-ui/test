using FluentValidation;

namespace Application.PaymentsAudits.MassiveCreate;

public class MassiveCreatePaymentAuditCommandValidator : AbstractValidator<MassiveCreatePaymentAuditCommand>
{
    public MassiveCreatePaymentAuditCommandValidator()
    {

        RuleFor(r => r.PaymentAuditItems).NotNull().NotEqual([])
             .WithName("Auditorias masivas");
    }
}
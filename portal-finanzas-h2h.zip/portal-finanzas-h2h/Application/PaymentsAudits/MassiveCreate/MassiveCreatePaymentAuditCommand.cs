using Domain.ValueObjects;
using ErrorOr;
using MediatR;

namespace Application.PaymentsAudits.MassiveCreate;

public record MassiveCreatePaymentAuditCommand(
    List<PaymentAuditItem> PaymentAuditItems
) : IRequest<ErrorOr<Unit>>;

public record PaymentAuditItem(
    int IdOrdenPago,
    int IdOrdenPagoDetalle,
    string Accion,
    string Detalle,
    string UsuarioCreador,
    string HostCreador,
    string AppCreador
);
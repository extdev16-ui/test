namespace PaymentsAudits.Common;

public record PaymentAuditResponse(
int IdOrdenPago,
int IdOrdenPagoDetalle,
string Accion,
string Detalle
);
using FluentValidation;

namespace Application.PaymentsAudits.Create;

public class CreatePaymentAuditCommandValidator : AbstractValidator<CreatePaymentAuditCommand>
{
    public CreatePaymentAuditCommandValidator()
    {

        RuleFor(r => r.IdOrdenPago).NotEqual(0)
             .WithName("Orden Pago");
        RuleFor(r => r.Accion).NotEmpty().NotNull()
             .WithName("Acción");
        RuleFor(r => r.Detalle).NotEmpty().NotNull()
             .WithName("Detalle");
        RuleFor(r => r.UsuarioCreador).NotEmpty().NotNull()
             .WithName("Usuario Creador");
    }
}
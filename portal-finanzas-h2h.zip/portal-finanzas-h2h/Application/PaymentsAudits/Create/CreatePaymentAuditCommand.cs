using Domain.ValueObjects;
using ErrorOr;
using MediatR;

namespace Application.PaymentsAudits.Create;

public record CreatePaymentAuditCommand(
    int IdOrdenPago,
    int IdOrdenPagoDetalle,
    string Accion,
    string Detalle,
    string UsuarioCreador,
    string HostCreador,
    string AppCreador
) : IRequest<ErrorOr<Unit>>;


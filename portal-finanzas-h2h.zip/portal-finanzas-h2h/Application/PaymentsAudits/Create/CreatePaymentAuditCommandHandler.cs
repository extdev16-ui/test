using Domain.PaymentsAudits;
using Domain.PaymentsAudits.Interfaces;
using Domain.Primitives;
using Domain.ValueObjects;
using ErrorOr;
using MediatR;
using System;

namespace Application.PaymentsAudits.Create;

internal sealed class CreatePaymentAuditCommandHandler : IRequestHandler<CreatePaymentAuditCommand, ErrorOr<Unit>>
{
    private readonly IPaymentAuditRepository _paymentAuditRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CreatePaymentAuditCommandHandler(IPaymentAuditRepository paymentAuditRepository, IUnitOfWork unitOfWork)
    {
        _paymentAuditRepository = paymentAuditRepository ?? throw new ArgumentNullException(nameof(paymentAuditRepository));
        _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
    }

    public async Task<ErrorOr<Unit>> Handle(CreatePaymentAuditCommand command, CancellationToken cancellationToken)
    {
        if (AuditRecord.Create(command.UsuarioCreador, command.HostCreador, command.AppCreador) is not AuditRecord auditRecord)
        {          
          return Error.Validation("PaymentAudit.AuditRecord", "Campos de Auditoria no tiene el formato correcto.");
        }

        var paymentAudit = new PaymentAudit(
            command.IdOrdenPago,
            command.IdOrdenPagoDetalle,
            command.Accion,
            command.Detalle,
            auditRecord
        );

        _paymentAuditRepository.Add(paymentAudit);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}
